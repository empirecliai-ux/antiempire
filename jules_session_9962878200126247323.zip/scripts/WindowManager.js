class Pane {
    constructor(manager, url = 'about:blank', title = 'New Tab') {
        this.manager = manager;
        this.element = document.createElement('div');
        this.element.className = 'pane';
        this.element.style.left = '50px';
        this.element.style.top = '50px';
        this.element.style.width = '600px';
        this.element.style.height = '400px';
        
        // Structure
        this.element.innerHTML = `
            <div class="pane-titlebar">
                <div class="pane-title">${title}</div>
                <div class="pane-controls">
                    <button class="pane-btn maximize" title="Maximize/Restore"></button>
                    <button class="pane-btn close" title="Close"></button>
                </div>
            </div>
            <div class="pane-content">
                <webview src="${url}" allowpopups></webview>
                <div class="webview-overlay" style="position:absolute;top:0;left:0;width:100%;height:100%;display:none;z-index:99;"></div>
            </div>
            <div class="resize-handle n"></div>
            <div class="resize-handle e"></div>
            <div class="resize-handle s"></div>
            <div class="resize-handle w"></div>
            <div class="resize-handle ne"></div>
            <div class="resize-handle se"></div>
            <div class="resize-handle sw"></div>
            <div class="resize-handle nw"></div>
        `;

        this.webview = this.element.querySelector('webview');
        this.titleBar = this.element.querySelector('.pane-titlebar');
        this.overlay = this.element.querySelector('.webview-overlay');
        
        this.setupEvents();
        
        // Initial maximize state
        this.isMaximized = false;
        this.preMaximizeRect = null;
    }

    setupEvents() {
        // Activation
        this.element.addEventListener('mousedown', () => this.manager.setActivePane(this));
        
        // Dragging
        this.titleBar.addEventListener('mousedown', (e) => this.manager.startDrag(e, this));
        
        // Resizing
        this.element.querySelectorAll('.resize-handle').forEach(handle => {
            handle.addEventListener('mousedown', (e) => this.manager.startResize(e, this, handle.className.split(' ')[1]));
        });

        // Controls
        this.element.querySelector('.pane-btn.close').addEventListener('click', (e) => {
            e.stopPropagation();
            this.close();
        });

        this.element.querySelector('.pane-btn.maximize').addEventListener('click', (e) => {
            e.stopPropagation();
            this.toggleMaximize();
        });

        // Webview events
        this.webview.addEventListener('did-start-loading', () => {
            this.titleBar.querySelector('.pane-title').textContent = 'Loading...';
        });

        this.webview.addEventListener('did-stop-loading', () => {
            this.titleBar.querySelector('.pane-title').textContent = this.webview.getTitle();
        });
        
        this.webview.addEventListener('page-title-updated', (e) => {
            this.titleBar.querySelector('.pane-title').textContent = e.title;
        });

        this.webview.addEventListener('dom-ready', () => {
             // Inject CSS for scrollbars if needed
        });
        
        // Sync active pane state
        this.webview.addEventListener('focus', () => this.manager.setActivePane(this));
    }

    close() {
        this.element.remove();
        this.manager.removePane(this);
    }

    toggleMaximize() {
        if (this.isMaximized) {
            this.restore();
        } else {
            this.maximize();
        }
    }

    maximize() {
        this.preMaximizeRect = {
            left: this.element.style.left,
            top: this.element.style.top,
            width: this.element.style.width,
            height: this.element.style.height
        };
        this.element.style.left = '0';
        this.element.style.top = '0';
        this.element.style.width = '100%';
        this.element.style.height = '100%';
        this.isMaximized = true;
    }

    restore() {
        if (this.preMaximizeRect) {
            this.element.style.left = this.preMaximizeRect.left;
            this.element.style.top = this.preMaximizeRect.top;
            this.element.style.width = this.preMaximizeRect.width;
            this.element.style.height = this.preMaximizeRect.height;
        }
        this.isMaximized = false;
    }

    showOverlay() {
        this.overlay.style.display = 'block';
    }

    hideOverlay() {
        this.overlay.style.display = 'none';
    }
}

class WindowManager {
    constructor(container) {
        this.container = container;
        this.panes = [];
        this.activePane = null;
        this.dragState = null;
        this.resizeState = null;
        
        // Snap overlay
        this.snapOverlay = document.createElement('div');
        this.snapOverlay.className = 'snap-overlay';
        this.container.appendChild(this.snapOverlay);

        // Global mouse events
        document.addEventListener('mousemove', (e) => this.handleMouseMove(e));
        document.addEventListener('mouseup', (e) => this.handleMouseUp(e));
    }

    createPane(url = 'about:blank') {
        const pane = new Pane(this, url);
        this.container.appendChild(pane.element);
        this.panes.push(pane);
        this.setActivePane(pane);
        return pane;
    }

    removePane(pane) {
        this.panes = this.panes.filter(p => p !== pane);
        if (this.activePane === pane) {
            this.activePane = this.panes.length > 0 ? this.panes[this.panes.length - 1] : null;
            if (this.activePane) this.setActivePane(this.activePane);
        }
    }

    setActivePane(pane) {
        if (this.activePane) {
            this.activePane.element.classList.remove('active');
            this.activePane.element.style.zIndex = 10;
        }
        this.activePane = pane;
        if (pane) {
            pane.element.classList.add('active');
            pane.element.style.zIndex = 20;
            // Dispatch event for UI updates (address bar)
            const event = new CustomEvent('pane-activated', { detail: { pane } });
            document.dispatchEvent(event);
        }
    }

    startDrag(e, pane) {
        if (pane.isMaximized) return; // Cannot drag maximized window easily without restoring first
        
        this.dragState = {
            pane,
            startX: e.clientX,
            startY: e.clientY,
            initialLeft: pane.element.offsetLeft,
            initialTop: pane.element.offsetTop
        };
        pane.showOverlay();
        e.preventDefault();
    }

    startResize(e, pane, handleType) {
        if (pane.isMaximized) return;

        this.resizeState = {
            pane,
            handleType,
            startX: e.clientX,
            startY: e.clientY,
            initialLeft: pane.element.offsetLeft,
            initialTop: pane.element.offsetTop,
            initialWidth: pane.element.offsetWidth,
            initialHeight: pane.element.offsetHeight
        };
        pane.showOverlay();
        e.preventDefault();
    }

    handleMouseMove(e) {
        if (this.dragState) {
            this.handleDrag(e);
        } else if (this.resizeState) {
            this.handleResize(e);
        }
    }

    handleDrag(e) {
        const { pane, startX, startY, initialLeft, initialTop } = this.dragState;
        const deltaX = e.clientX - startX;
        const deltaY = e.clientY - startY;
        
        let newLeft = initialLeft + deltaX;
        let newTop = initialTop + deltaY;
        
        // Bounds check (keep titlebar visible)
        if (newTop < 0) newTop = 0;
        if (newTop > this.container.clientHeight - 30) newTop = this.container.clientHeight - 30;
        if (newLeft < -pane.element.offsetWidth + 50) newLeft = -pane.element.offsetWidth + 50;
        if (newLeft > this.container.clientWidth - 50) newLeft = this.container.clientWidth - 50;

        pane.element.style.left = `${newLeft}px`;
        pane.element.style.top = `${newTop}px`;

        // Snap detection
        this.checkSnap(e.clientX, e.clientY);
    }

    checkSnap(x, y) {
        const threshold = 20;
        const { clientWidth, clientHeight } = this.container;
        
        this.snapOverlay.classList.remove('visible');
        this.dragState.snapType = null;

        if (x < threshold) {
            // Left half
            this.showSnapPreview(0, 0, clientWidth / 2, clientHeight);
            this.dragState.snapType = 'left';
        } else if (x > clientWidth - threshold) {
            // Right half
            this.showSnapPreview(clientWidth / 2, 0, clientWidth / 2, clientHeight);
            this.dragState.snapType = 'right';
        } else if (y < threshold) {
            // Top half (or maximize)
            this.showSnapPreview(0, 0, clientWidth, clientHeight); // Maximize
            this.dragState.snapType = 'maximize';
        } else if (y > clientHeight - threshold) {
            // Bottom half
             this.showSnapPreview(0, clientHeight / 2, clientWidth, clientHeight / 2);
             this.dragState.snapType = 'bottom';
        }
    }

    showSnapPreview(x, y, w, h) {
        this.snapOverlay.style.left = `${x}px`;
        this.snapOverlay.style.top = `${y}px`;
        this.snapOverlay.style.width = `${w}px`;
        this.snapOverlay.style.height = `${h}px`;
        this.snapOverlay.classList.add('visible');
    }

    handleResize(e) {
        const { pane, handleType, startX, startY, initialLeft, initialTop, initialWidth, initialHeight } = this.resizeState;
        const deltaX = e.clientX - startX;
        const deltaY = e.clientY - startY;

        if (handleType.includes('e')) {
            pane.element.style.width = `${Math.max(200, initialWidth + deltaX)}px`;
        }
        if (handleType.includes('s')) {
            pane.element.style.height = `${Math.max(150, initialHeight + deltaY)}px`;
        }
        if (handleType.includes('w')) {
            const newWidth = Math.max(200, initialWidth - deltaX);
            pane.element.style.width = `${newWidth}px`;
            pane.element.style.left = `${initialLeft + (initialWidth - newWidth)}px`;
        }
        if (handleType.includes('n')) {
             const newHeight = Math.max(150, initialHeight - deltaY);
             pane.element.style.height = `${newHeight}px`;
             pane.element.style.top = `${initialTop + (initialHeight - newHeight)}px`;
        }
    }

    handleMouseUp(e) {
        if (this.dragState) {
            const { pane, snapType } = this.dragState;
            pane.hideOverlay();
            
            if (snapType) {
                this.applySnap(pane, snapType);
            }
            
            this.snapOverlay.classList.remove('visible');
            this.dragState = null;
        } else if (this.resizeState) {
            this.resizeState.pane.hideOverlay();
            this.resizeState = null;
        }
    }

    applySnap(pane, type) {
        const { clientWidth, clientHeight } = this.container;
        
        pane.preMaximizeRect = { // Save state before snap
            left: pane.element.style.left,
            top: pane.element.style.top,
            width: pane.element.style.width,
            height: pane.element.style.height
        };

        if (type === 'left') {
            pane.element.style.left = '0';
            pane.element.style.top = '0';
            pane.element.style.width = '50%';
            pane.element.style.height = '100%';
        } else if (type === 'right') {
            pane.element.style.left = '50%';
            pane.element.style.top = '0';
            pane.element.style.width = '50%';
            pane.element.style.height = '100%';
        } else if (type === 'maximize') {
            pane.maximize(); // Use existing maximize logic
            return;
        } else if (type === 'bottom') {
            pane.element.style.left = '0';
            pane.element.style.top = '50%';
            pane.element.style.width = '100%';
            pane.element.style.height = '50%';
        }
        // pane.isMaximized = true; // Treat snap as maximize state? Maybe not strictly.
    }
}

// Export for usage
window.WindowManager = WindowManager;
