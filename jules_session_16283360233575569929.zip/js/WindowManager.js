class WindowManager {
    constructor(containerId) {
        this.container = document.getElementById(containerId);
        this.panes = [];
        this.activePane = null;
        this.zIndexCounter = 10;
        this.snapDistance = 20;

        // Global event listeners for drag/resize end
        document.addEventListener('mousemove', (e) => this.handleMouseMove(e));
        document.addEventListener('mouseup', () => this.handleMouseUp());

        this.dragState = {
            isDragging: false,
            isResizing: false,
            pane: null,
            startX: 0,
            startY: 0,
            initialLeft: 0,
            initialTop: 0,
            initialWidth: 0,
            initialHeight: 0,
            resizeDirection: ''
        };
    }

    createPane(url = 'about:blank') {
        const pane = document.createElement('div');
        pane.className = 'window-pane active';
        pane.style.left = '50px';
        pane.style.top = '50px';
        pane.style.width = '800px';
        pane.style.height = '600px';
        pane.style.zIndex = ++this.zIndexCounter;

        pane.innerHTML = `
            <div class="pane-header">
                <div class="pane-title">Loading...</div>
                <div class="pane-controls">
                    <button class="pane-btn expand" title="Maximize Pane"></button>
                    <button class="pane-btn close" title="Close Pane"></button>
                </div>
            </div>
            <div class="pane-content">
                <webview allowpopups></webview>
            </div>
            <div class="resize-handle n"></div>
            <div class="resize-handle s"></div>
            <div class="resize-handle e"></div>
            <div class="resize-handle w"></div>
            <div class="resize-handle ne"></div>
            <div class="resize-handle nw"></div>
            <div class="resize-handle se"></div>
            <div class="resize-handle sw"></div>
        `;

        this.container.appendChild(pane);
        this.panes.push(pane);

        const webview = pane.querySelector('webview');
        webview.src = url;

        this.setActivePane(pane);

        const titleEl = pane.querySelector('.pane-title');

        webview.addEventListener('dom-ready', () => {
             titleEl.textContent = webview.getTitle();
             // Dispatch event to update address bar if this is active pane
             if (this.activePane === pane) {
                 const event = new CustomEvent('pane-updated', { detail: { pane, url: webview.getURL() } });
                 document.dispatchEvent(event);
             }
        });

        webview.addEventListener('page-title-updated', (e) => {
            titleEl.textContent = e.title;
        });

        webview.addEventListener('did-navigate', (e) => {
            if (this.activePane === pane) {
                 const event = new CustomEvent('pane-updated', { detail: { pane, url: e.url } });
                 document.dispatchEvent(event);
             }
        });

        // Pane controls
        pane.querySelector('.close').addEventListener('click', (e) => {
            e.stopPropagation();
            this.closePane(pane);
        });

        pane.querySelector('.expand').addEventListener('click', (e) => {
            e.stopPropagation();
            this.maximizePane(pane);
        });

        // Drag start
        const header = pane.querySelector('.pane-header');
        header.addEventListener('mousedown', (e) => {
            this.startDrag(e, pane);
        });

        // Resize start
        const handles = pane.querySelectorAll('.resize-handle');
        handles.forEach(handle => {
            handle.addEventListener('mousedown', (e) => {
                e.stopPropagation();
                const direction = handle.className.replace('resize-handle ', '');
                this.startResize(e, pane, direction);
            });
        });

        pane.addEventListener('mousedown', () => {
            this.setActivePane(pane);
        });

        return pane;
    }

    closePane(pane) {
        pane.remove();
        this.panes = this.panes.filter(p => p !== pane);
        if (this.panes.length > 0) {
            this.setActivePane(this.panes[this.panes.length - 1]);
        } else {
            this.activePane = null;
            // Dispatch event for no active pane
            const event = new CustomEvent('pane-activated', { detail: { pane: null } });
            document.dispatchEvent(event);
        }
    }

    maximizePane(pane) {
        // Toggle maximize logic
        if (pane.dataset.maximized === 'true') {
            pane.style.left = pane.dataset.prevLeft;
            pane.style.top = pane.dataset.prevTop;
            pane.style.width = pane.dataset.prevWidth;
            pane.style.height = pane.dataset.prevHeight;
            pane.dataset.maximized = 'false';
        } else {
            pane.dataset.prevLeft = pane.style.left;
            pane.dataset.prevTop = pane.style.top;
            pane.dataset.prevWidth = pane.style.width;
            pane.dataset.prevHeight = pane.style.height;

            pane.style.left = '0';
            pane.style.top = '0';
            pane.style.width = '100%';
            pane.style.height = '100%';
            pane.dataset.maximized = 'true';
        }
    }

    setActivePane(pane) {
        this.panes.forEach(p => p.classList.remove('active'));
        pane.classList.add('active');
        pane.style.zIndex = ++this.zIndexCounter;
        this.activePane = pane;

        // Dispatch event so renderer can update address bar
        const webview = pane.querySelector('webview');
        const url = (webview && typeof webview.getURL === 'function') ? webview.getURL() : 'about:blank';
        const event = new CustomEvent('pane-activated', { detail: { pane, url } });
        document.dispatchEvent(event);
    }

    startDrag(e, pane) {
        if (pane.dataset.maximized === 'true') return;

        this.dragState.isDragging = true;
        this.dragState.pane = pane;
        this.dragState.startX = e.clientX;
        this.dragState.startY = e.clientY;
        this.dragState.initialLeft = pane.offsetLeft;
        this.dragState.initialTop = pane.offsetTop;
    }

    startResize(e, pane, direction) {
        if (pane.dataset.maximized === 'true') return;

        this.dragState.isResizing = true;
        this.dragState.pane = pane;
        this.dragState.resizeDirection = direction;
        this.dragState.startX = e.clientX;
        this.dragState.startY = e.clientY;
        this.dragState.initialLeft = pane.offsetLeft;
        this.dragState.initialTop = pane.offsetTop;
        this.dragState.initialWidth = pane.offsetWidth;
        this.dragState.initialHeight = pane.offsetHeight;
    }

    handleMouseMove(e) {
        if (this.dragState.isDragging) {
            const dx = e.clientX - this.dragState.startX;
            const dy = e.clientY - this.dragState.startY;

            let newLeft = this.dragState.initialLeft + dx;
            let newTop = this.dragState.initialTop + dy;

            // Snap logic
            newLeft = this.snap(newLeft, 'x');
            newTop = this.snap(newTop, 'y');

            // Boundary checks
            const containerWidth = this.container.offsetWidth;
            const containerHeight = this.container.offsetHeight;
            const paneWidth = this.dragState.pane.offsetWidth;
            const paneHeight = this.dragState.pane.offsetHeight;

            if (newLeft < 0) newLeft = 0;
            if (newTop < 0) newTop = 0;
            if (newLeft + paneWidth > containerWidth) newLeft = containerWidth - paneWidth;
            if (newTop + paneHeight > containerHeight) newTop = containerHeight - paneHeight;

            this.dragState.pane.style.left = `${newLeft}px`;
            this.dragState.pane.style.top = `${newTop}px`;
        }
        else if (this.dragState.isResizing) {
            const dx = e.clientX - this.dragState.startX;
            const dy = e.clientY - this.dragState.startY;
            const direction = this.dragState.resizeDirection;

            let newWidth = this.dragState.initialWidth;
            let newHeight = this.dragState.initialHeight;
            let newLeft = this.dragState.initialLeft;
            let newTop = this.dragState.initialTop;

            if (direction.includes('e')) newWidth += dx;
            if (direction.includes('w')) {
                newWidth -= dx;
                newLeft += dx;
            }
            if (direction.includes('s')) newHeight += dy;
            if (direction.includes('n')) {
                newHeight -= dy;
                newTop += dy;
            }

            // Minimum size
            if (newWidth < 200) newWidth = 200;
            if (newHeight < 150) newHeight = 150;

            this.dragState.pane.style.width = `${newWidth}px`;
            this.dragState.pane.style.height = `${newHeight}px`;
            if (direction.includes('w')) this.dragState.pane.style.left = `${newLeft}px`;
            if (direction.includes('n')) this.dragState.pane.style.top = `${newTop}px`;
        }
    }

    handleMouseUp() {
        this.dragState.isDragging = false;
        this.dragState.isResizing = false;
        this.dragState.pane = null;
    }

    snap(pos, axis) {
        // Snap to container edges
        if (Math.abs(pos) < this.snapDistance) return 0;

        const containerSize = axis === 'x' ? this.container.offsetWidth : this.container.offsetHeight;
        const paneSize = axis === 'x' ? this.dragState.pane.offsetWidth : this.dragState.pane.offsetHeight;

        if (Math.abs(pos + paneSize - containerSize) < this.snapDistance) {
            return containerSize - paneSize;
        }

        // Snap to other panes
        for (const otherPane of this.panes) {
            if (otherPane === this.dragState.pane) continue;

            const otherRect = {
                left: otherPane.offsetLeft,
                top: otherPane.offsetTop,
                right: otherPane.offsetLeft + otherPane.offsetWidth,
                bottom: otherPane.offsetTop + otherPane.offsetHeight
            };

            if (axis === 'x') {
                // Snap left to right
                if (Math.abs(pos - otherRect.right) < this.snapDistance) return otherRect.right;
                // Snap right to left
                if (Math.abs(pos + paneSize - otherRect.left) < this.snapDistance) return otherRect.left - paneSize;
                 // Snap left to left
                if (Math.abs(pos - otherRect.left) < this.snapDistance) return otherRect.left;
                 // Snap right to right
                 if (Math.abs(pos + paneSize - otherRect.right) < this.snapDistance) return otherRect.right - paneSize;

            } else {
                 // Snap top to bottom
                if (Math.abs(pos - otherRect.bottom) < this.snapDistance) return otherRect.bottom;
                // Snap bottom to top
                if (Math.abs(pos + paneSize - otherRect.top) < this.snapDistance) return otherRect.top - paneSize;
                // Snap top to top
                if (Math.abs(pos - otherRect.top) < this.snapDistance) return otherRect.top;
                 // Snap bottom to bottom
                 if (Math.abs(pos + paneSize - otherRect.bottom) < this.snapDistance) return otherRect.bottom - paneSize;
            }
        }

        return pos;
    }
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = WindowManager;
} else {
    window.WindowManager = WindowManager;
}
