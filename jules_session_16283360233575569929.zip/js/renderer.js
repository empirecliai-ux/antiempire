const ipcRenderer = (typeof require !== 'undefined') ? require('electron').ipcRenderer : {
    send: () => {}, invoke: () => Promise.resolve(), on: () => {}
};
// In browser environment, WindowManager is already global from the previous script tag
const WindowManagerRef = (typeof require !== 'undefined' && typeof module !== 'undefined') ? require('./js/WindowManager.js') : WindowManager;

const addressBar = document.getElementById('address-bar');
const loadingScreen = document.getElementById('loading-screen');
const novaBtn = document.getElementById('nova-btn');
const voiceOverlay = document.getElementById('voice-overlay');

// Empire Navigator Core
class EmpireNavigatorRenderer {
    constructor() {
        this.isListening = false;
        this.recognition = null;
        this.windowManager = new WindowManagerRef('browser-content');

        this.initializeVoiceRecognition();
        this.setupEventListeners();

        // Create initial pane
        this.windowManager.createPane('https://www.google.com');

        this.hideLoadingScreen();
    }

    initializeVoiceRecognition() {
        if ('webkitSpeechRecognition' in window) {
            this.recognition = new webkitSpeechRecognition();
            this.recognition.continuous = false;
            this.recognition.interimResults = false;
            this.recognition.lang = 'en-US';

            this.recognition.onstart = () => {
                console.log('🎤 Nova listening...');
                this.isListening = true;
                novaBtn.classList.add('listening');
                voiceOverlay.classList.add('active');
            };

            this.recognition.onresult = (event) => {
                const command = event.results[0][0].transcript;
                console.log('🗣️ Voice Command:', command);
                this.handleVoiceCommand(command);
            };

            this.recognition.onend = () => {
                this.isListening = false;
                novaBtn.classList.remove('listening');
                voiceOverlay.classList.remove('active');
            };

            this.recognition.onerror = (event) => {
                console.error('Voice recognition error:', event.error);
                this.isListening = false;
                novaBtn.classList.remove('listening');
                voiceOverlay.classList.remove('active');
            };
        }
    }

    setupEventListeners() {
        // Pane updates
        document.addEventListener('pane-updated', (e) => {
            const { pane, url } = e.detail;
            if (this.windowManager.activePane === pane) {
                addressBar.value = url;
                this.updateNavigationButtons();
            }
        });

        document.addEventListener('pane-activated', (e) => {
            const { pane, url } = e.detail;
            if (pane) {
                addressBar.value = url;
                this.updateNavigationButtons();
            } else {
                addressBar.value = '';
                // Disable nav buttons if no pane
            }
        });

        // Empire status updates
        setInterval(() => {
            this.updateEmpireStatus();
        }, 5000);
    }

    hideLoadingScreen() {
        setTimeout(() => {
            loadingScreen.style.opacity = '0';
            setTimeout(() => {
                loadingScreen.style.display = 'none';
            }, 500);
        }, 3000);
    }

    handleVoiceCommand(command) {
        const cmd = command.toLowerCase();

        // Update voice overlay
        document.getElementById('voice-command-text').textContent = `"${command}"`;

        // Send to main process (if needed)
        // ipcRenderer.invoke('empire-command', command);

        // Handle locally
        if (cmd.includes('navigate to') || cmd.includes('go to')) {
            const site = cmd.replace(/navigate to|go to/g, '').trim();
            this.navigateToSite(site);
        } else if (cmd.includes('new tab') || cmd.includes('new window')) {
            this.windowManager.createPane('about:blank');
        } else if (cmd.includes('refresh') || cmd.includes('reload')) {
            this.refresh();
        } else if (cmd.includes('back')) {
            this.goBack();
        } else if (cmd.includes('forward')) {
            this.goForward();
        } else if (cmd.includes('close tab') || cmd.includes('close window')) {
            if (this.windowManager.activePane) {
                this.windowManager.closePane(this.windowManager.activePane);
            }
        }
    }

    navigateToSite(site) {
        let url = site;

        if (!url.includes('http')) {
            if (url.includes('.')) {
                url = `https://${url}`;
            } else {
                const shortcuts = {
                    'github': 'https://github.com',
                    'gmail': 'https://gmail.com',
                    'teams': 'https://teams.microsoft.com',
                    'discord': 'https://discord.com',
                    'youtube': 'https://youtube.com'
                };
                url = shortcuts[url] || `https://www.google.com/search?q=${encodeURIComponent(url)}`;
            }
        }

        if (this.windowManager.activePane) {
            const webview = this.windowManager.activePane.querySelector('webview');
            webview.src = url;
            // addressBar.value = url; // updated by pane-updated event
        } else {
            this.windowManager.createPane(url);
        }
    }

    updateNavigationButtons() {
        const backBtn = document.getElementById('back-btn');
        const forwardBtn = document.getElementById('forward-btn');

        if (this.windowManager.activePane) {
            const webview = this.windowManager.activePane.querySelector('webview');
            // Check if webview is ready
            try {
                if (webview.canGoBack) {
                    backBtn.disabled = !webview.canGoBack();
                    forwardBtn.disabled = !webview.canGoForward();
                }
            } catch (e) {
                console.log('Webview not ready yet');
            }
        } else {
            backBtn.disabled = true;
            forwardBtn.disabled = true;
        }
    }

    async updateEmpireStatus() {
        // Mock status update
        document.getElementById('agent-count').textContent = '47 AGENTS';
    }

    goBack() {
        if (this.windowManager.activePane) {
            this.windowManager.activePane.querySelector('webview').goBack();
        }
    }

    goForward() {
        if (this.windowManager.activePane) {
            this.windowManager.activePane.querySelector('webview').goForward();
        }
    }

    refresh() {
        if (this.windowManager.activePane) {
            this.windowManager.activePane.querySelector('webview').reload();
        }
    }
}

// Global Functions
window.activateNova = function() {
    if (empireNavigator.recognition && !empireNavigator.isListening) {
        empireNavigator.recognition.start();
    }
}

window.toggleSocietas = function() {
    console.log('Toggle Societas');
    // Implementation for Societas panel could go here
}

window.handleAddressBar = function(event) {
    if (event.key === 'Enter') {
        const url = addressBar.value;
        empireNavigator.navigateToSite(url);
    }
}

window.goBack = function() {
    empireNavigator.goBack();
}

window.goForward = function() {
    empireNavigator.goForward();
}

window.refresh = function() {
    empireNavigator.refresh();
}

window.minimizeWindow = function() {
    ipcRenderer.send('window-minimize');
}

window.maximizeWindow = function() {
    ipcRenderer.send('window-maximize');
}

window.closeWindow = function() {
    ipcRenderer.send('window-close');
}

// Initialize Empire Navigator
const empireNavigator = new EmpireNavigatorRenderer();

// Empire Easter Eggs
document.addEventListener('keydown', (event) => {
    // Ctrl+Shift+E = Empire Command Palette
    if (event.ctrlKey && event.shiftKey && event.key === 'E') {
        activateNova();
    }

    // Ctrl+Shift+S = Show Societas
    if (event.ctrlKey && event.shiftKey && event.key === 'S') {
        toggleSocietas();
    }
});

console.log('🏛️ Empire Navigator initialized');
console.log('🎤 Say "Hey Nova" or click the microphone');
console.log('💬 Press Ctrl+Shift+S for Societas');
