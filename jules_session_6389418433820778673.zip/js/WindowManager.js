class WindowManager {
    constructor(containerId) {
        this.container = document.getElementById(containerId);
        if (!this.container) throw new Error(`Container #${containerId} not found`);
        
        this.panes = [];
        this.activePane = null;
        this.nextZIndex = 100;
        
        // Drag and Resize state
        this.dragState = null;
        this.resizeState = null;
        
        this.setupGlobalEvents();
    }

    setupGlobalEvents() {
        document.addEventListener('mousemove', (e) => this.handleMouseMove(e));
        document.addEventListener('mouseup', (e) => this.handleMouseUp(e));
    }

    createPane(url = 'about:blank') {
        const id = 'pane-' + Date.now() + '-' + Math.floor(Math.random() * 1000);
        const paneEl = document.createElement('div');
        paneEl.className = 'pane';
        paneEl.id = id;
        paneEl.style.zIndex = this.nextZIndex++;
        
        // Initial position (cascade)
        const offset = (this.panes.length % 10) * 20 + 20;
        paneEl.style.left = `${offset}px`;
        paneEl.style.top = `${offset}px`;
        paneEl.style.width = '600px';
        paneEl.style.height = '400px';

        // HTML Structure
        paneEl.innerHTML = `
            <div class="pane-header">
                <span class="pane-title">Loading...</span>
                <div class="pane-controls">
                    <button class="pane-btn close" title="Close"></button>
                </div>
            </div>
            <div class="pane-content">
                <webview class="pane-webview" src="${url}" allowpopups></webview>
                <div class="pane-overlay" style="position:absolute;top:0;left:0;width:100%;height:100%;display:none;"></div>
            </div>
            <!-- Resize Handles -->
            <div class="resize-handle n" data-dir="n"></div>
            <div class="resize-handle s" data-dir="s"></div>
            <div class="resize-handle e" data-dir="e"></div>
            <div class="resize-handle w" data-dir="w"></div>
            <div class="resize-handle ne" data-dir="ne"></div>
            <div class="resize-handle nw" data-dir="nw"></div>
            <div class="resize-handle se" data-dir="se"></div>
            <div class="resize-handle sw" data-dir="sw"></div>
        `;

        this.container.appendChild(paneEl);

        const webview = paneEl.querySelector('webview');
        
        // Pane Object
        const pane = {
            id,
            element: paneEl,
            webview: webview,
            currentUrl: url
        };

        this.panes.push(pane);
        this.setActivePane(pane);

        // Event Listeners for this pane
        this.setupPaneEvents(pane);

        return pane;
    }

    setupPaneEvents(pane) {
        const header = pane.element.querySelector('.pane-header');
        const closeBtn = pane.element.querySelector('.close');
        
        // Activate on click
        pane.element.addEventListener('mousedown', () => {
            this.setActivePane(pane);
        });

        // Drag Start
        header.addEventListener('mousedown', (e) => {
            if (e.target.closest('.pane-controls')) return; // Don't drag if clicking controls
            e.preventDefault();
            this.dragState = {
                pane: pane,
                startX: e.clientX,
                startY: e.clientY,
                initialLeft: pane.element.offsetLeft,
                initialTop: pane.element.offsetTop
            };
            this.showOverlay(true); // Overlay to capture mouse events over webview
        });

        // Close
        closeBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            this.removePane(pane.id);
        });

        // Resize Start
        const handles = pane.element.querySelectorAll('.resize-handle');
        handles.forEach(handle => {
            handle.addEventListener('mousedown', (e) => {
                e.preventDefault();
                e.stopPropagation();
                this.resizeState = {
                    pane: pane,
                    dir: handle.dataset.dir,
                    startX: e.clientX,
                    startY: e.clientY,
                    initialLeft: pane.element.offsetLeft,
                    initialTop: pane.element.offsetTop,
                    initialWidth: pane.element.offsetWidth,
                    initialHeight: pane.element.offsetHeight
                };
                this.showOverlay(true);
            });
        });

        // Webview Events
        if (pane.webview) {
            pane.webview.addEventListener('did-start-loading', () => {
                const titleEl = pane.element.querySelector('.pane-title');
                if (titleEl) titleEl.textContent = 'Loading...';
            });

            pane.webview.addEventListener('did-stop-loading', () => {
                const titleEl = pane.element.querySelector('.pane-title');
                if (titleEl) titleEl.textContent = pane.webview.getTitle();
                pane.currentUrl = pane.webview.getURL();
                if (this.activePane === pane) {
                    this.updateAddressBar(pane.currentUrl);
                }
            });

            pane.webview.addEventListener('dom-ready', () => {
                 const titleEl = pane.element.querySelector('.pane-title');
                 if (titleEl) titleEl.textContent = pane.webview.getTitle();
            });
            
            pane.webview.addEventListener('did-navigate', (e) => {
                 pane.currentUrl = e.url;
                 if (this.activePane === pane) {
                    this.updateAddressBar(e.url);
                }
            });
        }
    }

    removePane(id) {
        const index = this.panes.findIndex(p => p.id === id);
        if (index > -1) {
            const pane = this.panes[index];
            pane.element.remove();
            this.panes.splice(index, 1);
            if (this.activePane === pane) {
                this.activePane = this.panes.length > 0 ? this.panes[this.panes.length - 1] : null;
                if (this.activePane) this.setActivePane(this.activePane);
            }
        }
    }

    setActivePane(pane) {
        this.activePane = pane;
        
        // Update Z-Index
        pane.element.style.zIndex = this.nextZIndex++;
        
        // Update Styles
        this.panes.forEach(p => p.element.classList.remove('active'));
        pane.element.classList.add('active');

        // Dispatch Event for UI updates
        const event = new CustomEvent('pane-activated', { detail: { pane: pane } });
        document.dispatchEvent(event);
        
        if (pane.currentUrl) {
            this.updateAddressBar(pane.currentUrl);
        }
    }

    updateAddressBar(url) {
        const addressBar = document.getElementById('address-bar');
        if (addressBar) {
            addressBar.value = url;
        }
    }

    handleMouseMove(e) {
        if (this.dragState) {
            e.preventDefault();
            const { pane, startX, startY, initialLeft, initialTop } = this.dragState;
            const dx = e.clientX - startX;
            const dy = e.clientY - startY;
            
            pane.element.style.left = `${initialLeft + dx}px`;
            pane.element.style.top = `${initialTop + dy}px`;
        } else if (this.resizeState) {
            e.preventDefault();
            const { pane, dir, startX, startY, initialLeft, initialTop, initialWidth, initialHeight } = this.resizeState;
            const dx = e.clientX - startX;
            const dy = e.clientY - startY;
            
            let newWidth = initialWidth;
            let newHeight = initialHeight;
            let newLeft = initialLeft;
            let newTop = initialTop;

            if (dir.includes('e')) newWidth = initialWidth + dx;
            if (dir.includes('w')) {
                newWidth = initialWidth - dx;
                newLeft = initialLeft + dx;
            }
            if (dir.includes('s')) newHeight = initialHeight + dy;
            if (dir.includes('n')) {
                newHeight = initialHeight - dy;
                newTop = initialTop + dy;
            }

            // Min dimensions
            if (newWidth > 200) {
                pane.element.style.width = `${newWidth}px`;
                if (dir.includes('w')) pane.element.style.left = `${newLeft}px`;
            }
            if (newHeight > 150) {
                pane.element.style.height = `${newHeight}px`;
                if (dir.includes('n')) pane.element.style.top = `${newTop}px`;
            }
        }
    }

    handleMouseUp(e) {
        if (this.dragState || this.resizeState) {
            this.dragState = null;
            this.resizeState = null;
            this.showOverlay(false);
        }
    }
    
    showOverlay(show) {
        // Show an invisible overlay over all webviews to prevent them from capturing mouse events during drag/resize
        this.panes.forEach(p => {
            const overlay = p.element.querySelector('.pane-overlay');
            if (overlay) overlay.style.display = show ? 'block' : 'none';
        });
    }
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = WindowManager;
} else {
    window.WindowManager = WindowManager;
}
