const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');

function createWindow() {
  const win = new BrowserWindow({
    width: 1200,
    height: 800,
    frame: false, // Custom title bar
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
      webviewTag: true,
      enableRemoteModule: true // might be needed for remote module used in user code
    }
  });

  win.loadFile('index.html');
  
  // win.webContents.openDevTools();
}

app.whenReady().then(() => {
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

// IPC handlers for Empire status
ipcMain.handle('get-empire-status', async () => {
    return { status: 'online', agents: 47 };
});

ipcMain.handle('empire-command', async (event, command) => {
    console.log('Received command:', command);
    // Logic to handle commands can be expanded here
    return { success: true };
});
