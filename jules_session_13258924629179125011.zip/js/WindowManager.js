class WindowManager {
    constructor(container) {
        this.container = container;
        this.panes = [];
        this.activePane = null;
        this.zIndexCounter = 100;
        this.snapThreshold = 20;

        // Global event handlers bound to this instance
        this.handleDragMove = this.handleDragMove.bind(this);
        this.handleDragEnd = this.handleDragEnd.bind(this);
        this.handleResizeMove = this.handleResizeMove.bind(this);
        this.handleResizeEnd = this.handleResizeEnd.bind(this);

        this.dragState = null;
        this.resizeState = null;
    }

    createPane(url) {
        const id = 'pane-' + Date.now() + Math.floor(Math.random() * 1000);
        const pane = document.createElement('div');
        pane.className = 'window-pane';
        pane.id = id;
        pane.style.zIndex = ++this.zIndexCounter;
        
        // Staggered positioning
        const offset = (this.panes.length * 30) % 150;
        pane.style.left = (50 + offset) + 'px';
        pane.style.top = (50 + offset) + 'px';
        pane.style.width = '600px';
        pane.style.height = '400px';

        pane.innerHTML = `
            <div class="pane-header">
                <div class="pane-title">Loading...</div>
                <div class="pane-controls">
                    <button class="pane-btn minimize" title="Minimize"></button>
                    <button class="pane-btn maximize" title="Maximize"></button>
                    <button class="pane-btn close" title="Close"></button>
                </div>
            </div>
            <div class="pane-content">
                <webview src="${url}" allowpopups></webview>
            </div>
            <div class="resize-handle n"></div>
            <div class="resize-handle e"></div>
            <div class="resize-handle s"></div>
            <div class="resize-handle w"></div>
            <div class="resize-handle ne"></div>
            <div class="resize-handle se"></div>
            <div class="resize-handle sw"></div>
            <div class="resize-handle nw"></div>
        `;

        this.container.appendChild(pane);
        const webview = pane.querySelector('webview');
        
        const paneObj = {
            id: id,
            element: pane,
            webview: webview,
            getURL: () => webview.getURL(),
            loadURL: (url) => webview.loadURL(url),
            reload: () => webview.reload(),
            goBack: () => webview.goBack(),
            goForward: () => webview.goForward(),
            canGoBack: () => webview.canGoBack(),
            canGoForward: () => webview.canGoForward()
        };
        
        this.panes.push(paneObj);
        this.setActivePane(paneObj);

        this.initDrag(pane, paneObj);
        this.initResize(pane, paneObj);
        this.initControls(pane, paneObj);
        this.initWebviewEvents(paneObj);

        pane.addEventListener('mousedown', () => {
            this.setActivePane(paneObj);
        });

        return paneObj;
    }

    setActivePane(paneObj) {
        this.activePane = paneObj;
        this.panes.forEach(p => p.element.classList.remove('active'));
        paneObj.element.classList.add('active');
        paneObj.element.style.zIndex = ++this.zIndexCounter;
        
        const event = new CustomEvent('pane-focused', { detail: { pane: paneObj } });
        document.dispatchEvent(event);
    }
    
    getActivePane() {
        return this.activePane;
    }

    closePane(id) {
        const index = this.panes.findIndex(p => p.id === id);
        if (index > -1) {
            const paneObj = this.panes[index];
            paneObj.element.remove();
            this.panes.splice(index, 1);
            
            if (this.activePane && this.activePane.id === id) {
                this.activePane = this.panes.length > 0 ? this.panes[this.panes.length - 1] : null;
                if (this.activePane) this.setActivePane(this.activePane);
            }
        }
    }

    initControls(pane, paneObj) {
        const closeBtn = pane.querySelector('.pane-btn.close');
        // Maximize implementation can be added here
        
        closeBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            this.closePane(paneObj.id);
        });
    }

    initWebviewEvents(paneObj) {
        const webview = paneObj.webview;
        const titleEl = paneObj.element.querySelector('.pane-title');

        const updateTitle = () => {
             titleEl.textContent = webview.getTitle();
             this.emitUpdate(paneObj);
        };

        webview.addEventListener('dom-ready', updateTitle);
        webview.addEventListener('did-navigate', updateTitle);
        webview.addEventListener('page-title-updated', (e) => {
            titleEl.textContent = e.title;
        });
    }
    
    emitUpdate(paneObj) {
        const event = new CustomEvent('pane-updated', { detail: { pane: paneObj } });
        document.dispatchEvent(event);
    }

    // Drag Logic
    initDrag(pane, paneObj) {
        const header = pane.querySelector('.pane-header');
        header.addEventListener('mousedown', (e) => {
            if (e.target.closest('.pane-controls')) return;
            
            this.setActivePane(paneObj);
            
            this.dragState = {
                pane: pane,
                startX: e.clientX,
                startY: e.clientY,
                startLeft: pane.offsetLeft,
                startTop: pane.offsetTop
            };
            
            this.addOverlay();
            document.addEventListener('mousemove', this.handleDragMove);
            document.addEventListener('mouseup', this.handleDragEnd);
        });
    }

    handleDragMove(e) {
        if (!this.dragState) return;

        const { pane, startX, startY, startLeft, startTop } = this.dragState;
        const dx = e.clientX - startX;
        const dy = e.clientY - startY;

        let newLeft = startLeft + dx;
        let newTop = startTop + dy;

        // Snap Logic
        const containerWidth = this.container.clientWidth;
        const containerHeight = this.container.clientHeight;

        if (Math.abs(newLeft) < this.snapThreshold) newLeft = 0;
        if (Math.abs(newTop) < this.snapThreshold) newTop = 0;
        if (Math.abs(newLeft + pane.offsetWidth - containerWidth) < this.snapThreshold)
            newLeft = containerWidth - pane.offsetWidth;
        if (Math.abs(newTop + pane.offsetHeight - containerHeight) < this.snapThreshold)
            newTop = containerHeight - pane.offsetHeight;

        pane.style.left = newLeft + 'px';
        pane.style.top = newTop + 'px';
    }

    handleDragEnd() {
        this.dragState = null;
        this.removeOverlay();
        document.removeEventListener('mousemove', this.handleDragMove);
        document.removeEventListener('mouseup', this.handleDragEnd);
    }

    // Resize Logic
    initResize(pane, paneObj) {
        const handles = pane.querySelectorAll('.resize-handle');
        handles.forEach(handle => {
            handle.addEventListener('mousedown', (e) => {
                e.stopPropagation();
                this.setActivePane(paneObj);
                
                this.resizeState = {
                    pane: pane,
                    handleType: handle.className.split(' ')[1],
                    startX: e.clientX,
                    startY: e.clientY,
                    startWidth: pane.offsetWidth,
                    startHeight: pane.offsetHeight,
                    startLeft: pane.offsetLeft,
                    startTop: pane.offsetTop
                };

                this.addOverlay();
                document.addEventListener('mousemove', this.handleResizeMove);
                document.addEventListener('mouseup', this.handleResizeEnd);
            });
        });
    }

    handleResizeMove(e) {
        if (!this.resizeState) return;

        const { pane, handleType, startX, startY, startWidth, startHeight, startLeft, startTop } = this.resizeState;
        const dx = e.clientX - startX;
        const dy = e.clientY - startY;

        // Minimum dimensions
        const minW = 200;
        const minH = 150;

        let newW = startWidth;
        let newH = startHeight;
        let newL = startLeft;
        let newT = startTop;

        if (handleType.includes('e')) {
            newW = Math.max(minW, startWidth + dx);
        }
        if (handleType.includes('s')) {
            newH = Math.max(minH, startHeight + dy);
        }
        if (handleType.includes('w')) {
            newW = Math.max(minW, startWidth - dx);
            newL = startLeft + (startWidth - newW);
        }
        if (handleType.includes('n')) {
            newH = Math.max(minH, startHeight - dy);
            newT = startTop + (startHeight - newH);
        }

        pane.style.width = newW + 'px';
        pane.style.height = newH + 'px';
        pane.style.left = newL + 'px';
        pane.style.top = newT + 'px';
    }

    handleResizeEnd() {
        this.resizeState = null;
        this.removeOverlay();
        document.removeEventListener('mousemove', this.handleResizeMove);
        document.removeEventListener('mouseup', this.handleResizeEnd);
    }
    
    addOverlay() {
        if (!document.getElementById('drag-overlay')) {
            const overlay = document.createElement('div');
            overlay.id = 'drag-overlay';
            overlay.style.position = 'fixed';
            overlay.style.top = '0';
            overlay.style.left = '0';
            overlay.style.width = '100%';
            overlay.style.height = '100%';
            overlay.style.zIndex = '9999';
            overlay.style.cursor = 'move'; // Or resize based on context, but move is fine
            overlay.style.background = 'transparent';
            document.body.appendChild(overlay);
        }
    }
    
    removeOverlay() {
        const overlay = document.getElementById('drag-overlay');
        if (overlay) overlay.remove();
    }
}
