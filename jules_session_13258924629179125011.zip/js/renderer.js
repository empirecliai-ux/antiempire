const { ipcRenderer } = require('electron');

// Global references
const addressBar = document.getElementById('address-bar');
const loadingScreen = document.getElementById('loading-screen');
const novaBtn = document.getElementById('nova-btn');
const voiceOverlay = document.getElementById('voice-overlay');
const backBtn = document.getElementById('back-btn');
const forwardBtn = document.getElementById('forward-btn');
const refreshBtn = document.getElementById('refresh-btn');
const browserContent = document.getElementById('browser-content');

// Empire Navigator Core
class EmpireNavigatorRenderer {
    constructor() {
        this.isListening = false;
        this.recognition = null;
        this.windowManager = null; // Will be initialized after DOM loaded
        
        this.setupWindowControls();
        this.initializeVoiceRecognition();
        this.setupEventListeners();
        
        // Initialize Window Manager
        this.windowManager = new WindowManager(browserContent);
        
        // Open default pane
        this.windowManager.createPane('https://www.google.com');
        
        this.hideLoadingScreen();
    }

    setupWindowControls() {
        document.getElementById('win-minimize').addEventListener('click', () => {
            ipcRenderer.send('window-minimize');
        });
        document.getElementById('win-maximize').addEventListener('click', () => {
            ipcRenderer.send('window-maximize');
        });
        document.getElementById('win-close').addEventListener('click', () => {
            ipcRenderer.send('window-close');
        });
    }

    initializeVoiceRecognition() {
        if ('webkitSpeechRecognition' in window) {
            this.recognition = new webkitSpeechRecognition();
            this.recognition.continuous = false;
            this.recognition.interimResults = false;
            this.recognition.lang = 'en-US';

            this.recognition.onstart = () => {
                console.log('🎤 Nova listening...');
                this.isListening = true;
                novaBtn.classList.add('listening');
                voiceOverlay.classList.add('active');
            };

            this.recognition.onresult = (event) => {
                const command = event.results[0][0].transcript;
                console.log('🗣️ Voice Command:', command);
                this.handleVoiceCommand(command);
            };

            this.recognition.onend = () => {
                this.isListening = false;
                novaBtn.classList.remove('listening');
                voiceOverlay.classList.remove('active');
            };

            this.recognition.onerror = (event) => {
                console.error('Voice recognition error:', event.error);
                this.isListening = false;
                novaBtn.classList.remove('listening');
                voiceOverlay.classList.remove('active');
            };
        }
    }

    setupEventListeners() {
        // Empire status updates
        setInterval(() => {
            this.updateEmpireStatus();
        }, 5000);
        
        // Address bar
        addressBar.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                const url = this.formatUrl(addressBar.value);
                const activePane = this.windowManager.getActivePane();
                if (activePane) {
                    activePane.loadURL(url);
                } else {
                    this.windowManager.createPane(url);
                }
            }
        });

        // Navigation buttons
        backBtn.addEventListener('click', () => {
            const activePane = this.windowManager.getActivePane();
            if (activePane) activePane.goBack();
        });

        forwardBtn.addEventListener('click', () => {
            const activePane = this.windowManager.getActivePane();
            if (activePane) activePane.goForward();
        });

        refreshBtn.addEventListener('click', () => {
            const activePane = this.windowManager.getActivePane();
            if (activePane) activePane.reload();
        });

        // Nova button
        novaBtn.addEventListener('click', () => this.activateNova());

        // Societas Toggle
        document.getElementById('societas-toggle').addEventListener('click', () => {
            this.toggleSocietas();
        });

        // Listen for pane updates to update UI (address bar, buttons)
        document.addEventListener('pane-focused', (e) => {
            const pane = e.detail.pane;
            this.updateInterface(pane);
        });
        
        document.addEventListener('pane-updated', (e) => {
             const pane = e.detail.pane;
             if (pane === this.windowManager.getActivePane()) {
                 this.updateInterface(pane);
             }
        });
    }
    
    updateInterface(pane) {
        if (!pane) return;
        addressBar.value = pane.getURL();
        backBtn.disabled = !pane.canGoBack();
        forwardBtn.disabled = !pane.canGoForward();
    }

    hideLoadingScreen() {
        setTimeout(() => {
            loadingScreen.style.opacity = '0';
            setTimeout(() => {
                loadingScreen.style.display = 'none';
            }, 500);
        }, 3000);
    }

    handleVoiceCommand(command) {
        const cmd = command.toLowerCase();
        
        // Update voice overlay
        document.getElementById('voice-command-text').textContent = `"${command}"`;
        
        // Send to main process
        ipcRenderer.invoke('empire-command', command);
        
        const activePane = this.windowManager.getActivePane();

        // Handle locally
        if (cmd.includes('navigate to') || cmd.includes('go to')) {
            const site = cmd.replace(/navigate to|go to/g, '').trim();
            const url = this.formatUrl(site);
            if (activePane) {
                activePane.loadURL(url);
            } else {
                this.windowManager.createPane(url);
            }
        } else if (cmd.includes('new tab') || cmd.includes('new window')) {
            this.windowManager.createPane('about:blank');
        } else if (cmd.includes('refresh') || cmd.includes('reload')) {
            if (activePane) activePane.reload();
        } else if (cmd.includes('back')) {
            if (activePane) activePane.goBack();
        } else if (cmd.includes('forward')) {
            if (activePane) activePane.goForward();
        } else if (cmd.includes('close tab') || cmd.includes('close window')) {
            if (activePane) this.windowManager.closePane(activePane.id);
        }
    }

    formatUrl(site) {
        let url = site;
        if (!url.includes('http')) {
            if (url.includes('.') && !url.includes(' ')) {
                url = `https://${url}`;
            } else {
                const shortcuts = {
                    'github': 'https://github.com',
                    'gmail': 'https://gmail.com',
                    'teams': 'https://teams.microsoft.com',
                    'discord': 'https://discord.com',
                    'youtube': 'https://youtube.com'
                };
                url = shortcuts[url.toLowerCase()] || `https://www.google.com/search?q=${encodeURIComponent(url)}`;
            }
        }
        return url;
    }

    async updateEmpireStatus() {
        try {
            const status = await ipcRenderer.invoke('get-empire-status');
            // Update agent count and status indicators
            document.getElementById('agent-count').textContent = '47 AGENTS';
        } catch (error) {
            console.error('Failed to update Empire status:', error);
        }
    }

    activateNova() {
        if (this.recognition && !this.isListening) {
            this.recognition.start();
        }
    }

    toggleSocietas() {
        ipcRenderer.invoke('empire-command', 'show societas');
    }
}

// Initialize on load
window.onload = () => {
    window.empireNavigator = new EmpireNavigatorRenderer();
    
    // Empire Easter Eggs
    document.addEventListener('keydown', (event) => {
        // Ctrl+Shift+E = Empire Command Palette
        if (event.ctrlKey && event.shiftKey && event.key === 'E') {
            window.empireNavigator.activateNova();
        }
        
        // Ctrl+Shift+S = Show Societas
        if (event.ctrlKey && event.shiftKey && event.key === 'S') {
            window.empireNavigator.toggleSocietas();
        }
    });

    console.log('🏛️ Empire Navigator initialized');
};
