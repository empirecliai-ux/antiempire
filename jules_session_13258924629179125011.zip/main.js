const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');

function createWindow() {
    const mainWindow = new BrowserWindow({
        width: 1200,
        height: 800,
        frame: false, // Frameless window
        webPreferences: {
            nodeIntegration: true,
            contextIsolation: false,
            webviewTag: true, // Enable <webview> tag
        }
    });

    mainWindow.loadFile('index.html');

    // IPC listeners for window controls
    ipcMain.on('window-minimize', () => {
        mainWindow.minimize();
    });

    ipcMain.on('window-maximize', () => {
        if (mainWindow.isMaximized()) {
            mainWindow.unmaximize();
        } else {
            mainWindow.maximize();
        }
    });

    ipcMain.on('window-close', () => {
        mainWindow.close();
    });

    // Handle Empire specific commands if needed
    ipcMain.handle('empire-command', async (event, command) => {
        console.log('Received empire command:', command);
        return { success: true };
    });

    ipcMain.handle('get-empire-status', async () => {
        return { status: 'online', agents: 47 };
    });
}

app.whenReady().then(() => {
    createWindow();

    app.on('activate', function () {
        if (BrowserWindow.getAllWindows().length === 0) createWindow();
    });
});

app.on('window-all-closed', function () {
    if (process.platform !== 'darwin') app.quit();
});
