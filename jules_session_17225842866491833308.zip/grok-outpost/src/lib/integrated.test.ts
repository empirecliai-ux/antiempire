
import axios from 'axios';
import assert from 'node:assert';

// The code from api.ts (slightly modified for single file)
const XAI_API_URL = 'https://api.x.ai/v1/chat/completions';

async function sendMessageToGrok(
  messages: any[],
  apiKey: string,
  model: string = 'grok-beta'
): Promise<string> {
  try {
    const formattedMessages = messages.map(msg => ({
      role: msg.role,
      content: msg.content
    }));

    const response = await axios.post(
      XAI_API_URL,
      {
        model: model,
        messages: formattedMessages,
        stream: false 
      },
      {
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json'
        }
      }
    );

    // Broken code: no validation
    return response.data.choices[0].message.content;
  } catch (error: any) {
    if (error.response) {
      throw new Error(`API Error: ${error.response.status} - ${JSON.stringify(error.response.data)}`);
    }
    throw new Error(error.message || 'Unknown error occurred');
  }
}

async function runTests() {
  console.log('Running tests for sendMessageToGrok...');

  const apiKey = 'test-api-key';
  const messages = [{ role: 'user', content: 'Hello' }];

  // Test Case 1: Valid Response
  (axios as any).__setMockPost(() => Promise.resolve({
    data: {
      choices: [
        {
          message: {
            content: 'Hi there!'
          }
        }
      ]
    }
  }));

  const response1 = await sendMessageToGrok(messages, apiKey);
  assert.strictEqual(response1, 'Hi there!', 'Should return the correct content');
  console.log('✅ Test Case 1: Valid Response passed');

  // Test Case 2: Missing response.data
  (axios as any).__setMockPost(() => Promise.resolve({}));
  try {
    await sendMessageToGrok(messages, apiKey);
    assert.fail('Should have thrown an error for missing response.data');
  } catch (error: any) {
    assert.strictEqual(error.message, 'Invalid response structure from xAI API');
    console.log('✅ Test Case 2: Missing response.data passed');
  }

  // Test Case 3: Missing response.data.choices
  (axios as any).__setMockPost(() => Promise.resolve({ data: {} }));
  try {
    await sendMessageToGrok(messages, apiKey);
    assert.fail('Should have thrown an error for missing response.data.choices');
  } catch (error: any) {
    assert.strictEqual(error.message, 'Invalid response structure from xAI API');
    console.log('✅ Test Case 3: Missing response.data.choices passed');
  }

  // Test Case 4: Empty response.data.choices
  (axios as any).__setMockPost(() => Promise.resolve({ data: { choices: [] } }));
  try {
    await sendMessageToGrok(messages, apiKey);
    assert.fail('Should have thrown an error for empty choices array');
  } catch (error: any) {
    assert.strictEqual(error.message, 'Invalid response structure from xAI API');
    console.log('✅ Test Case 4: Empty response.data.choices passed');
  }
}

runTests().catch(err => {
  console.error('Tests failed:', err);
  process.exit(1);
});
