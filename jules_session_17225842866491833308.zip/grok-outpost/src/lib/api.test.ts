
import { sendMessageToGrok } from './api.js';
import axios from 'axios';
import assert from 'node:assert';

async function runTests() {
  console.log('Running tests for sendMessageToGrok...');

  const apiKey = 'test-api-key';
  const messages = [{ role: 'user', content: 'Hello' }];

  // Test Case 1: Valid Response
  (axios as any).__setMockPost(() => Promise.resolve({
    data: {
      choices: [
        {
          message: {
            content: 'Hi there!'
          }
        }
      ]
    }
  }));

  const response1 = await sendMessageToGrok(messages, apiKey);
  assert.strictEqual(response1, 'Hi there!', 'Should return the correct content');
  console.log('✅ Test Case 1: Valid Response passed');

  // Test Case 2: Missing response.data
  (axios as any).__setMockPost(() => Promise.resolve({}));
  try {
    await sendMessageToGrok(messages, apiKey);
    assert.fail('Should have thrown an error for missing response.data');
  } catch (error: any) {
    assert.strictEqual(error.message, 'Invalid response structure from xAI API');
    console.log('✅ Test Case 2: Missing response.data passed');
  }

  // Test Case 3: Missing response.data.choices
  (axios as any).__setMockPost(() => Promise.resolve({ data: {} }));
  try {
    await sendMessageToGrok(messages, apiKey);
    assert.fail('Should have thrown an error for missing response.data.choices');
  } catch (error: any) {
    assert.strictEqual(error.message, 'Invalid response structure from xAI API');
    console.log('✅ Test Case 3: Missing response.data.choices passed');
  }

  // Test Case 4: Empty response.data.choices
  (axios as any).__setMockPost(() => Promise.resolve({ data: { choices: [] } }));
  try {
    await sendMessageToGrok(messages, apiKey);
    assert.fail('Should have thrown an error for empty choices array');
  } catch (error: any) {
    assert.strictEqual(error.message, 'Invalid response structure from xAI API');
    console.log('✅ Test Case 4: Empty response.data.choices passed');
  }

  // Test Case 5: Missing content in choice
  (axios as any).__setMockPost(() => Promise.resolve({
    data: {
      choices: [
        {
          message: {}
        }
      ]
    }
  }));
  // Current implementation doesn't check for message.content explicitly, 
  // it just returns it, so it might return undefined.
  // Let's see what happens.
  const response5 = await sendMessageToGrok(messages, apiKey);
  console.log('Test Case 5 returned:', response5);
  // It returns undefined because of response.data.choices[0].message.content
  
  // Actually, the current code is:
  // if (response.data && response.data.choices && response.data.choices.length > 0) {
  //   return response.data.choices[0].message.content;
  // }
  
  // If message or content is missing, it will return undefined. 
  // Maybe we should improve the validation to catch this too?
}

runTests().catch(err => {
  console.error('Tests failed:', err);
  process.exit(1);
});
