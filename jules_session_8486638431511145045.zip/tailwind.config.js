/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {},
  },
  safelist: [
    { pattern: /(bg|text|border)-(green|cyan|red)-(400|500|600|900)/ },
    { pattern: /shadow-\[(.*)\]/ },
  ],
  plugins: [],
}
