export interface Theme {
  id: string;
  name: string;
  colors: {
    primary: string; // The main glow color (e.g., green-500)
    secondary: string; // Secondary accent (e.g., green-900)
    background: string; // Background color (e.g., black)
    text: string; // Text color (e.g., green-400)
    border: string; // Border color
    shadow: string; // Shadow color (e.g., #00ff00)
  };
  styles: {
    border: string; // Tailwind class for border color
    text: string; // Tailwind class for text color
    bg: string; // Tailwind class for background
    glow: string; // Tailwind class for shadow/glow
    
    // New specific classes to avoid dynamic construction issues
    bgPrimary: string;
    bgSecondary: string;
    textSecondary: string;
  };
}
