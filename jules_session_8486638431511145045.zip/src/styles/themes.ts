import { Theme } from '../types/theme';

export const THEMES: Record<string, Theme> = {
  empire: {
    id: 'empire',
    name: 'Empire',
    colors: {
      primary: 'green-500',
      secondary: 'green-900',
      background: 'black',
      text: 'green-400',
      border: 'green-500',
      shadow: '#00ff00',
    },
    styles: {
      border: 'border-green-500',
      text: 'text-green-400',
      bg: 'bg-black',
      glow: 'shadow-[0_0_10px_#00ff00]',
      bgPrimary: 'bg-green-500',
      bgSecondary: 'bg-green-900',
      textSecondary: 'text-green-900',
    },
  },
  cyber: {
    id: 'cyber',
    name: 'Cyber',
    colors: {
      primary: 'cyan-400',
      secondary: 'cyan-900',
      background: 'slate-950',
      text: 'cyan-300',
      border: 'cyan-400',
      shadow: '#00ffff',
    },
    styles: {
      border: 'border-cyan-400',
      text: 'text-cyan-300',
      bg: 'bg-slate-950',
      glow: 'shadow-[0_0_15px_#00ffff]',
      bgPrimary: 'bg-cyan-400',
      bgSecondary: 'bg-cyan-900',
      textSecondary: 'text-cyan-900',
    },
  },
  crimson: {
    id: 'crimson',
    name: 'Crimson',
    colors: {
      primary: 'red-600',
      secondary: 'red-900',
      background: 'neutral-950',
      text: 'red-500',
      border: 'red-600',
      shadow: '#ff0000',
    },
    styles: {
      border: 'border-red-600',
      text: 'text-red-500',
      bg: 'bg-neutral-950',
      glow: 'shadow-[0_0_12px_#ff0000]',
      bgPrimary: 'bg-red-600',
      bgSecondary: 'bg-red-900',
      textSecondary: 'text-red-900',
    },
  },
};

export const DEFAULT_THEME = THEMES.empire;
