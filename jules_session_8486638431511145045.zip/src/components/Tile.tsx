import React, { useRef } from 'react'
import Draggable from 'react-draggable'
import { ResizableBox } from 'react-resizable'
import { motion } from 'framer-motion'
import { QRCodeSVG } from 'qrcode.react'
import { Maximize2, Monitor, Lock, HardDrive, Cpu, Terminal, Sparkles, Wifi, X } from 'lucide-react'
import clsx from 'clsx'
import { twMerge } from 'tailwind-merge'
import { Theme } from '../types/theme'

import 'react-resizable/css/styles.css'

export type TileCategory = 'Network' | 'Personal' | 'Security' | 'Storage' | 'Hardware' | 'AI Core' | 'Chaos'

export interface TileProps {
  id: string
  title: string
  status: string
  category: TileCategory
  x: number
  y: number
  w: number
  h: number
  expanded: boolean
  onExpand: (id: string) => void
  onCollapse: (id: string) => void
  content: React.ReactNode
  onDragStart?: () => void
  onDragStop?: () => void
  theme: Theme
}

const CategoryIcon = ({ category }: { category: TileCategory }) => {
  switch (category) {
    case 'Network': return <Wifi className="w-4 h-4" />
    case 'Personal': return <Monitor className="w-4 h-4" />
    case 'Security': return <Lock className="w-4 h-4" />
    case 'Storage': return <HardDrive className="w-4 h-4" />
    case 'Hardware': return <Cpu className="w-4 h-4" />
    case 'AI Core': return <Terminal className="w-4 h-4" />
    case 'Chaos': return <Sparkles className="w-4 h-4" />
    default: return <Monitor className="w-4 h-4" />
  }
}

export function Tile({ id, title, status, category, x, y, w, h, expanded, onExpand, onCollapse, content, onDragStart, onDragStop, theme }: TileProps) {
  const nodeRef = useRef(null)
  
  // Handling expanded state: full screen overlay
  if (expanded) {
    return (
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.9 }}
        className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-8"
      >
        <div 
            className={`w-full h-full max-w-4xl max-h-[80vh] ${theme.styles.bg} border ${theme.styles.border} flex flex-col relative overflow-hidden`}
            style={{ boxShadow: `0 0 20px ${theme.colors.shadow}` }}
        >
             {/* Header */}
            <div className={`flex items-center justify-between p-4 border-b ${theme.styles.border} ${theme.styles.bgSecondary} bg-opacity-10`}>
                <div className={`flex items-center gap-3 ${theme.styles.text}`}>
                    <CategoryIcon category={category} />
                    <span className="font-mono text-lg font-bold tracking-wider uppercase">{title}</span>
                </div>
                <div className="flex items-center gap-4">
                    <span className={`font-mono text-xs ${theme.styles.text} animate-pulse`}>{status}</span>
                    <button onClick={() => onCollapse(id)} className={`${theme.styles.text} hover:opacity-80`}>
                        <X className="w-6 h-6" />
                    </button>
                </div>
            </div>
            
            {/* Content */}
            <div className={`flex-1 p-6 overflow-auto font-mono text-white/80`}>
                {content}
            </div>

            {/* Decor */}
            <div className={`absolute bottom-0 right-0 p-2 text-[10px] ${theme.styles.text} font-mono pointer-events-none opacity-50`}>
                {id} // EXPANDED_VIEW
            </div>
        </div>
      </motion.div>
    )
  }

  // Normal draggable tile
  return (
    <Draggable
      handle=".drag-handle"
      defaultPosition={{ x, y }}
      grid={[20, 20]}
      scale={1}
      onStart={onDragStart}
      onStop={onDragStop}
      nodeRef={nodeRef}
    >
      <div ref={nodeRef} className="absolute inline-block">
        <ResizableBox
          width={w}
          height={h}
          minConstraints={[150, 150]}
          maxConstraints={[600, 600]}
          resizeHandles={['se']}
          handle={(resizeHandle: any, ref: any) => (
            <span
              className={`custom-handle custom-handle-${resizeHandle} absolute bottom-0 right-0 w-4 h-4 cursor-se-resize ${theme.styles.bgPrimary} bg-opacity-20 hover:bg-opacity-50 clip-path-triangle`}
              ref={ref}
            />
          )}
        >
          <motion.div 
            className={twMerge(
                `w-full h-full ${theme.styles.bg} border ${theme.styles.border} border-opacity-50 hover:border-opacity-100 transition-all duration-200 flex flex-col overflow-hidden group`,
                "relative backdrop-blur-md bg-opacity-90"
            )}
            style={{ boxShadow: `0 0 5px ${theme.colors.shadow}33` }} // 33 for ~20% opacity
            whileHover={{ 
                scale: 1.02,
                boxShadow: `0 0 15px ${theme.colors.shadow}66` // 66 for ~40% opacity
            }}
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
          >
            {/* Header / Drag Handle */}
            <div className={`drag-handle h-8 ${theme.styles.bgSecondary} bg-opacity-20 border-b ${theme.styles.border} border-opacity-30 flex items-center justify-between px-2 cursor-move select-none hover:bg-opacity-30 transition-colors`}>
                <div className={`flex items-center gap-2 ${theme.styles.text}`}>
                    <CategoryIcon category={category} />
                    <span className="font-mono text-xs font-bold uppercase truncate max-w-[100px]">{title}</span>
                </div>
                <div className="flex items-center gap-2">
                    <div 
                        className={clsx("w-2 h-2 rounded-full animate-pulse")} 
                        style={{ backgroundColor: status.includes("Connected") ? theme.colors.primary : '#eab308' }}
                    />
                </div>
            </div>

            {/* Body */}
            <div className="flex-1 p-3 flex flex-col gap-2 relative">
                {/* QR Code Overlay (faded in background or explicit) */}
                <div className="absolute top-2 right-2 opacity-20 group-hover:opacity-40 transition-opacity pointer-events-none">
                     <QRCodeSVG value={`thirdos://${category}/${id}`} size={40} fgColor={theme.colors.shadow} bgColor="transparent" />
                </div>

                {/* Status Text */}
                <div className="mt-auto">
                    <div className={`font-mono text-[10px] ${theme.styles.text} opacity-70 uppercase mb-1`}>STATUS</div>
                    <div className={`font-mono text-xs ${theme.styles.text} truncate animate-pulse`}>
                        {status}
                    </div>
                </div>

                {/* Expand Button (appears on hover) */}
                <button 
                    onClick={() => onExpand(id)}
                    className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity bg-black/80 border ${theme.styles.border} p-2 rounded-full ${theme.styles.text} hover:scale-110`}
                >
                    <Maximize2 className="w-5 h-5" />
                </button>
            </div>

            {/* Corner decorations */}
            <div className={`absolute top-0 left-0 w-2 h-2 border-t border-l ${theme.styles.border}`} />
            <div className={`absolute top-0 right-0 w-2 h-2 border-t border-r ${theme.styles.border}`} />
            <div className={`absolute bottom-0 left-0 w-2 h-2 border-b border-l ${theme.styles.border}`} />

          </motion.div>
        </ResizableBox>
      </div>
    </Draggable>
  )
}
