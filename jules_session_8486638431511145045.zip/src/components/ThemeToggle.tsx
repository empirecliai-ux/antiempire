import React from 'react';
import { Palette } from 'lucide-react';
import { Theme } from '../types/theme';
import { THEMES } from '../styles/themes';

interface ThemeToggleProps {
  currentTheme: Theme;
  onThemeChange: (themeId: string) => void;
}

export function ThemeToggle({ currentTheme, onThemeChange }: ThemeToggleProps) {
  const [isOpen, setIsOpen] = React.useState(false);

  const toggleOpen = () => setIsOpen(!isOpen);

  const handleThemeSelect = (themeId: string) => {
    onThemeChange(themeId);
    setIsOpen(false);
  };

  return (
    <div className="fixed bottom-4 left-4 z-50">
      <div className={`relative ${isOpen ? 'mb-2' : ''}`}>
        {isOpen && (
          <div className={`absolute bottom-full left-0 mb-2 flex flex-col gap-2 p-2 rounded border backdrop-blur-md ${currentTheme.styles.bg} ${currentTheme.styles.border}`}>
            {Object.values(THEMES).map((theme) => (
              <button
                key={theme.id}
                onClick={() => handleThemeSelect(theme.id)}
                className={`flex items-center gap-2 px-3 py-1 rounded hover:bg-white/10 transition-colors text-xs font-mono uppercase ${
                  currentTheme.id === theme.id ? 'bg-white/20' : ''
                } ${theme.styles.text}`}
              >
                <div className={`w-3 h-3 rounded-full bg-${theme.colors.primary}`} style={{ boxShadow: `0 0 5px ${theme.colors.shadow}` }} />
                {theme.name}
              </button>
            ))}
          </div>
        )}
        <button
          onClick={toggleOpen}
          className={`p-3 rounded-full border backdrop-blur-md transition-all duration-300 hover:scale-110 ${currentTheme.styles.bg} ${currentTheme.styles.border} ${currentTheme.styles.text} ${currentTheme.styles.glow}`}
        >
          <Palette className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
}
