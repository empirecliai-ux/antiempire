import { useEffect } from 'react'
import { motion } from 'framer-motion'
import { Swords } from 'lucide-react'

export function EmpireOverlay({ onClose }: { onClose: () => void }) {
  useEffect(() => {
    const timer = setTimeout(onClose, 3000)
    return () => clearTimeout(timer)
  }, [onClose])

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-black/90 pointer-events-none"
    >
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1.2, opacity: 1 }}
        transition={{ duration: 0.5, ease: "backOut" }}
        className="text-green-500 flex flex-col items-center gap-8"
      >
        <div className="relative">
             <Swords className="w-48 h-48 animate-pulse drop-shadow-[0_0_30px_#00ff00]" />
             <div className="absolute inset-0 border-4 border-green-500 rounded-full animate-ping opacity-20" />
        </div>
        
        <h1 className="text-6xl font-black tracking-widest uppercase font-mono text-center drop-shadow-[0_0_20px_#00ff00]">
          Legion Stands Ready
        </h1>
        
        <p className="text-green-800 font-mono text-xl tracking-[1em] animate-pulse">
          FOR THE EMPIRE
        </p>
      </motion.div>
      
      {/* Runes background effect */}
      <div className="absolute inset-0 opacity-10 font-mono text-green-900 text-xs break-all overflow-hidden -z-10">
        {Array(5000).fill(0).map(() => Math.random() > 0.5 ? '1' : '0').join('')}
      </div>
    </motion.div>
  )
}
