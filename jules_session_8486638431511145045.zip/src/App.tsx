import { useState, useEffect, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Theme } from './types/theme'
import { THEMES, DEFAULT_THEME } from './styles/themes'
import { ThemeToggle } from './components/ThemeToggle'
import { Tile } from './components/Tile' 
import { INITIAL_TILES, TileData } from './data/tiles'
import { EmpireOverlay } from './components/EmpireOverlay'

const getMockStatus = (tile: TileData) => {
    const networkStatuses = ['Connected - 1Gbps', 'Ping: 14ms', 'Scanning...', 'Tailnet: Syncing', 'Upload: 45MB/s']
    const hardwareStatuses = ['CPU Mood: Anxious', 'CPU Mood: Zen', 'Fan: 2400RPM', 'RAM: 64% Used', 'Temp: 65°C']
    const aiStatuses = ['Dreaming...', 'Training: Epoch 4', 'Thinking...', 'Idle', 'Generating Memes']
    const securityStatuses = ['Guardian: Active', 'Scanning Ports...', 'No Threats', 'Firewall: Solid']
    
    const pick = (arr: string[]) => arr[Math.floor(Math.random() * arr.length)]

    switch(tile.category) {
        case 'Network': return pick(networkStatuses)
        case 'Hardware': return pick(hardwareStatuses)
        case 'AI Core': return pick(aiStatuses)
        case 'Security': return pick(securityStatuses)
        default: return tile.status
    }
}

function App() {
  const [theme, setTheme] = useState<Theme>(DEFAULT_THEME)
  const [tiles, setTiles] = useState<TileData[]>(INITIAL_TILES)
  const [expandedId, setExpandedId] = useState<string | null>(null)
  const [showEmpire, setShowEmpire] = useState(false)
  const [chaosFlash, setChaosFlash] = useState(false)
  
  const keyBuffer = useRef<string>("")

  const handleThemeChange = (themeId: string) => {
    const newTheme = THEMES[themeId]
    if (newTheme) {
      setTheme(newTheme)
    }
  }

  // 24/7 Sync Simulation
  useEffect(() => {
    const interval = setInterval(() => {
      setTiles(currentTiles => 
        currentTiles.map(tile => {
            if (Math.random() > 0.85) {
                return { ...tile, status: getMockStatus(tile) }
            }
            return tile
        })
      )
    }, 2000)
    return () => clearInterval(interval)
  }, [])

  // Empire Command Listener
  useEffect(() => {
      const handleKeyDown = (e: KeyboardEvent) => {
          keyBuffer.current = (keyBuffer.current + e.key).slice(-20) // Keep last 20 chars
          if (keyBuffer.current.toLowerCase().includes("fortheempire")) {
              setShowEmpire(true)
              keyBuffer.current = "" // Reset
              // Force Empire theme?
              setTheme(THEMES.empire)
          }
      }
      window.addEventListener('keydown', handleKeyDown)
      return () => window.removeEventListener('keydown', handleKeyDown)
  }, [])

  const handleDragStart = (tile: TileData) => {
      if (tile.category === 'Chaos') {
          setChaosFlash(true)
          setTimeout(() => setChaosFlash(false), 200)
      }
  }

  return (
    <div className={`w-screen h-screen ${theme.styles.bg} overflow-hidden relative selection:bg-green-900 selection:text-green-200 transition-colors duration-500`}>
        <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1 }}
            className="absolute inset-0 pointer-events-none"
            style={{
                backgroundImage: `radial-gradient(circle at center, ${theme.colors.secondary} 0%, ${theme.colors.background} 100%)`,
                opacity: 0.2
            }}
        />
        
        {/* Chaos Flash Overlay */}
        <AnimatePresence>
            {chaosFlash && (
                <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.1 }}
                    className="fixed inset-0 z-50 pointer-events-none mix-blend-screen bg-gradient-to-br from-red-500 via-green-500 to-blue-500 opacity-50"
                />
            )}
        </AnimatePresence>

        {/* Empire Overlay */}
        <AnimatePresence>
            {showEmpire && (
                <EmpireOverlay onClose={() => setShowEmpire(false)} />
            )}
        </AnimatePresence>

        {/* Tiles */}
        <AnimatePresence>
            {tiles.map(tile => (
                <Tile 
                    key={tile.id}
                    {...tile}
                    theme={theme}
                    expanded={expandedId === tile.id}
                    onExpand={() => setExpandedId(tile.id)}
                    onCollapse={() => setExpandedId(null)}
                    content={<div className="whitespace-pre-wrap">{tile.content}</div>}
                    onDragStart={() => handleDragStart(tile)}
                />
            ))}
        </AnimatePresence>
        
        <ThemeToggle currentTheme={theme} onThemeChange={handleThemeChange} />

        <div className={`absolute bottom-4 right-4 text-xs font-mono pointer-events-none select-none ${theme.styles.text}`}>
            System: ONLINE
        </div>
    </div>
  )
}

export default App
