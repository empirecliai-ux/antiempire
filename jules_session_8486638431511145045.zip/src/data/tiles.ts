import { TileCategory } from '../components/Tile';

export interface TileData {
  id: string;
  title: string;
  status: string;
  category: TileCategory;
  x: number;
  y: number;
  w: number;
  h: number;
  content: string; // Placeholder for now, could be ReactNode
}

export const INITIAL_TILES: TileData[] = [
  {
    id: 'net-01',
    title: 'Network',
    status: 'Connected - 1Gbps',
    category: 'Network',
    x: 50,
    y: 50,
    w: 200,
    h: 150,
    content: 'WiFi: Empire_Secure_5G\nEthernet: Active\nTailnet: Connected (3 peers)\n\n> Booting from IP: 192.168.1.100...',
  },
  {
    id: 'pers-01',
    title: 'Personal',
    status: 'Derek – Docking in 3…',
    category: 'Personal',
    x: 300,
    y: 50,
    w: 200,
    h: 150,
    content: 'Identity: Verified\nTrust Pulse: 98%\n\nRitual Counter: 42\nNext Sync: 04:00 AM',
  },
  {
    id: 'sec-01',
    title: 'Security',
    status: 'Guardian Lock: ACTIVE',
    category: 'Security',
    x: 550,
    y: 50,
    w: 200,
    h: 150,
    content: 'Perimeter: Secure\nTamper Self-Brick: ARMED\nMirror Reflection: OFF',
  },
  {
    id: 'store-01',
    title: 'Storage',
    status: 'S:\\ Mounted',
    category: 'Storage',
    x: 50,
    y: 250,
    w: 300,
    h: 200,
    content: 'Volume: EmpireCloud\nUsed: 4.2TB / 10TB\n\n> Flat File View: ENABLED\n> GPU Roller: IDLE',
  },
  {
    id: 'hw-01',
    title: 'Hardware',
    status: 'CPU Mood: Anxious',
    category: 'Hardware',
    x: 400,
    y: 250,
    w: 300,
    h: 200,
    content: 'CPU Load: 84%\nRAM Anxiety: High (28GB/32GB)\nFan Guardians: 100%\n\n> Thermal Throttling: IMMINENT',
  },
  {
    id: 'ai-01',
    title: 'AI Core',
    status: 'Baby Thirdos: Dreaming',
    category: 'AI Core',
    x: 50,
    y: 500,
    w: 250,
    h: 200,
    content: 'Model: GPT-4-Empire-Tuned\nTraining Loop: PAUSED\n\n> Dream Depth: Level 3',
  },
  {
    id: 'chaos-01',
    title: 'Chaos',
    status: 'Entropy: 14%',
    category: 'Chaos',
    x: 350,
    y: 500,
    w: 200,
    h: 150,
    content: 'Random Meme Generator: READY\n"All the Way" Flash: ARMED\n\n> Click to unleash chaos.',
  },
];
