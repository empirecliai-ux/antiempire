import { useState, useRef, useEffect } from 'react';
import { Send, Sparkles } from 'lucide-react';
import { cn } from '../lib/utils';

interface InputAreaProps {
  onSend: (content: string) => void;
  isLoading: boolean;
}

export function InputArea({ onSend, isLoading }: InputAreaProps) {
  const [content, setContent] = useState('');
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const handleSubmit = () => {
    if (!content.trim() || isLoading) return;
    onSend(content.trim());
    setContent('');
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${textareaRef.current.scrollHeight}px`;
    }
  }, [content]);

  return (
    <div className="fixed bottom-0 w-full bg-gradient-to-t from-background via-background to-transparent pb-8 pt-10 px-6 z-10">
      <div className="max-w-4xl mx-auto relative group">
        <div className="absolute -inset-1 bg-gradient-to-r from-primary/20 via-primary/10 to-primary/5 rounded-lg blur opacity-20 group-hover:opacity-40 transition duration-1000"></div>

        <div className="relative flex items-end gap-2 bg-secondary/80 backdrop-blur-xl border border-border rounded-lg p-2 shadow-2xl">
          <textarea
            ref={textareaRef}
            value={content}
            onChange={(e) => setContent(e.target.value)}
            onKeyDown={handleKeyDown}
            disabled={isLoading}
            rows={1}
            placeholder="Awaiting directive..."
            className="flex-1 bg-transparent text-foreground placeholder-gray-500 font-mono text-sm px-4 py-3 focus:outline-none resize-none max-h-48 disabled:opacity-50"
          />

          <button
            onClick={handleSubmit}
            disabled={!content.trim() || isLoading}
            className={cn(
              "p-3 rounded-md transition-all duration-200",
              content.trim() && !isLoading
                ? "bg-primary/20 text-primary hover:bg-primary/30 hover:shadow-[0_0_15px_rgba(0,255,255,0.3)]"
                : "bg-transparent text-gray-600 cursor-not-allowed"
            )}
          >
            {isLoading ? <Sparkles className="w-5 h-5 animate-pulse" /> : <Send className="w-5 h-5" />}
          </button>
        </div>

        <div className="text-[10px] text-gray-600 font-mono mt-2 text-center opacity-60">
          SECURE CHANNEL // UNISON PROTOCOL // <span className="text-primary/40">SENTINEL ACTIVE</span>
        </div>
      </div>
    </div>
  );
}
