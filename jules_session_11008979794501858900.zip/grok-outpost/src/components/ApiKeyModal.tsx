import React, { useState } from 'react';
import { ShieldCheck } from 'lucide-react';

interface ApiKeyModalProps {
  isOpen: boolean;
  onSave: (key: string) => void;
}

export function ApiKeyModal({ isOpen, onSave }: ApiKeyModalProps) {
  const [inputKey, setInputKey] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputKey.trim()) {
      onSave(inputKey.trim());
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm">
      <div className="w-full max-w-md p-6 bg-secondary border border-primary/20 rounded-lg shadow-[0_0_30px_rgba(0,255,255,0.1)]">
        <div className="flex items-center gap-3 mb-4 text-primary">
          <ShieldCheck className="w-6 h-6" />
          <h2 className="text-xl font-mono tracking-wider">AUTHENTICATION REQUIRED</h2>
        </div>
        <p className="mb-6 text-sm text-gray-400 font-mono">
          Enter your xAI API key to initialize the Neural Bridge.
          The key is stored locally on this terminal.
        </p>
        <form onSubmit={handleSubmit} className="space-y-4">
          <input
            type="password"
            value={inputKey}
            onChange={(e) => setInputKey(e.target.value)}
            placeholder="xai-..."
            className="w-full px-4 py-3 bg-black border border-border rounded focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary text-primary font-mono placeholder-gray-600"
            autoFocus
          />
          <button
            type="submit"
            disabled={!inputKey}
            className="w-full py-3 bg-primary/10 hover:bg-primary/20 border border-primary/50 text-primary font-mono rounded transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed uppercase tracking-widest hover:shadow-[0_0_15px_rgba(0,255,255,0.3)]"
          >
            Initialize Connection
          </button>
        </form>
      </div>
    </div>
  );
}
