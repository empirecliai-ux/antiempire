export interface Message {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: number;
}

export interface Thread {
  id: string;
  name?: string;
  created: number;
  lastUpdated: number;
  messages: Message[];
}

export interface Config {
  apiKey: string;
  model: string;
}

export interface ChatState {
  currentThread: Thread | null;
  isLoading: boolean;
  error: string | null;
  config: Config;
}
