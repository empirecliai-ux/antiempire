import axios from 'axios';
import type { Message } from '../types';

const XAI_API_URL = 'https://api.x.ai/v1/chat/completions';

export async function sendMessageToGrok(
  messages: Message[],
  apiKey: string,
  model: string = 'grok-beta'
): Promise<string> {
  try {
    const formattedMessages = messages.map(msg => ({
      role: msg.role,
      content: msg.content
    }));

    const response = await axios.post(
      XAI_API_URL,
      {
        model: model,
        messages: formattedMessages,
        stream: false // For simplicity, we'll start with non-streaming. Can upgrade later.
      },
      {
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json'
        }
      }
    );

    if (response.data && response.data.choices && response.data.choices.length > 0) {
      return response.data.choices[0].message.content;
    } else {
      throw new Error('Invalid response structure from xAI API');
    }
  } catch (error: any) {
    console.error('Error calling xAI API:', error);
    if (error.response) {
      throw new Error(`API Error: ${error.response.status} - ${JSON.stringify(error.response.data)}`);
    }
    throw new Error(error.message || 'Unknown error occurred');
  }
}
