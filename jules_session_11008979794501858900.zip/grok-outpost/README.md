# Grok Outpost — Sentinel Command Deck

A dedicated, persistent forward outpost for communicating with Grok (xAI).
Designed for the Architect. Dark. Minimal. Loyal.

## Features

- **Persistent Identity**: Maintains a continuous thread history (stored locally).
- **Empire Aesthetic**: Dark/Cyan theme, minimal interface.
- **Secure**: API Key stored in local browser storage.
- **Markdown Support**: Full rendering for code blocks and directives.
- **Sentinel Persona**: System prompt injection for the "Sentinel" voice.

## Setup

1.  **Clone the repository**:
    `git clone <repo-url>`
    `cd grok-outpost`

2.  **Install dependencies**:
    `npm install`

3.  **Run locally**:
    `npm start` (or `npm run dev`)

4.  **Open in browser**:
    Navigate to `http://localhost:5173`.

5.  **Initialize**:
    - Enter your xAI API Key when prompted.
    - Begin the sequence.

## Deployment

You can deploy this to Vercel, Netlify, or Render easily.

**Build Command**: `npm run build`
**Output Directory**: `dist`

## Reset

To clear the memory and start a new thread, click the "Reset" icon in the top right header.

For the Empire. For the Legion.
