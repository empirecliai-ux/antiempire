# Performance Rationale: MessageBubble Optimization

## Issue
In `grok-outpost/src/components/MessageBubble.tsx`, the `ReactMarkdown` component receives a `components` prop defined as an inline object literal:

```typescript
<ReactMarkdown
  components={{
    code({node, className, children, ...props}) {
      return (
        <code className={className} {...props}>
          {children}
        </code>
      )
    }
  }}
>
```

## Impact
Since this object is created on every render of `MessageBubble`, the `components` prop is referentially new each time. This causes `ReactMarkdown` to treat the prop as changed, triggering a full re-render of the markdown content and its children, even if the markdown content itself hasn't changed. Given that `ReactMarkdown` performs complex parsing and rendering, this is an expensive operation to repeat unnecessarily.

## Optimization
By moving the `components` object definition outside the `MessageBubble` component (or memoizing it), we ensure referential stability. The `components` prop will point to the same object across renders, allowing `ReactMarkdown` (and React's reconciliation process) to skip unnecessary updates if other props are unchanged.

## Measurement Limitations
Direct performance measurement (benchmarking) was not feasible in the current environment for the following reasons:
1.  **Headless Environment**: The environment lacks a browser engine to run the client-side React application and profile actual render times using browser devtools.
2.  **No Existing Test Infrastructure**: The project does not have a test runner (like Vitest or Jest) set up with performance profiling capabilities. Setting up a new test environment would introduce significant dependencies and complexity outside the scope of this task.
3.  **Vite/Client-side Context**: The application is built with Vite for the browser. Running components in a Node.js environment for benchmarking would require mocking browser APIs and handling CSS imports, which is non-trivial without a dedicated test setup.

## Conclusion
Despite the lack of direct measurement, the optimization is a well-established best practice in React development. Avoiding inline object definitions for props that accept complex objects (like configuration or component maps) prevents broken memoization and unnecessary re-renders, leading to improved performance, especially in list components like `MessageList` where many `MessageBubble` instances are rendered.
