(function() {
const { ipcRenderer } = require('electron');
const WindowManager = require('./js/WindowManager.js');

let windowManager;
let addressBar;
let loadingScreen;
let novaBtn;
let voiceOverlay;
let empireNavigator;

class EmpireNavigatorRenderer {
    constructor() {
        this.isListening = false;
        this.recognition = null;
        this.initializeVoiceRecognition();
        this.hideLoadingScreen();

        // Start status update loop
        setInterval(() => {
            this.updateEmpireStatus();
        }, 5000);
    }

    initializeVoiceRecognition() {
        if ('webkitSpeechRecognition' in window) {
            this.recognition = new webkitSpeechRecognition();
            this.recognition.continuous = false;
            this.recognition.interimResults = false;
            this.recognition.lang = 'en-US';

            this.recognition.onstart = () => {
                console.log('🎤 Nova listening...');
                this.isListening = true;
                novaBtn.classList.add('listening');
                voiceOverlay.classList.add('active');
            };

            this.recognition.onresult = (event) => {
                const command = event.results[0][0].transcript;
                console.log('🗣️ Voice Command:', command);
                this.handleVoiceCommand(command);
            };

            this.recognition.onend = () => {
                this.isListening = false;
                novaBtn.classList.remove('listening');
                voiceOverlay.classList.remove('active');
            };

            this.recognition.onerror = (event) => {
                console.error('Voice recognition error:', event.error);
                this.isListening = false;
                novaBtn.classList.remove('listening');
                voiceOverlay.classList.remove('active');
            };
        }
    }

    hideLoadingScreen() {
        setTimeout(() => {
            if (loadingScreen) {
                loadingScreen.style.opacity = '0';
                setTimeout(() => {
                    loadingScreen.style.display = 'none';
                }, 500);
            }
        }, 3000);
    }

    handleVoiceCommand(command) {
        const cmd = command.toLowerCase();

        // Update voice overlay
        document.getElementById('voice-command-text').textContent = `"${command}"`;

        // Send to main process
        ipcRenderer.invoke('empire-command', command);

        // Handle locally
        if (cmd.includes('navigate to') || cmd.includes('go to')) {
            const site = cmd.replace(/navigate to|go to/g, '').trim();
            this.navigateToSite(site);
        } else if (cmd.includes('new tab') || cmd.includes('new window')) {
            windowManager.createWindow('about:blank');
        } else if (cmd.includes('refresh') || cmd.includes('reload')) {
            const webview = windowManager.getActiveWebview();
            if (webview) webview.reload();
        } else if (cmd.includes('back')) {
             const webview = windowManager.getActiveWebview();
             if (webview && webview.canGoBack()) webview.goBack();
        } else if (cmd.includes('forward')) {
             const webview = windowManager.getActiveWebview();
             if (webview && webview.canGoForward()) webview.goForward();
        } else if (cmd.includes('close window')) {
             if (windowManager.activeWindow) windowManager.closeWindow(windowManager.activeWindow.id);
        }
    }

    navigateToSite(site) {
        let url = site;

        if (!url.includes('http')) {
            if (url.includes('.')) {
                url = `https://${url}`;
            } else {
                const shortcuts = {
                    'github': 'https://github.com',
                    'gmail': 'https://gmail.com',
                    'teams': 'https://teams.microsoft.com',
                    'discord': 'https://discord.com',
                    'youtube': 'https://youtube.com'
                };
                url = shortcuts[url] || `https://www.google.com/search?q=${encodeURIComponent(url)}`;
            }
        }

        const webview = windowManager.getActiveWebview();
        if (webview) {
            webview.src = url;
            // Address bar update handled by WindowManager event listener
        } else {
            // No active window, create one
            windowManager.createWindow(url);
        }
    }

    async updateEmpireStatus() {
        try {
            const status = await ipcRenderer.invoke('get-empire-status');
            // Update agent count and status indicators
            const agentCountEl = document.getElementById('agent-count');
            if (agentCountEl) agentCountEl.textContent = '47 AGENTS';
        } catch (error) {
            console.error('Failed to update Empire status:', error);
        }
    }
}

// Global Functions
function activateNova() {
    if (empireNavigator && empireNavigator.recognition && !empireNavigator.isListening) {
        empireNavigator.recognition.start();
    }
}

function toggleSocietas() {
    ipcRenderer.invoke('empire-command', 'show societas');
}

function handleAddressBar(event) {
    if (event.key === 'Enter') {
        const url = addressBar.value;
        if (empireNavigator) empireNavigator.navigateToSite(url);
    }
}

function goBack() {
    const webview = windowManager.getActiveWebview();
    if (webview && webview.canGoBack()) webview.goBack();
}

function goForward() {
    const webview = windowManager.getActiveWebview();
    if (webview && webview.canGoForward()) webview.goForward();
}

function refresh() {
    const webview = windowManager.getActiveWebview();
    if (webview) webview.reload();
}

function minimizeWindow() {
    ipcRenderer.send('window-minimize');
}

function maximizeWindow() {
    ipcRenderer.send('window-maximize');
}

function closeWindow() {
    ipcRenderer.send('window-close');
}

// Initialize on load
document.addEventListener('DOMContentLoaded', () => {
    addressBar = document.getElementById('address-bar');
    loadingScreen = document.getElementById('loading-screen');
    novaBtn = document.getElementById('nova-btn');
    voiceOverlay = document.getElementById('voice-overlay');

    windowManager = new WindowManager('browser-container');
    windowManager.createWindow('about:blank');

    empireNavigator = new EmpireNavigatorRenderer();

    // Make global for inline onclick handlers
    window.activateNova = activateNova;
    window.toggleSocietas = toggleSocietas;
    window.handleAddressBar = handleAddressBar;
    window.goBack = goBack;
    window.goForward = goForward;
    window.refresh = refresh;
    window.minimizeWindow = minimizeWindow;
    window.maximizeWindow = maximizeWindow;
    window.closeWindow = closeWindow;

    // Empire Easter Eggs
    document.addEventListener('keydown', (event) => {
        // Ctrl+Shift+E = Empire Command Palette
        if (event.ctrlKey && event.shiftKey && event.key === 'E') {
            activateNova();
        }

        // Ctrl+Shift+S = Show Societas
        if (event.ctrlKey && event.shiftKey && event.key === 'S') {
            toggleSocietas();
        }

        // Ctrl+T = New Window
        if (event.ctrlKey && event.key === 't') {
            windowManager.createWindow('about:blank');
        }
    });

    console.log('🏛️ Empire Navigator initialized');
    console.log('🎤 Say "Hey Nova" or click the microphone');
    console.log('💬 Press Ctrl+Shift+S for Societas');
});
})();
