const { ipcRenderer } = require('electron');

// DOM Elements
const addressBar = document.getElementById('address-bar');
const loadingScreen = document.getElementById('loading-screen');
const novaBtn = document.getElementById('nova-btn');
const voiceOverlay = document.getElementById('voice-overlay');
const voiceCommandText = document.getElementById('voice-command-text');

// Initialize Window Manager
const windowManager = new WindowManager('browser-content');

// Initial Pane
windowManager.createPane('https://www.google.com');

// Helper to get active webview
function getActiveWebview() {
    return windowManager.getActiveWebview();
}

// Window Controls
document.getElementById('minimize-btn').addEventListener('click', () => {
    ipcRenderer.send('window-minimize');
});
document.getElementById('maximize-btn').addEventListener('click', () => {
    ipcRenderer.send('window-maximize');
});
document.getElementById('close-btn').addEventListener('click', () => {
    ipcRenderer.send('window-close');
});

// Navigation Controls
document.getElementById('back-btn').addEventListener('click', () => {
    const webview = getActiveWebview();
    if (webview && webview.canGoBack()) webview.goBack();
});

document.getElementById('forward-btn').addEventListener('click', () => {
    const webview = getActiveWebview();
    if (webview && webview.canGoForward()) webview.goForward();
});

document.getElementById('refresh-btn').addEventListener('click', () => {
    const webview = getActiveWebview();
    if (webview) webview.reload();
});

document.getElementById('new-pane-btn').addEventListener('click', () => {
    windowManager.createPane('about:blank');
});

// Address Bar
addressBar.addEventListener('keypress', (event) => {
    if (event.key === 'Enter') {
        const url = formatUrl(addressBar.value);
        const webview = getActiveWebview();
        if (webview) {
            webview.src = url;
        } else {
            windowManager.createPane(url);
        }
    }
});

function formatUrl(input) {
    if (!input) return 'about:blank';
    if (input.startsWith('http://') || input.startsWith('https://') || input.startsWith('file://') || input.startsWith('about:')) {
        return input;
    }
    if (input.includes('.')) {
        return 'https://' + input;
    }
    // Search fallback
    return 'https://www.google.com/search?q=' + encodeURIComponent(input);
}


// Empire Loading Screen
setTimeout(() => {
    loadingScreen.style.opacity = '0';
    setTimeout(() => {
        loadingScreen.style.display = 'none';
    }, 500);
}, 2000);


// Voice Command Logic (Ported from user snippet)
class VoiceInterface {
    constructor() {
        this.isListening = false;
        this.recognition = null;
        this.initialize();
    }

    initialize() {
        if ('webkitSpeechRecognition' in window) {
            this.recognition = new webkitSpeechRecognition();
            this.recognition.continuous = false;
            this.recognition.interimResults = false;
            this.recognition.lang = 'en-US';

            this.recognition.onstart = () => {
                console.log('🎤 Nova listening...');
                this.isListening = true;
                novaBtn.classList.add('listening');
                voiceOverlay.classList.add('active');
            };

            this.recognition.onresult = (event) => {
                const command = event.results[0][0].transcript;
                console.log('🗣️ Voice Command:', command);
                this.handleCommand(command);
            };

            this.recognition.onend = () => {
                this.isListening = false;
                novaBtn.classList.remove('listening');
                voiceOverlay.classList.remove('active');
            };

            this.recognition.onerror = (event) => {
                console.error('Voice recognition error:', event.error);
                this.isListening = false;
                novaBtn.classList.remove('listening');
                voiceOverlay.classList.remove('active');
            };
        }
    }

    start() {
        if (this.recognition && !this.isListening) {
            this.recognition.start();
        }
    }

    handleCommand(command) {
        const cmd = command.toLowerCase();
        
        // Update overlay text
        if (voiceCommandText) voiceCommandText.textContent = `"${command}"`;
        
        // Process commands
        if (cmd.includes('navigate to') || cmd.includes('go to')) {
            const site = cmd.replace(/navigate to|go to/g, '').trim();
            const url = formatUrl(site);
            const webview = getActiveWebview();
            if (webview) {
                webview.src = url;
            } else {
                windowManager.createPane(url);
            }
        } else if (cmd.includes('new tab') || cmd.includes('new window') || cmd.includes('new pane')) {
            windowManager.createPane('about:blank');
        } else if (cmd.includes('close tab') || cmd.includes('close pane')) {
            if (windowManager.activePane) {
                windowManager.closePane(windowManager.activePane.id);
            }
        } else if (cmd.includes('refresh') || cmd.includes('reload')) {
            const webview = getActiveWebview();
            if (webview) webview.reload();
        } else if (cmd.includes('back')) {
            const webview = getActiveWebview();
            if (webview && webview.canGoBack()) webview.goBack();
        } else if (cmd.includes('forward')) {
            const webview = getActiveWebview();
            if (webview && webview.canGoForward()) webview.goForward();
        } else if (cmd.includes('show societas')) {
            // Mock toggle
            alert('Societas Panel Toggled (Mock)');
        }
    }
}

const voiceInterface = new VoiceInterface();

novaBtn.addEventListener('click', () => {
    voiceInterface.start();
});

// Keyboard Shortcuts
document.addEventListener('keydown', (event) => {
    // Ctrl+Shift+E = Empire Command Palette (Voice)
    if (event.ctrlKey && event.shiftKey && event.key === 'E') {
        voiceInterface.start();
    }
    
    // Ctrl+N = New Pane
    if (event.ctrlKey && event.key === 'n') {
        windowManager.createPane('about:blank');
    }
});

console.log('🏛️ Empire Navigator Modular initialized');
