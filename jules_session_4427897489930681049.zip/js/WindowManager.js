class WindowManager {
    constructor(containerId) {
        this.container = document.getElementById(containerId);
        this.panes = [];
        this.zIndex = 100;
        this.activePane = null;
        
        // Global mouse events for drag/resize
        this.isDragging = false;
        this.isResizing = false;
        this.currentPane = null; // The pane being manipulated
        this.resizeDir = null; // 'e', 's', 'se'
        
        this.startX = 0;
        this.startY = 0;
        this.startLeft = 0;
        this.startTop = 0;
        this.startWidth = 0;
        this.startHeight = 0;

        document.addEventListener('mousemove', this.handleMouseMove.bind(this));
        document.addEventListener('mouseup', this.handleMouseUp.bind(this));
    }

    createPane(url = 'https://www.google.com') {
        const id = 'pane-' + Date.now();
        const pane = document.createElement('div');
        pane.className = 'window-pane';
        pane.id = id;
        
        // Initial Position & Size (staggered)
        const offset = (this.panes.length * 30) % 200;
        pane.style.left = (50 + offset) + 'px';
        pane.style.top = (50 + offset) + 'px';
        pane.style.width = '600px';
        pane.style.height = '400px';
        pane.style.zIndex = ++this.zIndex;

        // Header
        const header = document.createElement('div');
        header.className = 'pane-header';
        
        const title = document.createElement('div');
        title.className = 'pane-title';
        title.innerText = 'Loading...';
        
        const controls = document.createElement('div');
        controls.className = 'pane-controls';
        
        const closeBtn = document.createElement('button');
        closeBtn.className = 'pane-control-btn close';
        closeBtn.title = 'Close Pane';
        closeBtn.onclick = (e) => {
            e.stopPropagation();
            this.closePane(id);
        };
        
        controls.appendChild(closeBtn);
        header.appendChild(title);
        header.appendChild(controls);

        // Content (WebView)
        const content = document.createElement('div');
        content.className = 'pane-content';
        
        const webview = document.createElement('webview');
        webview.src = url;
        webview.setAttribute('allowpopups', '');
        
        // Webview Events
        webview.addEventListener('did-start-loading', () => {
            title.innerText = 'Loading...';
        });
        webview.addEventListener('did-stop-loading', () => {
            title.innerText = webview.getTitle();
            this.updateAddressBar(webview.getURL());
        });
        webview.addEventListener('dom-ready', () => {
             title.innerText = webview.getTitle();
             this.updateAddressBar(webview.getURL());
        });
        webview.addEventListener('did-navigate', (e) => {
             this.updateAddressBar(e.url);
        });
        
        // Forward click to activate pane
        // Note: clicks inside webview are consumed by webview, so we might need an overlay or capture at container level if we want clicking webview to focus pane.
        // For now, clicking header focuses pane.

        content.appendChild(webview);

        // Resize Handles
        const resizeE = document.createElement('div');
        resizeE.className = 'resize-handle e';
        const resizeS = document.createElement('div');
        resizeS.className = 'resize-handle s';
        const resizeSE = document.createElement('div');
        resizeSE.className = 'resize-handle se';

        // Assemble
        pane.appendChild(header);
        pane.appendChild(content);
        pane.appendChild(resizeE);
        pane.appendChild(resizeS);
        pane.appendChild(resizeSE);

        this.container.appendChild(pane);
        
        const paneObj = { id, element: pane, webview };
        this.panes.push(paneObj);
        this.setActivePane(paneObj);

        // Event Listeners for Interaction
        pane.addEventListener('mousedown', () => this.setActivePane(paneObj));
        
        header.addEventListener('mousedown', (e) => this.startDrag(e, paneObj));
        
        resizeE.addEventListener('mousedown', (e) => this.startResize(e, paneObj, 'e'));
        resizeS.addEventListener('mousedown', (e) => this.startResize(e, paneObj, 's'));
        resizeSE.addEventListener('mousedown', (e) => this.startResize(e, paneObj, 'se'));

        return paneObj;
    }

    closePane(id) {
        const index = this.panes.findIndex(p => p.id === id);
        if (index !== -1) {
            const pane = this.panes[index];
            this.container.removeChild(pane.element);
            this.panes.splice(index, 1);
            if (this.activePane === pane) {
                // Set active to the last one or null
                if (this.panes.length > 0) {
                    this.setActivePane(this.panes[this.panes.length - 1]);
                } else {
                    this.activePane = null;
                }
            }
        }
    }

    setActivePane(paneObj) {
        this.activePane = paneObj;
        paneObj.element.style.zIndex = ++this.zIndex;
        
        // Update styling
        this.panes.forEach(p => p.element.classList.remove('active'));
        paneObj.element.classList.add('active');

        // Update main address bar if needed (optional integration)
        if (paneObj.webview.getURL) {
            try {
                const url = paneObj.webview.getURL();
                this.updateAddressBar(url);
            } catch(e) {}
        }
    }
    
    updateAddressBar(url) {
        // Only update if this is the active pane
        if (this.activePane && this.activePane.webview.getURL() === url) {
            const addressBar = document.getElementById('address-bar');
            if (addressBar && url && url !== 'about:blank') {
                addressBar.value = url;
            }
        }
    }

    startDrag(e, paneObj) {
        this.isDragging = true;
        this.currentPane = paneObj;
        this.startX = e.clientX;
        this.startY = e.clientY;
        this.startLeft = paneObj.element.offsetLeft;
        this.startTop = paneObj.element.offsetTop;
        
        // Prevent text selection
        e.preventDefault();
    }

    startResize(e, paneObj, dir) {
        this.isResizing = true;
        this.currentPane = paneObj;
        this.resizeDir = dir;
        this.startX = e.clientX;
        this.startY = e.clientY;
        this.startWidth = paneObj.element.offsetWidth;
        this.startHeight = paneObj.element.offsetHeight;
        
        e.preventDefault();
        e.stopPropagation();
    }

    handleMouseMove(e) {
        if (this.isDragging && this.currentPane) {
            const dx = e.clientX - this.startX;
            const dy = e.clientY - this.startY;
            
            let newLeft = this.startLeft + dx;
            let newTop = this.startTop + dy;

            // Simple Snapping (e.g. within 10px of edges)
            const snapThreshold = 10;
            const containerWidth = this.container.offsetWidth;
            const containerHeight = this.container.offsetHeight;
            const paneWidth = this.currentPane.element.offsetWidth;
            const paneHeight = this.currentPane.element.offsetHeight;

            if (Math.abs(newLeft) < snapThreshold) newLeft = 0;
            if (Math.abs(newTop) < snapThreshold) newTop = 0;
            if (Math.abs(newLeft + paneWidth - containerWidth) < snapThreshold) newLeft = containerWidth - paneWidth;
            if (Math.abs(newTop + paneHeight - containerHeight) < snapThreshold) newTop = containerHeight - paneHeight;
            
            // Constrain to container
            if (newLeft < 0) newLeft = 0;
            if (newTop < 0) newTop = 0;
            if (newLeft + paneWidth > containerWidth) newLeft = containerWidth - paneWidth;
            if (newTop + paneHeight > containerHeight) newTop = containerHeight - paneHeight;

            this.currentPane.element.style.left = newLeft + 'px';
            this.currentPane.element.style.top = newTop + 'px';
        }

        if (this.isResizing && this.currentPane) {
            const dx = e.clientX - this.startX;
            const dy = e.clientY - this.startY;

            if (this.resizeDir === 'e' || this.resizeDir === 'se') {
                this.currentPane.element.style.width = Math.max(200, (this.startWidth + dx)) + 'px';
            }
            if (this.resizeDir === 's' || this.resizeDir === 'se') {
                this.currentPane.element.style.height = Math.max(150, (this.startHeight + dy)) + 'px';
            }
        }
    }

    handleMouseUp() {
        this.isDragging = false;
        this.isResizing = false;
        this.currentPane = null;
        this.resizeDir = null;
    }
    
    getActiveWebview() {
        return this.activePane ? this.activePane.webview : null;
    }
}

// Expose to window for renderer.js to use
window.WindowManager = WindowManager;
