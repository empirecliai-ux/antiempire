
class EmpireNavigatorRenderer {
    constructor() {
        this.isListening = false;
        this.recognition = null;
        this.windowManager = new WindowManager('browser-content');
        
        // Create initial pane
        this.windowManager.createPane('https://www.google.com');

        this.initializeVoiceRecognition();
        this.setupEventListeners();
        this.hideLoadingScreen();
    }

    initializeVoiceRecognition() {
        if ('webkitSpeechRecognition' in window) {
            // eslint-disable-next-line no-undef
            this.recognition = new webkitSpeechRecognition(); 
            this.recognition.continuous = false;
            this.recognition.interimResults = false;
            this.recognition.lang = 'en-US';

            this.recognition.onstart = () => {
                console.log('🎤 Nova listening...');
                this.isListening = true;
                const novaBtn = document.getElementById('nova-btn');
                const voiceOverlay = document.getElementById('voice-overlay');
                if (novaBtn) novaBtn.classList.add('listening');
                if (voiceOverlay) voiceOverlay.classList.add('active');
            };

            this.recognition.onresult = (event) => {
                const command = event.results[0][0].transcript;
                console.log('🗣️ Voice Command:', command);
                this.handleVoiceCommand(command);
            };

            this.recognition.onend = () => {
                this.isListening = false;
                const novaBtn = document.getElementById('nova-btn');
                const voiceOverlay = document.getElementById('voice-overlay');
                if (novaBtn) novaBtn.classList.remove('listening');
                if (voiceOverlay) voiceOverlay.classList.remove('active');
            };

            this.recognition.onerror = (event) => {
                console.error('Voice recognition error:', event.error);
                this.isListening = false;
                const novaBtn = document.getElementById('nova-btn');
                const voiceOverlay = document.getElementById('voice-overlay');
                if (novaBtn) novaBtn.classList.remove('listening');
                if (voiceOverlay) voiceOverlay.classList.remove('active');
            };
        } else {
            console.warn('webkitSpeechRecognition not supported');
        }
    }

    setupEventListeners() {
        // Empire status updates
        setInterval(() => {
            this.updateEmpireStatus();
        }, 5000);

        // Navigation Buttons
        document.getElementById('back-btn').addEventListener('click', () => {
            const webview = this.windowManager.getActiveWebview();
            if (webview && webview.canGoBack()) webview.goBack();
        });

        document.getElementById('forward-btn').addEventListener('click', () => {
            const webview = this.windowManager.getActiveWebview();
            if (webview && webview.canGoForward()) webview.goForward();
        });

        document.getElementById('refresh-btn').addEventListener('click', () => {
            const webview = this.windowManager.getActiveWebview();
            if (webview) webview.reload();
        });

        // Address Bar
        const addressBar = document.getElementById('address-bar');
        addressBar.addEventListener('keypress', (event) => {
            if (event.key === 'Enter') {
                this.navigateToSite(addressBar.value);
            }
        });

        // Window Controls (delegated to IPC via preload)
        document.querySelector('.control-btn.minimize').addEventListener('click', () => {
            window.empireApi.minimizeWindow();
        });
        document.querySelector('.control-btn.maximize').addEventListener('click', () => {
            window.empireApi.maximizeWindow();
        });
        document.querySelector('.control-btn.close').addEventListener('click', () => {
            window.empireApi.closeWindow();
        });

        // Nova/Societas
        document.getElementById('nova-btn').addEventListener('click', () => this.activateNova());
        document.querySelector('.societas-toggle').addEventListener('click', () => this.toggleSocietas());
        
        // Add new tab/pane button if we have one, or keyboard shortcut
        document.addEventListener('keydown', (e) => {
            // Ctrl+T for new tab
            if (e.ctrlKey && e.key === 't') {
                this.windowManager.createPane();
            }
            // Ctrl+Shift+E = Empire Command Palette
            if (e.ctrlKey && e.shiftKey && e.key === 'E') { 
                this.activateNova(); 
            } 
             
            // Ctrl+Shift+S = Show Societas 
            if (e.ctrlKey && e.shiftKey && e.key === 'S') { 
                this.toggleSocietas(); 
            } 
        });
    }

    hideLoadingScreen() {
        const loadingScreen = document.getElementById('loading-screen');
        setTimeout(() => {
            loadingScreen.style.opacity = '0';
            setTimeout(() => {
                loadingScreen.style.display = 'none';
            }, 500);
        }, 3000);
    }

    handleVoiceCommand(command) {
        const cmd = command.toLowerCase();
        
        // Update voice overlay 
        const voiceText = document.getElementById('voice-command-text');
        if (voiceText) voiceText.textContent = `"${command}"`;
        
        // Send to main process 
        window.empireApi.sendEmpireCommand(command);
        
        // Handle locally 
        if (cmd.includes('navigate to') || cmd.includes('go to')) { 
            const site = cmd.replace(/navigate to|go to/g, '').trim(); 
            this.navigateToSite(site); 
        } else if (cmd.includes('new tab') || cmd.includes('new window')) { 
            this.windowManager.createPane(); 
        } else if (cmd.includes('close tab') || cmd.includes('close window')) {
            if (this.windowManager.activePane) {
                this.windowManager.closePane(this.windowManager.activePane);
            }
        } else if (cmd.includes('refresh') || cmd.includes('reload')) { 
            const webview = this.windowManager.getActiveWebview();
            if (webview) webview.reload(); 
        } else if (cmd.includes('back')) { 
            const webview = this.windowManager.getActiveWebview();
            if (webview && webview.canGoBack()) webview.goBack(); 
        } else if (cmd.includes('forward')) { 
            const webview = this.windowManager.getActiveWebview();
            if (webview && webview.canGoForward()) webview.goForward(); 
        } 
    } 

    navigateToSite(site) { 
        let url = site; 
        
        if (!url.includes('http')) { 
            if (url.includes('.') && !url.includes(' ')) { 
                url = `https://${url}`; 
            } else { 
                const shortcuts = { 
                    'github': 'https://github.com', 
                    'gmail': 'https://gmail.com', 
                    'teams': 'https://teams.microsoft.com', 
                    'discord': 'https://discord.com', 
                    'youtube': 'https://youtube.com' 
                }; 
                url = shortcuts[url] || `https://www.google.com/search?q=${encodeURIComponent(url)}`; 
            } 
        } 
        
        const webview = this.windowManager.getActiveWebview();
        if (webview) {
            webview.src = url;
            // Address bar update is handled by 'did-navigate' listener in WindowManager
        } else {
            // If no active pane, create one
            this.windowManager.createPane(url);
        }
    } 

    updateAddressBar(url) {
        const addressBar = document.getElementById('address-bar');
        if (addressBar) addressBar.value = url;
        this.updateNavigationButtons();
    }

    updateNavigationButtons() { 
        const webview = this.windowManager.getActiveWebview();
        const backBtn = document.getElementById('back-btn');
        const forwardBtn = document.getElementById('forward-btn');
        
        if (webview && backBtn && forwardBtn) {
            backBtn.disabled = !webview.canGoBack(); 
            forwardBtn.disabled = !webview.canGoForward(); 
        }
    } 

    async updateEmpireStatus() { 
        try { 
            const status = await window.empireApi.getEmpireStatus(); 
            // Update agent count and status indicators 
            const agentCount = document.getElementById('agent-count');
            if (agentCount) agentCount.textContent = `${status.agents} AGENTS`; 
        } catch (error) { 
            console.error('Failed to update Empire status:', error); 
        } 
    } 

    activateNova() { 
        if (this.recognition && !this.isListening) { 
            this.recognition.start(); 
        } 
    } 

    toggleSocietas() { 
        window.empireApi.sendEmpireCommand('show societas'); 
    } 
}

// Initialize on load
window.addEventListener('DOMContentLoaded', () => {
    window.empireNavigator = new EmpireNavigatorRenderer();
    console.log('🏛️ Empire Navigator initialized'); 
    console.log('🎤 Say "Hey Nova" or click the microphone'); 
    console.log('💬 Press Ctrl+Shift+S for Societas'); 
});
