class WindowManager {
    constructor(containerId) {
        this.container = document.getElementById(containerId);
        this.panes = [];
        this.activePane = null;
        this.zIndexCounter = 100;
        this.isDragging = false;
        this.isResizing = false;
        
        // Drag/Resize state
        this.dragOffset = { x: 0, y: 0 };
        this.currentPane = null;
        this.resizeDirection = '';
        this.initialRect = null;
        this.initialMouse = { x: 0, y: 0 };

        this.setupGlobalListeners();
    }

    createPane(url = 'about:blank') {
        const paneId = `pane-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
        const pane = document.createElement('div');
        pane.className = 'window-pane active';
        pane.id = paneId;
        pane.style.left = '50px';
        pane.style.top = '50px';
        pane.style.width = '800px';
        pane.style.height = '600px';
        pane.style.zIndex = ++this.zIndexCounter;

        // Pane Structure
        pane.innerHTML = `
            <div class="pane-header">
                <div class="pane-title">New Tab</div>
                <div class="pane-controls">
                    <button class="pane-btn minimize" title="Minimize"></button>
                    <button class="pane-btn maximize" title="Maximize/Restore"></button>
                    <button class="pane-btn close" title="Close"></button>
                </div>
            </div>
            <div class="pane-content">
                <!-- Webview will be inserted here -->
            </div>
            <div class="resize-handle resize-e"></div>
            <div class="resize-handle resize-s"></div>
            <div class="resize-handle resize-se"></div>
        `;

        // Create Webview securely
        const webview = document.createElement('webview');
        webview.src = url;
        webview.setAttribute('allowpopups', '');
        // webview.setAttribute('webpreferences', 'contextIsolation=true'); // Electron specific
        
        const paneContent = pane.querySelector('.pane-content');
        paneContent.appendChild(webview);

        // Append to container
        this.container.appendChild(pane);
        this.panes.push(pane);
        this.setActivePane(pane);

        // Event Listeners for Pane
        this.setupPaneListeners(pane, webview);
        
        return { pane, webview };
    }

    setupPaneListeners(pane, webview) {
        const header = pane.querySelector('.pane-header');
        const closeBtn = pane.querySelector('.pane-btn.close');
        const maxBtn = pane.querySelector('.pane-btn.maximize');
        const resizeHandles = pane.querySelectorAll('.resize-handle');

        // Dragging
        header.addEventListener('mousedown', (e) => {
            if (e.target.closest('.pane-controls')) return; // Ignore if clicking controls
            this.startDrag(e, pane);
        });

        // Activation
        pane.addEventListener('mousedown', () => {
            this.setActivePane(pane);
        });

        // Controls
        closeBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            this.closePane(pane);
        });

        maxBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            this.toggleMaximize(pane);
        });

        // Resizing
        resizeHandles.forEach(handle => {
            handle.addEventListener('mousedown', (e) => {
                e.stopPropagation();
                const direction = handle.classList.contains('resize-e') ? 'e' : 
                                  handle.classList.contains('resize-s') ? 's' : 'se';
                this.startResize(e, pane, direction);
            });
        });

        // Webview Events (to update title/url)
        webview.addEventListener('did-navigate', (e) => {
            const titleEl = pane.querySelector('.pane-title');
            titleEl.textContent = webview.getTitle() || e.url;
            // Notify renderer if this is the active pane
            if (this.activePane === pane && window.empireNavigator) {
                window.empireNavigator.updateAddressBar(e.url);
            }
        });

        webview.addEventListener('page-title-updated', (e) => {
            const titleEl = pane.querySelector('.pane-title');
            titleEl.textContent = e.title;
        });

        webview.addEventListener('dom-ready', () => {
             // Inject custom CSS or scripts if needed
        });
    }

    startDrag(e, pane) {
        this.isDragging = true;
        this.currentPane = pane;
        this.dragOffset.x = e.clientX - pane.offsetLeft;
        this.dragOffset.y = e.clientY - pane.offsetTop;
        
        // Add overlay to webview to prevent it swallowing mouse events
        pane.querySelector('.pane-content').style.pointerEvents = 'none';
    }

    startResize(e, pane, direction) {
        this.isResizing = true;
        this.currentPane = pane;
        this.resizeDirection = direction;
        this.initialMouse = { x: e.clientX, y: e.clientY };
        this.initialRect = {
            width: pane.offsetWidth,
            height: pane.offsetHeight
        };
        
        pane.querySelector('.pane-content').style.pointerEvents = 'none';
    }

    setupGlobalListeners() {
        document.addEventListener('mousemove', (e) => {
            if (this.isDragging && this.currentPane) {
                this.handleDrag(e);
            } else if (this.isResizing && this.currentPane) {
                this.handleResize(e);
            }
        });

        document.addEventListener('mouseup', () => {
            if (this.currentPane) {
                // Re-enable pointer events on webview
                this.currentPane.querySelector('.pane-content').style.pointerEvents = 'auto';
            }
            this.isDragging = false;
            this.isResizing = false;
            this.currentPane = null;
        });
    }

    handleDrag(e) {
        if (!this.currentPane) return;
        
        let newX = e.clientX - this.dragOffset.x;
        let newY = e.clientY - this.dragOffset.y;

        // Boundary checks (optional, but good for "snap")
        // Simple snap to edges
        const snapThreshold = 20;
        if (newX < snapThreshold) newX = 0;
        if (newY < snapThreshold) newY = 0;
        if (newX + this.currentPane.offsetWidth > this.container.offsetWidth - snapThreshold) {
            newX = this.container.offsetWidth - this.currentPane.offsetWidth;
        }
        if (newY + this.currentPane.offsetHeight > this.container.offsetHeight - snapThreshold) {
            newY = this.container.offsetHeight - this.currentPane.offsetHeight;
        }

        this.currentPane.style.left = `${newX}px`;
        this.currentPane.style.top = `${newY}px`;
    }

    handleResize(e) {
        if (!this.currentPane) return;

        const deltaX = e.clientX - this.initialMouse.x;
        const deltaY = e.clientY - this.initialMouse.y;

        if (this.resizeDirection === 'e' || this.resizeDirection === 'se') {
            const newWidth = Math.max(200, this.initialRect.width + deltaX);
            this.currentPane.style.width = `${newWidth}px`;
        }
        
        if (this.resizeDirection === 's' || this.resizeDirection === 'se') {
            const newHeight = Math.max(150, this.initialRect.height + deltaY);
            this.currentPane.style.height = `${newHeight}px`;
        }
    }

    setActivePane(pane) {
        this.activePane = pane;
        this.panes.forEach(p => p.classList.remove('active'));
        pane.classList.add('active');
        pane.style.zIndex = ++this.zIndexCounter;

        // Update main address bar
        const webview = pane.querySelector('webview');
        if (window.empireNavigator && webview) {
            window.empireNavigator.updateAddressBar(webview.getURL());
            window.empireNavigator.updateNavigationButtons();
        }
    }

    closePane(pane) {
        const index = this.panes.indexOf(pane);
        if (index > -1) {
            this.panes.splice(index, 1);
            pane.remove();
            
            // Activate another pane if available
            if (this.panes.length > 0) {
                this.setActivePane(this.panes[this.panes.length - 1]);
            } else {
                this.activePane = null;
                // Maybe open a default new tab?
                this.createPane();
            }
        }
    }

    toggleMaximize(pane) {
        if (pane.classList.contains('maximized')) {
            pane.classList.remove('maximized');
            pane.style.width = pane.dataset.restoreWidth;
            pane.style.height = pane.dataset.restoreHeight;
            pane.style.left = pane.dataset.restoreLeft;
            pane.style.top = pane.dataset.restoreTop;
        } else {
            // Save state
            pane.dataset.restoreWidth = pane.style.width;
            pane.dataset.restoreHeight = pane.style.height;
            pane.dataset.restoreLeft = pane.style.left;
            pane.dataset.restoreTop = pane.style.top;
            
            pane.classList.add('maximized');
            pane.style.width = '100%';
            pane.style.height = '100%';
            pane.style.left = '0';
            pane.style.top = '0';
        }
    }

    getActiveWebview() {
        if (this.activePane) {
            return this.activePane.querySelector('webview');
        }
        return null;
    }
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = WindowManager;
} else {
    window.WindowManager = WindowManager;
}
