const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('empireApi', {
    minimizeWindow: () => ipcRenderer.invoke('minimize-window'),
    maximizeWindow: () => ipcRenderer.invoke('maximize-window'),
    closeWindow: () => ipcRenderer.invoke('close-window'),
    sendEmpireCommand: (command) => ipcRenderer.invoke('empire-command', command),
    getEmpireStatus: () => ipcRenderer.invoke('get-empire-status'),
});

// Expose minimal node capabilities if needed (e.g. for drag controls or other OS interactions that might be needed later, though usually IPC is preferred)
// For now, only IPC is exposed.
