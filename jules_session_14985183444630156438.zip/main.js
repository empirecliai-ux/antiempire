const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');

function createWindow() {
    const win = new BrowserWindow({
        width: 1200,
        height: 800,
        frame: false, // Custom title bar, hide native frame
        backgroundColor: '#020617',
        webPreferences: {
            nodeIntegration: true,
            contextIsolation: false,
            webviewTag: true,
            // enableRemoteModule: true // Commented out to encourage IPC usage
        }
    });

    win.loadFile('index.html');

    // IPC handlers for window controls
    ipcMain.handle('window-minimize', () => {
        win.minimize();
    });

    ipcMain.handle('window-maximize', () => {
        if (win.isMaximized()) {
            win.unmaximize();
        } else {
            win.maximize();
        }
    });

    ipcMain.handle('window-close', () => {
        win.close();
    });

    // Empire status handler (mock)
    ipcMain.handle('get-empire-status', () => {
        return { status: 'ONLINE', agents: 47 };
    });

    // Empire command handler (log to console for now)
    ipcMain.handle('empire-command', (event, command) => {
        console.log('Empire Command:', command);
    });
}

app.whenReady().then(() => {
    createWindow();

    app.on('activate', () => {
        if (BrowserWindow.getAllWindows().length === 0) {
            createWindow();
        }
    });
});

app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
        app.quit();
    }
});
