class WindowManager {
    constructor(container) {
        this.container = container;
        this.windows = [];
        this.activeWindow = null;
        this.zIndexCounter = 100;
        this.snapThreshold = 20;
        
        // Ghost element for snap preview
        this.ghost = document.createElement('div');
        this.ghost.className = 'snap-ghost';
        this.container.appendChild(this.ghost);
        
        // Global mouse events for drag/resize
        document.addEventListener('mousemove', this.handleMouseMove.bind(this));
        document.addEventListener('mouseup', this.handleMouseUp.bind(this));
        
        this.dragState = null; // { type: 'move'|'resize', window, startX, startY, initialRect, handle }
    }

    createWindow(url = 'https://google.com') {
        const id = 'win-' + Date.now();
        const winEl = document.createElement('div');
        winEl.className = 'window-container';
        winEl.id = id;
        winEl.style.left = '50px';
        winEl.style.top = '50px';
        winEl.style.width = '800px';
        winEl.style.height = '600px';
        
        // Header
        const header = document.createElement('div');
        header.className = 'window-header';
        
        const title = document.createElement('div');
        title.className = 'window-title';
        title.textContent = 'Loading...';
        
        const controls = document.createElement('div');
        controls.className = 'window-controls';
        
        const minBtn = document.createElement('div');
        minBtn.className = 'win-control-btn minimize';
        const maxBtn = document.createElement('div');
        maxBtn.className = 'win-control-btn maximize';
        const closeBtn = document.createElement('div');
        closeBtn.className = 'win-control-btn close';
        
        controls.appendChild(minBtn);
        controls.appendChild(maxBtn);
        controls.appendChild(closeBtn);
        
        header.appendChild(title);
        header.appendChild(controls);
        
        // Content
        const content = document.createElement('div');
        content.className = 'webview-container';
        
        const webview = document.createElement('webview');
        webview.src = url;
        webview.setAttribute('allowpopups', '');
        
        content.appendChild(webview);
        
        winEl.appendChild(header);
        winEl.appendChild(content);
        this.container.appendChild(winEl);

        const winObject = {
            id,
            element: winEl,
            webview,
            isMaximized: false,
            preMaximizeRect: null
        };

        // Webview Events
        webview.addEventListener('dom-ready', () => {
            title.textContent = webview.getTitle();
        });
        
        webview.addEventListener('page-title-updated', (e) => {
            title.textContent = e.title;
        });

        webview.addEventListener('did-navigate', (e) => {
            if (this.activeWindow === winObject) {
               document.dispatchEvent(new CustomEvent('url-changed', { detail: e.url }));
            }
        });
        
        // Resize Handles
        const handles = ['n', 's', 'e', 'w', 'ne', 'nw', 'se', 'sw'];
        handles.forEach(dir => {
            const handle = document.createElement('div');
            handle.className = `resize-handle ${dir}`;
            handle.dataset.dir = dir;
            winEl.appendChild(handle);
            
            handle.addEventListener('mousedown', (e) => {
                this.startResize(e, winObject, dir);
            });
        });
        
        this.windows.push(winObject);
        this.setActiveWindow(winObject);
        
        // Window Control Events
        header.addEventListener('mousedown', (e) => {
            this.startMove(e, winObject);
        });
        
        winEl.addEventListener('mousedown', () => {
            this.setActiveWindow(winObject);
        });
        
        closeBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            this.closeWindow(winObject);
        });
        
        maxBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            this.toggleMaximize(winObject);
        });

        minBtn.addEventListener('click', (e) => {
             e.stopPropagation();
             winEl.style.display = 'none'; // Simple hide
        });
        
        return winObject;
    }
    
    closeWindow(winObject) {
        winObject.element.remove();
        this.windows = this.windows.filter(w => w !== winObject);
        if (this.activeWindow === winObject) {
            this.activeWindow = this.windows.length > 0 ? this.windows[this.windows.length - 1] : null;
            if (this.activeWindow) {
                this.setActiveWindow(this.activeWindow);
            }
        }
    }
    
    setActiveWindow(winObject) {
        this.activeWindow = winObject;
        this.windows.forEach(w => w.element.classList.remove('active'));
        if (winObject) {
            winObject.element.classList.add('active');
            winObject.element.style.zIndex = ++this.zIndexCounter;
            // Notify renderer to update address bar
            try {
                const url = winObject.webview.getURL();
                document.dispatchEvent(new CustomEvent('url-changed', { detail: url }));
            } catch (e) {
                // Ignore if webview not ready
            }
        }
    }

    toggleMaximize(winObject) {
        if (winObject.isMaximized) {
            // Restore
            const rect = winObject.preMaximizeRect;
            winObject.element.style.left = rect.left + 'px';
            winObject.element.style.top = rect.top + 'px';
            winObject.element.style.width = rect.width + 'px';
            winObject.element.style.height = rect.height + 'px';
            winObject.isMaximized = false;
        } else {
            // Maximize
            winObject.preMaximizeRect = {
                left: winObject.element.offsetLeft,
                top: winObject.element.offsetTop,
                width: winObject.element.offsetWidth,
                height: winObject.element.offsetHeight
            };
            winObject.element.style.left = '0';
            winObject.element.style.top = '0';
            winObject.element.style.width = '100%';
            winObject.element.style.height = '100%';
            winObject.isMaximized = true;
        }
    }
    
    startMove(e, winObject) {
        if (e.target.closest('.window-controls')) return; // Ignore clicks on controls
        if (winObject.isMaximized) return; // Can't move maximized window (maybe drag to restore? Todo)

        this.dragState = {
            type: 'move',
            window: winObject,
            startX: e.clientX,
            startY: e.clientY,
            initialRect: {
                left: winObject.element.offsetLeft,
                top: winObject.element.offsetTop
            }
        };
        
        this.setActiveWindow(winObject);
        // Add overlay to prevent iframe stealing mouse events
        this.addOverlay();
    }
    
    startResize(e, winObject, dir) {
        e.stopPropagation();
        if (winObject.isMaximized) return;

        this.dragState = {
            type: 'resize',
            window: winObject,
            startX: e.clientX,
            startY: e.clientY,
            initialRect: {
                width: winObject.element.offsetWidth,
                height: winObject.element.offsetHeight,
                left: winObject.element.offsetLeft,
                top: winObject.element.offsetTop
            },
            handle: dir
        };
        
        this.setActiveWindow(winObject);
        this.addOverlay();
    }
    
    handleMouseMove(e) {
        if (!this.dragState) return;
        
        const { type, window: win, startX, startY, initialRect } = this.dragState;
        const dx = e.clientX - startX;
        const dy = e.clientY - startY;
        
        if (type === 'move') {
            let newX = initialRect.left + dx;
            let newY = initialRect.top + dy;
            
            // Check snapping
            this.checkSnap(e.clientX, e.clientY);
            
            win.element.style.left = newX + 'px';
            win.element.style.top = newY + 'px';
            
        } else if (type === 'resize') {
            const handle = this.dragState.handle;
            let newW = initialRect.width;
            let newH = initialRect.height;
            let newX = initialRect.left;
            let newY = initialRect.top;
            
            if (handle.includes('e')) newW = initialRect.width + dx;
            if (handle.includes('w')) {
                newW = initialRect.width - dx;
                newX = initialRect.left + dx;
            }
            if (handle.includes('s')) newH = initialRect.height + dy;
            if (handle.includes('n')) {
                newH = initialRect.height - dy;
                newY = initialRect.top + dy;
            }
            
            if (newW > 200) {
                win.element.style.width = newW + 'px';
                win.element.style.left = newX + 'px';
            }
            if (newH > 150) {
                win.element.style.height = newH + 'px';
                win.element.style.top = newY + 'px';
            }
        }
    }
    
    handleMouseUp(e) {
        if (!this.dragState) return;
        
        if (this.dragState.type === 'move') {
            // Apply snap if active
            if (this.snapGhostActive) {
                this.applySnap(this.dragState.window);
            }
        }
        
        this.dragState = null;
        this.removeOverlay();
        this.hideSnapGhost();
    }
    
    checkSnap(x, y) {
        const containerRect = this.container.getBoundingClientRect();
        const threshold = 20;
        
        let snapType = null;
        
        // Relative to window client area
        if (x < threshold) snapType = 'left';
        else if (x > containerRect.width - threshold) snapType = 'right';
        else if (y < threshold + 90) snapType = 'top'; // Offset for titlebar/nav
        else if (y > containerRect.height - threshold) snapType = 'bottom';
        
        // Improve snap detection logic
        // Left
        if (x < containerRect.left + threshold) snapType = 'left';
        // Right
        else if (x > containerRect.right - threshold) snapType = 'right';
        // Top
        else if (y < containerRect.top + threshold) snapType = 'top';
        // Bottom
        else if (y > containerRect.bottom - threshold) snapType = 'bottom';
        
        if (snapType) {
            this.showSnapGhost(snapType);
        } else {
            this.hideSnapGhost();
        }
    }
    
    showSnapGhost(type) {
        this.snapGhostActive = type;
        this.ghost.style.display = 'block';
        
        if (type === 'left') {
            this.ghost.style.top = '0';
            this.ghost.style.left = '0';
            this.ghost.style.width = '50%';
            this.ghost.style.height = '100%';
        } else if (type === 'right') {
            this.ghost.style.top = '0';
            this.ghost.style.left = '50%';
            this.ghost.style.width = '50%';
            this.ghost.style.height = '100%';
        } else if (type === 'top') {
            this.ghost.style.top = '0';
            this.ghost.style.left = '0';
            this.ghost.style.width = '100%';
            this.ghost.style.height = '50%'; 
        } else if (type === 'bottom') {
            this.ghost.style.top = '50%';
            this.ghost.style.left = '0';
            this.ghost.style.width = '100%';
            this.ghost.style.height = '50%';
        }
    }
    
    hideSnapGhost() {
        this.snapGhostActive = null;
        this.ghost.style.display = 'none';
    }
    
    applySnap(win) {
        if (!this.snapGhostActive) return;
        
        const type = this.snapGhostActive;
        
        win.preMaximizeRect = {
            left: win.element.offsetLeft,
            top: win.element.offsetTop,
            width: win.element.offsetWidth,
            height: win.element.offsetHeight
        };
        
        win.element.style.top = this.ghost.style.top;
        win.element.style.left = this.ghost.style.left;
        win.element.style.width = this.ghost.style.width;
        win.element.style.height = this.ghost.style.height;
    }

    addOverlay() {
        // Adds a transparent overlay to capture mouse events over webviews
        this.windows.forEach(w => {
            w.element.style.pointerEvents = 'none';
        });
        document.body.style.cursor = this.dragState.type === 'move' ? 'grabbing' : (this.dragState.handle ? this.dragState.handle + '-resize' : 'default');
    }
    
    removeOverlay() {
        this.windows.forEach(w => {
            w.element.style.pointerEvents = 'auto';
        });
        document.body.style.cursor = 'default';
    }
}

module.exports = WindowManager;
