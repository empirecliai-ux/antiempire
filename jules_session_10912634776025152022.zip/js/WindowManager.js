class WindowManager {
    constructor(container) {
        this.container = container;
        this.windows = [];
        this.activeWindow = null;
        this.zIndexCounter = 10;
        
        // Drag/Resize state
        this.isDragging = false;
        this.isResizing = false;
        this.dragTarget = null;
        this.resizeTarget = null;
        this.resizeType = null;
        this.startX = 0;
        this.startY = 0;
        this.initialLeft = 0;
        this.initialTop = 0;
        this.initialWidth = 0;
        this.initialHeight = 0;

        // Global mouse events for drag/resize
        document.addEventListener('mousemove', (e) => this.handleMouseMove(e));
        document.addEventListener('mouseup', () => this.handleMouseUp());
    }

    createWindow(url = 'about:blank') {
        const id = 'win-' + Date.now();
        const win = document.createElement('div');
        win.className = 'window-pane';
        win.id = id;
        
        // Initial Position (cascade)
        const offset = (this.windows.length * 30) % 200;
        win.style.left = (50 + offset) + 'px';
        win.style.top = (50 + offset) + 'px';
        win.style.width = '800px';
        win.style.height = '500px';

        // Header
        const header = document.createElement('div');
        header.className = 'window-header';
        
        const title = document.createElement('span');
        title.className = 'window-title';
        title.textContent = 'New Tab';
        
        const controls = document.createElement('div');
        controls.className = 'window-controls-mini';
        
        const closeBtn = document.createElement('button');
        closeBtn.className = 'window-btn window-close';
        closeBtn.onclick = (e) => {
            e.stopPropagation();
            this.closeWindow(id);
        };
        
        controls.appendChild(closeBtn);
        header.appendChild(title);
        header.appendChild(controls);

        // Content
        const content = document.createElement('div');
        content.className = 'window-content';
        
        const webview = document.createElement('webview');
        webview.src = url;
        webview.setAttribute('allowpopups', '');
        
        // Webview events
        webview.addEventListener('dom-ready', () => {
            title.textContent = webview.getTitle();
            this.updateAddressBar();
        });
        
        webview.addEventListener('did-navigate', (e) => {
            title.textContent = webview.getTitle();
            if (this.activeWindow && this.activeWindow.id === id) {
                this.updateAddressBar();
            }
        });

        webview.addEventListener('page-title-updated', (e) => {
            title.textContent = e.title;
        });

        content.appendChild(webview);

        // Resize Handles
        const resizeE = document.createElement('div');
        resizeE.className = 'resize-handle resize-e';
        const resizeS = document.createElement('div');
        resizeS.className = 'resize-handle resize-s';
        const resizeSE = document.createElement('div');
        resizeSE.className = 'resize-handle resize-se';

        // Assemble
        win.appendChild(header);
        win.appendChild(content);
        win.appendChild(resizeE);
        win.appendChild(resizeS);
        win.appendChild(resizeSE);
        
        this.container.appendChild(win);
        
        const windowObj = { id, element: win, webview, header };
        this.windows.push(windowObj);
        
        // Event Listeners
        win.addEventListener('mousedown', () => this.setActiveWindow(id));
        header.addEventListener('mousedown', (e) => this.startDrag(e, windowObj));
        resizeE.addEventListener('mousedown', (e) => this.startResize(e, windowObj, 'e'));
        resizeS.addEventListener('mousedown', (e) => this.startResize(e, windowObj, 's'));
        resizeSE.addEventListener('mousedown', (e) => this.startResize(e, windowObj, 'se'));

        this.setActiveWindow(id);
        return windowObj;
    }

    closeWindow(id) {
        const index = this.windows.findIndex(w => w.id === id);
        if (index > -1) {
            const win = this.windows[index];
            win.element.remove();
            this.windows.splice(index, 1);
            
            if (this.activeWindow && this.activeWindow.id === id) {
                this.activeWindow = this.windows.length > 0 ? this.windows[this.windows.length - 1] : null;
                if (this.activeWindow) {
                    this.setActiveWindow(this.activeWindow.id);
                } else {
                    // Reset UI if no windows
                    document.getElementById('address-bar').value = '';
                }
            }
        }
    }

    setActiveWindow(id) {
        this.windows.forEach(w => {
            w.element.classList.remove('active');
            w.element.style.zIndex = 1;
        });
        
        const win = this.windows.find(w => w.id === id);
        if (win) {
            this.activeWindow = win;
            win.element.classList.add('active');
            win.element.style.zIndex = ++this.zIndexCounter;
            this.updateAddressBar();
        }
    }

    updateAddressBar() {
        if (!this.activeWindow) return;
        try {
            const url = this.activeWindow.webview.getURL();
            const addressBar = document.getElementById('address-bar');
            if (addressBar && url !== 'about:blank') {
                addressBar.value = url;
            }
        } catch (e) {
            console.error('Error updating address bar:', e);
        }
    }

    startDrag(e, windowObj) {
        if (e.target.closest('.window-controls-mini')) return; // Ignore if clicking controls
        this.isDragging = true;
        this.dragTarget = windowObj;
        this.startX = e.clientX;
        this.startY = e.clientY;
        this.initialLeft = windowObj.element.offsetLeft;
        this.initialTop = windowObj.element.offsetTop;
        
        // Temporarily disable pointer events on webview to allow dragging over it
        windowObj.webview.style.pointerEvents = 'none';
    }

    startResize(e, windowObj, type) {
        e.stopPropagation();
        this.isResizing = true;
        this.resizeTarget = windowObj;
        this.resizeType = type;
        this.startX = e.clientX;
        this.startY = e.clientY;
        this.initialWidth = windowObj.element.offsetWidth;
        this.initialHeight = windowObj.element.offsetHeight;
        
        windowObj.webview.style.pointerEvents = 'none';
    }

    handleMouseMove(e) {
        if (this.isDragging && this.dragTarget) {
            const dx = e.clientX - this.startX;
            const dy = e.clientY - this.startY;
            
            let newLeft = this.initialLeft + dx;
            let newTop = this.initialTop + dy;
            
            // Snap to grid (20px)
            if (Math.abs(newLeft % 20) < 10) newLeft = Math.round(newLeft / 20) * 20;
            if (Math.abs(newTop % 20) < 10) newTop = Math.round(newTop / 20) * 20;

            // Boundaries
            if (newTop < 0) newTop = 0;
            if (newLeft < 0) newLeft = 0;
            
            this.dragTarget.element.style.left = newLeft + 'px';
            this.dragTarget.element.style.top = newTop + 'px';
        } else if (this.isResizing && this.resizeTarget) {
            const dx = e.clientX - this.startX;
            const dy = e.clientY - this.startY;
            
            if (this.resizeType === 'e' || this.resizeType === 'se') {
                this.resizeTarget.element.style.width = Math.max(200, this.initialWidth + dx) + 'px';
            }
            if (this.resizeType === 's' || this.resizeType === 'se') {
                this.resizeTarget.element.style.height = Math.max(150, this.initialHeight + dy) + 'px';
            }
        }
    }

    handleMouseUp() {
        if (this.isDragging && this.dragTarget) {
            this.dragTarget.webview.style.pointerEvents = 'auto';
            this.isDragging = false;
            this.dragTarget = null;
        }
        if (this.isResizing && this.resizeTarget) {
            this.resizeTarget.webview.style.pointerEvents = 'auto';
            this.isResizing = false;
            this.resizeTarget = null;
        }
    }
}
