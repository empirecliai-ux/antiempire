const { ipcRenderer } = require('electron');

// UI Elements
const addressBar = document.getElementById('address-bar');
const loadingScreen = document.getElementById('loading-screen');
const novaBtn = document.getElementById('nova-btn');
const voiceOverlay = document.getElementById('voice-overlay');
const windowContainer = document.getElementById('window-container');

// Controls
const backBtn = document.getElementById('back-btn');
const forwardBtn = document.getElementById('forward-btn');
const refreshBtn = document.getElementById('refresh-btn');
const addWindowBtn = document.getElementById('add-window-btn');

// Window Controls
const minBtn = document.getElementById('min-btn');
const maxBtn = document.getElementById('max-btn');
const closeBtn = document.getElementById('close-btn');

// Initialize Window Manager
const windowManager = new WindowManager(windowContainer);

class EmpireNavigatorRenderer {
    constructor() {
        this.isListening = false;
        this.recognition = null;
        this.initializeVoiceRecognition();
        this.setupEventListeners();
        this.hideLoadingScreen();
        
        // Create initial window
        windowManager.createWindow('https://github.com');
    }

    initializeVoiceRecognition() {
        if ('webkitSpeechRecognition' in window) {
            this.recognition = new webkitSpeechRecognition();
            this.recognition.continuous = false;
            this.recognition.interimResults = false;
            this.recognition.lang = 'en-US';

            this.recognition.onstart = () => {
                console.log('🎤 Nova listening...');
                this.isListening = true;
                novaBtn.classList.add('listening');
                voiceOverlay.classList.add('active');
            };

            this.recognition.onresult = (event) => {
                const command = event.results[0][0].transcript;
                console.log('🗣️ Voice Command:', command);
                this.handleVoiceCommand(command);
            };

            this.recognition.onend = () => {
                this.isListening = false;
                novaBtn.classList.remove('listening');
                voiceOverlay.classList.remove('active');
            };

            this.recognition.onerror = (event) => {
                console.error('Voice recognition error:', event.error);
                this.isListening = false;
                novaBtn.classList.remove('listening');
                voiceOverlay.classList.remove('active');
            };
        }
    }

    setupEventListeners() {
        // Window Controls
        minBtn.addEventListener('click', () => ipcRenderer.invoke('window-minimize'));
        maxBtn.addEventListener('click', () => ipcRenderer.invoke('window-maximize'));
        closeBtn.addEventListener('click', () => ipcRenderer.invoke('window-close'));

        // Navigation
        addWindowBtn.addEventListener('click', () => windowManager.createWindow());
        
        backBtn.addEventListener('click', () => {
            if (windowManager.activeWindow) windowManager.activeWindow.webview.goBack();
        });
        
        forwardBtn.addEventListener('click', () => {
            if (windowManager.activeWindow) windowManager.activeWindow.webview.goForward();
        });
        
        refreshBtn.addEventListener('click', () => {
            if (windowManager.activeWindow) windowManager.activeWindow.webview.reload();
        });

        // Address Bar
        addressBar.addEventListener('keypress', (event) => {
            if (event.key === 'Enter') {
                const url = addressBar.value;
                this.navigateToSite(url);
            }
        });

        // Societas Toggle
        document.getElementById('societas-toggle').addEventListener('click', () => {
            ipcRenderer.invoke('empire-command', 'show societas');
        });
        
        // Nova
        novaBtn.addEventListener('click', () => this.activateNova());
        
        // Empire status updates
        setInterval(() => {
            this.updateEmpireStatus();
        }, 5000);
    }

    hideLoadingScreen() {
        setTimeout(() => {
            loadingScreen.style.opacity = '0';
            setTimeout(() => {
                loadingScreen.style.display = 'none';
            }, 500);
        }, 3000);
    }

    activateNova() {
        if (this.recognition && !this.isListening) {
            this.recognition.start();
        }
    }

    handleVoiceCommand(command) {
        const cmd = command.toLowerCase();
        
        // Update voice overlay
        document.getElementById('voice-command-text').textContent = `"${command}"`;
        
        // Send to main process
        ipcRenderer.invoke('empire-command', command);
        
        // Handle locally
        if (cmd.includes('navigate to') || cmd.includes('go to')) {
            const site = cmd.replace(/navigate to|go to/g, '').trim();
            this.navigateToSite(site);
        } else if (cmd.includes('new tab') || cmd.includes('new window')) {
            windowManager.createWindow();
        } else if (cmd.includes('close tab') || cmd.includes('close window')) {
             if (windowManager.activeWindow) {
                 windowManager.closeWindow(windowManager.activeWindow.id);
             }
        } else if (cmd.includes('refresh') || cmd.includes('reload')) {
            if (windowManager.activeWindow) windowManager.activeWindow.webview.reload();
        } else if (cmd.includes('back')) {
            if (windowManager.activeWindow) windowManager.activeWindow.webview.goBack();
        } else if (cmd.includes('forward')) {
            if (windowManager.activeWindow) windowManager.activeWindow.webview.goForward();
        }
    }

    navigateToSite(site) {
        if (!windowManager.activeWindow) {
             windowManager.createWindow();
        }

        let url = site;
        
        if (!url.includes('http')) {
            if (url.includes('.') && !url.includes(' ')) {
                url = `https://${url}`;
            } else {
                const shortcuts = {
                    'github': 'https://github.com',
                    'gmail': 'https://gmail.com',
                    'teams': 'https://teams.microsoft.com',
                    'discord': 'https://discord.com',
                    'youtube': 'https://youtube.com'
                };
                url = shortcuts[url] || `https://www.google.com/search?q=${encodeURIComponent(url)}`;
            }
        }
        
        windowManager.activeWindow.webview.src = url;
        addressBar.value = url;
    }

    async updateEmpireStatus() {
        try {
            const status = await ipcRenderer.invoke('get-empire-status');
            // Update agent count and status indicators
            document.getElementById('agent-count').textContent = '47 AGENTS';
        } catch (error) {
            console.error('Failed to update Empire status:', error);
        }
    }
}

// Initialize Empire Navigator
const empireNavigator = new EmpireNavigatorRenderer();

// Empire Easter Eggs
document.addEventListener('keydown', (event) => {
    // Ctrl+Shift+E = Empire Command Palette
    if (event.ctrlKey && event.shiftKey && event.key === 'E') {
        empireNavigator.activateNova();
    }
    
    // Ctrl+Shift+S = Show Societas
    if (event.ctrlKey && event.shiftKey && event.key === 'S') {
        ipcRenderer.invoke('empire-command', 'show societas');
    }
    
    // Ctrl+N = New Window
    if (event.ctrlKey && event.key === 'n') {
        windowManager.createWindow();
    }
});

console.log('🏛️ Empire Navigator initialized');
console.log('🎤 Say "Hey Nova" or click the microphone');
