const fs = require('fs');

console.log('Running security verification...');

// Check main.js
const mainJs = fs.readFileSync('main.js', 'utf8');
if (mainJs.includes('nodeIntegration: false') &&
    mainJs.includes('contextIsolation: true') &&
    mainJs.includes("preload: path.join(__dirname, 'preload.js')")) {
    console.log('✅ main.js: Secure webPreferences found.');
} else {
    console.error('❌ main.js: Insecure settings or missing preload!');
    process.exit(1);
}

// Check preload.js
const preloadJs = fs.readFileSync('preload.js', 'utf8');
if (preloadJs.includes('contextBridge.exposeInMainWorld') &&
    preloadJs.includes('electronAPI')) {
    console.log('✅ preload.js: API exposure found.');
} else {
    console.error('❌ preload.js: Missing contextBridge or API exposure!');
    process.exit(1);
}

// Check index.html
const indexHtml = fs.readFileSync('index.html', 'utf8');
if (indexHtml.includes('<script src="js/WindowManager.js"></script>') &&
    indexHtml.indexOf('js/WindowManager.js') < indexHtml.indexOf('js/renderer.js')) {
    console.log('✅ index.html: WindowManager loaded before renderer.');
} else {
    console.error('❌ index.html: Incorrect script loading order!');
    process.exit(1);
}

// Check js/renderer.js
const rendererJs = fs.readFileSync('js/renderer.js', 'utf8');
if (!rendererJs.includes("require('electron')") &&
    rendererJs.includes('window.electronAPI.minimize()')) {
    console.log('✅ js/renderer.js: Node integration usage removed and API usage added.');
} else {
    console.error('❌ js/renderer.js: Still contains require or missing API usage!');
    process.exit(1);
}

console.log('🎉 All security checks passed!');
