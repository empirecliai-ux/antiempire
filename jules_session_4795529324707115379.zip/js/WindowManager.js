class WindowManager {
    constructor(containerId) {
        this.container = document.getElementById(containerId);
        this.windows = [];
        this.activeWindow = null;
        this.windowCount = 0;
        this.snapThreshold = 20; // px
        
        // Drag state
        this.isDragging = false;
        this.draggedWindow = null;
        this.startX = 0;
        this.startY = 0;
        this.initialLeft = 0;
        this.initialTop = 0;

        // Bind methods
        this.drag = this.drag.bind(this);
        this.stopDrag = this.stopDrag.bind(this);
    }

    createWindow(url = 'about:blank') {
        const id = `window-${this.windowCount++}`;
        const win = document.createElement('div');
        win.className = 'browser-window';
        win.id = id;
        win.style.position = 'absolute';
        
        // Initial positioning
        const offset = (this.windowCount * 20) % 200;
        win.style.top = `${50 + offset}px`;
        win.style.left = `${50 + offset}px`;
        win.style.width = '800px';
        win.style.height = '600px';
        win.style.display = 'flex';
        win.style.flexDirection = 'column';
        win.style.boxShadow = '0 0 20px rgba(0,0,0,0.5)';
        win.style.border = '1px solid #334155';
        win.style.backgroundColor = '#0f172a';
        win.style.zIndex = this.getWindowZIndex();

        // Header (Drag Handle)
        const header = document.createElement('div');
        header.className = 'window-header';
        header.style.height = '32px';
        header.style.background = '#1e293b';
        header.style.display = 'flex';
        header.style.alignItems = 'center';
        header.style.padding = '0 10px';
        header.style.cursor = 'grab';
        header.style.userSelect = 'none';
        header.style.borderBottom = '1px solid #334155';
        
        const title = document.createElement('span');
        title.innerText = 'Empire Node';
        title.style.fontSize = '12px';
        title.style.color = '#94a3b8';
        title.style.flex = '1';
        
        const controls = document.createElement('div');
        controls.className = 'window-controls';
        
        const closeBtn = document.createElement('button');
        closeBtn.innerHTML = '×';
        closeBtn.style.background = 'none';
        closeBtn.style.border = 'none';
        closeBtn.style.color = '#ef4444';
        closeBtn.style.fontSize = '18px';
        closeBtn.style.cursor = 'pointer';
        closeBtn.style.padding = '0 5px';
        closeBtn.onclick = (e) => {
            e.stopPropagation();
            this.closeWindow(id);
        };
        
        controls.appendChild(closeBtn);
        header.appendChild(title);
        header.appendChild(controls);
        
        // Webview Content
        const webviewContainer = document.createElement('div');
        webviewContainer.style.flex = '1';
        webviewContainer.style.position = 'relative';
        webviewContainer.style.background = '#000';
        
        const webview = document.createElement('webview');
        webview.src = url;
        webview.style.width = '100%';
        webview.style.height = '100%';
        webview.setAttribute('allowpopups', '');
        
        webviewContainer.appendChild(webview);
        win.appendChild(header);
        win.appendChild(webviewContainer);
        
        this.container.appendChild(win);
        
        const windowObj = { id, element: win, webview, header };
        this.windows.push(windowObj);
        
        this.setActiveWindow(id);
        
        // Event Listeners
        win.addEventListener('mousedown', () => this.setActiveWindow(id));
        
        // Drag listener
        header.addEventListener('mousedown', (e) => this.startDrag(e, windowObj));
        
        // Webview events for title/url updates
        webview.addEventListener('dom-ready', () => {
             title.innerText = webview.getTitle();
             if (this.activeWindow && this.activeWindow.id === id) {
                 this.updateAddressBar(webview.getURL());
             }
        });
        
        webview.addEventListener('did-navigate', (e) => {
            if (this.activeWindow && this.activeWindow.id === id) {
                 this.updateAddressBar(e.url);
            }
        });
        
        webview.addEventListener('page-title-updated', (e) => {
            title.innerText = e.title;
        });

        return windowObj;
    }

    closeWindow(id) {
        const index = this.windows.findIndex(w => w.id === id);
        if (index > -1) {
            const win = this.windows[index];
            win.element.remove();
            this.windows.splice(index, 1);
            
            if (this.activeWindow && this.activeWindow.id === id) {
                // Activate the last remaining window if any
                if (this.windows.length > 0) {
                    this.setActiveWindow(this.windows[this.windows.length - 1].id);
                } else {
                    this.activeWindow = null;
                    this.updateAddressBar('');
                }
            }
        }
    }

    setActiveWindow(id) {
        const win = this.windows.find(w => w.id === id);
        if (win) {
            this.activeWindow = win;
            
            // Manage Z-Index
            this.windows.forEach(w => {
                w.element.style.borderColor = '#334155';
                w.element.style.zIndex = parseInt(w.element.style.zIndex) || 1;
            });
            
            // Active window gets highest Z and highlight border
            win.element.style.zIndex = 1000;
            win.element.style.borderColor = '#06b6d4';
            
            this.updateAddressBar(win.webview.getURL());
            this.updateNavButtons();
        }
    }
    
    // Drag Logic
    startDrag(e, windowObj) {
        // Only trigger on left click
        if (e.button !== 0) return;
        
        this.isDragging = true;
        this.draggedWindow = windowObj;
        this.startX = e.clientX;
        this.startY = e.clientY;
        
        const rect = windowObj.element.getBoundingClientRect();
        // We need coordinates relative to container (which is relative or static, but element is absolute)
        // If container is body or 100vh div, rect.left is fine if not scrolled
        this.initialLeft = windowObj.element.offsetLeft;
        this.initialTop = windowObj.element.offsetTop;
        
        windowObj.header.style.cursor = 'grabbing';
        
        // Add global listeners
        document.addEventListener('mousemove', this.drag);
        document.addEventListener('mouseup', this.stopDrag);
    }
    
    drag(e) {
        if (!this.isDragging || !this.draggedWindow) return;
        
        e.preventDefault();
        
        const dx = e.clientX - this.startX;
        const dy = e.clientY - this.startY;
        
        let newLeft = this.initialLeft + dx;
        let newTop = this.initialTop + dy;
        
        // Snapping Logic
        const containerRect = this.container.getBoundingClientRect();
        const winRect = this.draggedWindow.element.getBoundingClientRect(); // Current rect
        // But we want to predict new rect based on newLeft/Top
        const winWidth = winRect.width;
        const winHeight = winRect.height;

        // Snap to left edge
        if (Math.abs(newLeft) < this.snapThreshold) {
            newLeft = 0;
        }
        
        // Snap to top edge
        if (Math.abs(newTop) < this.snapThreshold) {
            newTop = 0;
        }
        
        // Snap to right edge (container width - win width)
        // Note: element.offsetLeft is relative to offsetParent. 
        // Assuming container is the offsetParent.
        const containerWidth = this.container.clientWidth;
        if (Math.abs((newLeft + winWidth) - containerWidth) < this.snapThreshold) {
            newLeft = containerWidth - winWidth;
        }
        
        // Snap to bottom edge
        const containerHeight = this.container.clientHeight;
        if (Math.abs((newTop + winHeight) - containerHeight) < this.snapThreshold) {
            newTop = containerHeight - winHeight;
        }
        
        // Apply new position
        this.draggedWindow.element.style.left = `${newLeft}px`;
        this.draggedWindow.element.style.top = `${newTop}px`;
    }
    
    stopDrag() {
        if (this.draggedWindow) {
            this.draggedWindow.header.style.cursor = 'grab';
        }
        this.isDragging = false;
        this.draggedWindow = null;
        
        document.removeEventListener('mousemove', this.drag);
        document.removeEventListener('mouseup', this.stopDrag);
    }
    
    getWindowZIndex() {
        return this.windows.length + 10;
    }
    
    getActiveWebview() {
        return this.activeWindow ? this.activeWindow.webview : null;
    }
    
    updateAddressBar(url) {
        const addressBar = document.getElementById('address-bar');
        if (addressBar) {
            addressBar.value = url;
        }
    }
    
    updateNavButtons() {
        const backBtn = document.getElementById('back-btn');
        const fwdBtn = document.getElementById('forward-btn');
        const webview = this.getActiveWebview();
        
        if (webview && backBtn && fwdBtn) {
            backBtn.disabled = !webview.canGoBack();
            fwdBtn.disabled = !webview.canGoForward();
        }
    }
}

module.exports = WindowManager;
