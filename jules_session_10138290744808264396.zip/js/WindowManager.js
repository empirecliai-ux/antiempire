class WindowManager {
    constructor(containerId) {
        this.container = document.getElementById(containerId);
        this.windows = [];
        this.activeWindow = null;
        this.zIndexCounter = 10;
        this.snapGrid = 20; // Snap to 20px grid
    }

    createWindow(url = 'about:blank') {
        const pane = document.createElement('div');
        pane.className = 'window-pane';
        
        // Initial position logic (cascade)
        const offset = (this.windows.length * 30) % 150;
        pane.style.left = `${50 + offset}px`;
        pane.style.top = `${50 + offset}px`;
        pane.style.width = '800px';
        pane.style.height = '600px';
        
        // Structure
        pane.innerHTML = `
            <div class="window-header">
                <span class="window-title">Loading...</span>
                <div class="window-controls">
                    <button class="window-control-btn minimize" title="Rollup"></button>
                    <button class="window-control-btn maximize" title="Maximize"></button>
                    <button class="window-control-btn close" title="Close"></button>
                </div>
            </div>
            <div class="window-content">
                <webview src="${url}" allowpopups></webview>
            </div>
            <div class="resizer resizer-nw"></div>
            <div class="resizer resizer-ne"></div>
            <div class="resizer resizer-sw"></div>
            <div class="resizer resizer-se"></div>
            <div class="resizer resizer-n"></div>
            <div class="resizer resizer-s"></div>
            <div class="resizer resizer-e"></div>
            <div class="resizer resizer-w"></div>
        `;

        this.container.appendChild(pane);
        this.windows.push(pane);

        const header = pane.querySelector('.window-header');
        const webview = pane.querySelector('webview');
        
        // Event Listeners
        this.makeDraggable(pane, header);
        this.makeResizable(pane);
        
        pane.addEventListener('mousedown', () => {
            this.setActiveWindow(pane);
        });

        // Window Controls
        pane.querySelector('.close').addEventListener('click', (e) => {
            e.stopPropagation();
            this.closeWindow(pane);
        });

        pane.querySelector('.maximize').addEventListener('click', (e) => {
            e.stopPropagation();
            this.toggleMaximize(pane);
        });

        pane.querySelector('.minimize').addEventListener('click', (e) => {
            e.stopPropagation();
            this.toggleShade(pane);
        });

        // Webview events
        webview.addEventListener('dom-ready', () => {
             pane.querySelector('.window-title').textContent = webview.getTitle();
        });
        webview.addEventListener('page-title-updated', (e) => {
            pane.querySelector('.window-title').textContent = e.title;
        });
        webview.addEventListener('did-navigate', (e) => {
             // Update address bar if this is active window
             if (this.activeWindow === pane) {
                 const addressBar = document.getElementById('address-bar');
                 if (addressBar) addressBar.value = e.url;
             }
        });
        // Also update when switching to an existing page (did-navigate-in-page)
        webview.addEventListener('did-navigate-in-page', (e) => {
             if (this.activeWindow === pane) {
                 const addressBar = document.getElementById('address-bar');
                 if (addressBar) addressBar.value = e.url;
             }
        });

        this.setActiveWindow(pane);
        return pane;
    }

    closeWindow(pane) {
        pane.remove();
        this.windows = this.windows.filter(w => w !== pane);
        if (this.activeWindow === pane) {
            this.activeWindow = this.windows.length > 0 ? this.windows[this.windows.length - 1] : null;
            if (this.activeWindow) this.setActiveWindow(this.activeWindow);
        }
    }

    toggleMaximize(pane) {
        if (pane.dataset.maximized === 'true') {
            // Restore
            pane.style.top = pane.dataset.prevTop;
            pane.style.left = pane.dataset.prevLeft;
            pane.style.width = pane.dataset.prevWidth;
            pane.style.height = pane.dataset.prevHeight;
            pane.dataset.maximized = 'false';
        } else {
            // Maximize
            pane.dataset.prevTop = pane.style.top;
            pane.dataset.prevLeft = pane.style.left;
            pane.dataset.prevWidth = pane.style.width;
            pane.dataset.prevHeight = pane.style.height;

            pane.style.top = '0';
            pane.style.left = '0';
            pane.style.width = '100%';
            pane.style.height = '100%';
            pane.dataset.maximized = 'true';
        }
    }

    toggleShade(pane) {
         const content = pane.querySelector('.window-content');
         if (content.style.display === 'none') {
             content.style.display = 'block';
             pane.style.height = pane.dataset.prevHeight || '600px';
         } else {
             pane.dataset.prevHeight = pane.style.height;
             content.style.display = 'none';
             pane.style.height = 'auto';
         }
    }

    setActiveWindow(pane) {
        if (this.activeWindow) {
            this.activeWindow.classList.remove('active');
        }
        this.activeWindow = pane;
        pane.classList.add('active');
        this.zIndexCounter++;
        pane.style.zIndex = this.zIndexCounter;
        
        // Update address bar
        const webview = pane.querySelector('webview');
        const addressBar = document.getElementById('address-bar');
        if (webview && addressBar) {
            addressBar.value = webview.getURL();
        }
    }

    makeDraggable(pane, handle) {
        let isDragging = false;
        let startX, startY, initialLeft, initialTop;

        handle.addEventListener('mousedown', (e) => {
            if (e.target.closest('.window-controls')) return; // Don't drag if clicking controls
            
            isDragging = true;
            startX = e.clientX;
            startY = e.clientY;
            initialLeft = pane.offsetLeft;
            initialTop = pane.offsetTop;
            
            // Bring to front
            this.setActiveWindow(pane);
            
            document.addEventListener('mousemove', onMouseMove);
            document.addEventListener('mouseup', onMouseUp);
        });

        const onMouseMove = (e) => {
            if (!isDragging) return;
            const dx = e.clientX - startX;
            const dy = e.clientY - startY;
            
            let newLeft = initialLeft + dx;
            let newTop = initialTop + dy;

            // Snap logic
            newLeft = Math.round(newLeft / this.snapGrid) * this.snapGrid;
            newTop = Math.round(newTop / this.snapGrid) * this.snapGrid;
            
            // Boundaries
            const containerRect = this.container.getBoundingClientRect();
            // Allow some overhang, but keep title bar accessible
            if (newTop < 0) newTop = 0;
            if (newTop > containerRect.height - 30) newTop = containerRect.height - 30;
            if (newLeft + pane.offsetWidth < 30) newLeft = 30 - pane.offsetWidth;
            if (newLeft > containerRect.width - 30) newLeft = containerRect.width - 30;

            pane.style.left = `${newLeft}px`;
            pane.style.top = `${newTop}px`;
        };

        const onMouseUp = () => {
            isDragging = false;
            document.removeEventListener('mousemove', onMouseMove);
            document.removeEventListener('mouseup', onMouseUp);
        };
    }

    makeResizable(pane) {
        const resizers = pane.querySelectorAll('.resizer');
        
        resizers.forEach(resizer => {
            resizer.addEventListener('mousedown', (e) => {
                e.preventDefault();
                e.stopPropagation();
                
                // Bring to front
                this.setActiveWindow(pane);

                const direction = resizer.className.replace('resizer resizer-', '');
                const startX = e.clientX;
                const startY = e.clientY;
                const startWidth = parseInt(document.defaultView.getComputedStyle(pane).width, 10);
                const startHeight = parseInt(document.defaultView.getComputedStyle(pane).height, 10);
                const startLeft = pane.offsetLeft;
                const startTop = pane.offsetTop;

                const onMouseMove = (e) => {
                    const dx = e.clientX - startX;
                    const dy = e.clientY - startY;
                    
                    if (direction.includes('e')) {
                        pane.style.width = `${startWidth + dx}px`;
                    }
                    if (direction.includes('s')) {
                        pane.style.height = `${startHeight + dy}px`;
                    }
                    if (direction.includes('w')) {
                        pane.style.width = `${startWidth - dx}px`;
                        pane.style.left = `${startLeft + dx}px`;
                    }
                    if (direction.includes('n')) {
                        pane.style.height = `${startHeight - dy}px`;
                        pane.style.top = `${startTop + dy}px`;
                    }
                };

                const onMouseUp = () => {
                    document.removeEventListener('mousemove', onMouseMove);
                    document.removeEventListener('mouseup', onMouseUp);
                };

                document.addEventListener('mousemove', onMouseMove);
                document.addEventListener('mouseup', onMouseUp);
            });
        });
    }

    getActiveWebView() {
        if (this.activeWindow) {
            return this.activeWindow.querySelector('webview');
        }
        return null;
    }
}

// Export for use in renderer
if (typeof module !== 'undefined') {
    module.exports = WindowManager;
} else {
    window.WindowManager = WindowManager;
}
