const { ipcRenderer } = require('electron');
const WindowManager = require('./WindowManager');

const addressBar = document.getElementById('address-bar');
const loadingScreen = document.getElementById('loading-screen');
const novaBtn = document.getElementById('nova-btn');
const voiceOverlay = document.getElementById('voice-overlay');

// Empire Navigator Core 
class EmpireNavigatorRenderer { 
    constructor() { 
        this.windowManager = new WindowManager('browser-content');
        this.isListening = false; 
        this.recognition = null; 
        
        // Initialize with one window
        this.windowManager.createWindow('https://www.google.com');

        this.initializeVoiceRecognition(); 
        this.setupEventListeners(); 
        this.hideLoadingScreen(); 
    } 

    initializeVoiceRecognition() { 
        if ('webkitSpeechRecognition' in window) { 
            this.recognition = new webkitSpeechRecognition(); 
            this.recognition.continuous = false; 
            this.recognition.interimResults = false; 
            this.recognition.lang = 'en-US'; 

            this.recognition.onstart = () => { 
                console.log('🎤 Nova listening...'); 
                this.isListening = true; 
                novaBtn.classList.add('listening'); 
                voiceOverlay.classList.add('active'); 
            }; 

            this.recognition.onresult = (event) => { 
                const command = event.results[0][0].transcript; 
                console.log('🗣️ Voice Command:', command); 
                this.handleVoiceCommand(command); 
            }; 

            this.recognition.onend = () => { 
                this.isListening = false; 
                novaBtn.classList.remove('listening'); 
                voiceOverlay.classList.remove('active'); 
            }; 

            this.recognition.onerror = (event) => { 
                console.error('Voice recognition error:', event.error); 
                this.isListening = false; 
                novaBtn.classList.remove('listening'); 
                voiceOverlay.classList.remove('active'); 
            }; 
        } 
    } 

    setupEventListeners() { 
        // Monitor active window changes to update nav buttons
        // Since WindowManager updates address bar directly, we might need a callback or observer if we want to update back/forward buttons state
        // For now, simple polling or event listener delegation
        
        // Empire status updates 
        setInterval(() => { 
            this.updateEmpireStatus(); 
        }, 5000); 

        // Address bar
        if (addressBar) {
            addressBar.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    this.navigateToSite(addressBar.value);
                }
            });
        }
    } 

    hideLoadingScreen() { 
        if (!loadingScreen) return;
        setTimeout(() => { 
            loadingScreen.style.opacity = '0'; 
            setTimeout(() => { 
                loadingScreen.style.display = 'none'; 
            }, 500); 
        }, 3000); 
    } 

    handleVoiceCommand(command) { 
        const cmd = command.toLowerCase(); 
         
        // Update voice overlay 
        const cmdText = document.getElementById('voice-command-text');
        if (cmdText) cmdText.textContent = `"${command}"`; 
         
        // Send to main process 
        ipcRenderer.invoke('empire-command', command); 
         
        // Handle locally 
        if (cmd.includes('navigate to') || cmd.includes('go to')) { 
            const site = cmd.replace(/navigate to|go to/g, '').trim(); 
            this.navigateToSite(site); 
        } else if (cmd.includes('new tab') || cmd.includes('new window')) { 
            this.windowManager.createWindow('about:blank');
        } else if (cmd.includes('refresh') || cmd.includes('reload')) { 
            this.refresh(); 
        } else if (cmd.includes('back')) { 
            this.goBack(); 
        } else if (cmd.includes('forward')) { 
            this.goForward(); 
        } else if (cmd.includes('close window')) {
            if (this.windowManager.activeWindow) {
                this.windowManager.closeWindow(this.windowManager.activeWindow);
            }
        }
    } 

    navigateToSite(site) { 
        let url = site; 
         
        if (!url.includes('http')) { 
            if (url.includes('.')) { 
                url = `https://${url}`; 
            } else { 
                const shortcuts = { 
                    'github': 'https://github.com', 
                    'gmail': 'https://gmail.com', 
                    'teams': 'https://teams.microsoft.com', 
                    'discord': 'https://discord.com', 
                    'youtube': 'https://youtube.com' 
                }; 
                url = shortcuts[url] || `https://www.google.com/search?q=${encodeURIComponent(url)}`; 
            } 
        } 
         
        const webview = this.windowManager.getActiveWebView();
        if (webview) {
            webview.src = url;
            if (addressBar) addressBar.value = url;
        } else {
            // No active window, create one
            this.windowManager.createWindow(url);
            if (addressBar) addressBar.value = url;
        }
    } 

    goBack() { 
        const webview = this.windowManager.getActiveWebView();
        if (webview && webview.canGoBack()) {
            webview.goBack(); 
        }
    } 

    goForward() { 
        const webview = this.windowManager.getActiveWebView();
        if (webview && webview.canGoForward()) {
            webview.goForward(); 
        }
    } 

    refresh() { 
        const webview = this.windowManager.getActiveWebView();
        if (webview) {
            webview.reload(); 
        }
    } 

    async updateEmpireStatus() { 
        try { 
            const status = await ipcRenderer.invoke('get-empire-status'); 
            // Update agent count and status indicators 
            const agentCountEl = document.getElementById('agent-count');
            if (agentCountEl) agentCountEl.textContent = '47 AGENTS'; 
        } catch (error) { 
            console.error('Failed to update Empire status:', error); 
        } 
    } 
} 

// Global Functions attached to window for HTML event handlers
window.activateNova = function() { 
    if (empireNavigator && empireNavigator.recognition && !empireNavigator.isListening) { 
        empireNavigator.recognition.start(); 
    } 
}; 

window.toggleSocietas = function() { 
    ipcRenderer.invoke('empire-command', 'show societas'); 
}; 

window.goBack = function() { 
    if (empireNavigator) empireNavigator.goBack(); 
}; 

window.goForward = function() { 
    if (empireNavigator) empireNavigator.goForward(); 
}; 

window.refresh = function() { 
    if (empireNavigator) empireNavigator.refresh(); 
}; 

window.minimizeWindow = function() { 
    ipcRenderer.send('window-minimize');
}; 

window.maximizeWindow = function() { 
    ipcRenderer.send('window-maximize');
}; 

window.closeWindow = function() { 
    ipcRenderer.send('window-close');
}; 

window.newWindow = function() {
    if (empireNavigator) empireNavigator.windowManager.createWindow('about:blank');
};

// Initialize Empire Navigator 
let empireNavigator;
document.addEventListener('DOMContentLoaded', () => {
    empireNavigator = new EmpireNavigatorRenderer(); 

    // Empire Easter Eggs 
    document.addEventListener('keydown', (event) => { 
        // Ctrl+Shift+E = Empire Command Palette 
        if (event.ctrlKey && event.shiftKey && event.key === 'E') { 
            window.activateNova(); 
        } 
         
        // Ctrl+Shift+S = Show Societas 
        if (event.ctrlKey && event.shiftKey && event.key === 'S') { 
            window.toggleSocietas(); 
        } 
        
        // Ctrl+N = New Window Pane
        if (event.ctrlKey && event.key === 'n') {
            window.newWindow();
        }
    }); 

    console.log('🏛️ Empire Navigator initialized'); 
    console.log('🎤 Say "Hey Nova" or click the microphone'); 
    console.log('💬 Press Ctrl+Shift+S for Societas'); 
});
