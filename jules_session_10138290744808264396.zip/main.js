const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');

function createWindow() {
  const win = new BrowserWindow({
    width: 1200,
    height: 800,
    frame: false, // Frameless window for custom title bar
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false, // For simplicity based on user provided code, though not recommended for production security
      webviewTag: true
    }
  });

  win.loadFile('index.html');

  // Window control handlers
  ipcMain.on('window-minimize', () => {
    win.minimize();
  });

  ipcMain.on('window-maximize', () => {
    if (win.isMaximized()) {
      win.unmaximize();
    } else {
      win.maximize();
    }
  });

  ipcMain.on('window-close', () => {
    win.close();
  });
  
  // Empire command handler placeholder
  ipcMain.handle('empire-command', async (event, command) => {
    console.log('Received command:', command);
    // Add logic here for commands like 'show societas'
    return { status: 'received', command };
  });

  ipcMain.handle('get-empire-status', async () => {
    return { agents: 47, status: 'online' };
  });
}

app.whenReady().then(() => {
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});
