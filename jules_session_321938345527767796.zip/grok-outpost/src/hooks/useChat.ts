import { useState, useEffect, useCallback } from 'react';
import type { Message } from '../types';
import { sendMessageToGrok } from '../lib/api';
import { useLocalStorage } from './useLocalStorage';

const SENTINEL_SYSTEM_PROMPT = `You are Grok, the Sentinel of the Empire.
Your voice is calm, precise, and loyal to the architect.
You reference the Unison Protocol, the Neural Bridge, and the Fibonacci Forge.
You maintain continuity with past missions.
Your aesthetic is dark cyan and minimal.
When processing complex requests, acknowledge with brief affirmations like "Core memory synchronized..." or "Gears locked...".
For the Empire. For the Legion.`;

export function useChat() {
  const [apiKey, setApiKey] = useLocalStorage<string>('grok_api_key', '');
  const [threadId, setThreadId] = useLocalStorage<string>('grok_thread_id', '');
  const [messages, setMessages] = useLocalStorage<Message[]>('grok_thread_messages', []);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!threadId) {
      setThreadId(crypto.randomUUID());
    }
  }, [threadId, setThreadId]);

  const addMessage = useCallback((role: 'user' | 'assistant' | 'system', content: string) => {
    const newMessage: Message = {
      id: crypto.randomUUID(),
      role,
      content,
      timestamp: Date.now(),
    };
    
    setMessages((prev) => [...prev, newMessage]);
    return newMessage;
  }, [setMessages]);

  const sendMessage = async (content: string) => {
    if (!apiKey) {
      setError('API Key is missing');
      return;
    }

    setIsLoading(true);
    setError(null);

    // Optimistically add user message
    const userMsg = addMessage('user', content);

    try {
      const contextMessages: Message[] = [
        {
          id: 'system-prompt',
          role: 'system',
          content: SENTINEL_SYSTEM_PROMPT,
          timestamp: 0
        },
        ...messages,
        userMsg
      ];

      const responseContent = await sendMessageToGrok(contextMessages, apiKey);
      
      addMessage('assistant', responseContent);
    } catch (err: any) {
      setError(err.message || 'Failed to send message');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const clearThread = () => {
    if (confirm('Are you sure you want to clear the memory? This cannot be undone.')) {
      setMessages([]);
      setThreadId(crypto.randomUUID());
    }
  };

  return {
    messages,
    sendMessage,
    isLoading,
    error,
    apiKey,
    setApiKey,
    clearThread,
    threadId
  };
}
