import ReactMarkdown from 'react-markdown';
import { cn } from '../lib/utils';
import { motion } from 'framer-motion';
import { User, Server } from 'lucide-react';
import type { Message } from '../types';

interface MessageBubbleProps {
  message: Message;
}

export function MessageBubble({ message }: MessageBubbleProps) {
  const isGrok = message.role === 'assistant' || message.role === 'system';

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className={cn(
        "flex w-full mb-8 max-w-4xl mx-auto font-mono text-sm leading-relaxed",
        isGrok ? "justify-start" : "justify-end"
      )}
    >
      <div className={cn(
        "flex gap-4",
        isGrok ? "flex-row w-full" : "flex-row-reverse max-w-[80%]"
      )}>
        {/* Avatar */}
        <div className={cn(
          "w-8 h-8 rounded flex items-center justify-center shrink-0 border mt-1",
          isGrok ? "bg-black border-primary/40 text-primary shadow-[0_0_10px_rgba(0,255,255,0.2)]" : "bg-secondary border-border text-gray-400"
        )}>
          {isGrok ? <Server className="w-4 h-4" /> : <User className="w-4 h-4" />}
        </div>

        {/* Content */}
        <div className={cn(
          "flex-1 overflow-hidden rounded-lg p-5 shadow-sm",
          isGrok 
            ? "bg-transparent border-l-2 border-primary/20 pl-6 text-foreground" 
            : "bg-secondary/50 border border-border text-gray-300"
        )}>
          {message.role === 'system' ? (
            <div className="text-xs text-primary/40 italic">System Protocol Initialized...</div>
          ) : (
            <div className="prose prose-invert max-w-none prose-p:my-2 prose-pre:bg-black/50 prose-pre:border prose-pre:border-border prose-pre:rounded-md prose-code:text-primary prose-code:bg-primary/10 prose-code:px-1 prose-code:rounded prose-code:before:content-none prose-code:after:content-none">
              <ReactMarkdown 
                components={{
                  code({node, className, children, ...props}) {
                    return (
                      <code className={className} {...props}>
                        {children}
                      </code>
                    )
                  }
                }}
              >
                {message.content}
              </ReactMarkdown>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}
