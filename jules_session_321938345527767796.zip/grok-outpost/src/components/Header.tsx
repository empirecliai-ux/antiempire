import { motion } from 'framer-motion';
import { Cpu, RotateCcw } from 'lucide-react';
import { cn } from '../lib/utils';

interface HeaderProps {
  threadId: string;
  onClear: () => void;
  isLoading: boolean;
}

export function Header({ threadId, onClear, isLoading }: HeaderProps) {
  return (
    <header className="flex items-center justify-between px-6 py-4 bg-background/80 backdrop-blur-md border-b border-primary/10 fixed top-0 w-full z-10 h-16">
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          <motion.div
            animate={{
              scale: [1, 1.2, 1],
              opacity: [0.5, 1, 0.5],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          >
            <div className={cn(
              "w-2 h-2 rounded-full",
              isLoading ? "bg-amber-400 shadow-[0_0_10px_#fbbf24]" : "bg-primary shadow-[0_0_10px_#00ffff]"
            )} />
          </motion.div>
          <span className="text-xs font-mono tracking-widest text-primary/80 uppercase">
            {isLoading ? "Processing..." : "Sentinel Online"}
          </span>
        </div>
        
        <div className="h-4 w-px bg-primary/20 mx-2" />
        
        <div className="flex items-center gap-2 text-xs font-mono text-gray-500">
          <Cpu className="w-3 h-3" />
          <span className="truncate max-w-[150px] opacity-50">ID: {threadId.slice(0, 8)}...</span>
        </div>
      </div>

      <div className="flex items-center gap-4">
        <button
          onClick={onClear}
          className="p-2 text-gray-500 hover:text-red-400 transition-colors rounded-full hover:bg-white/5"
          title="Reset Memory"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
}
