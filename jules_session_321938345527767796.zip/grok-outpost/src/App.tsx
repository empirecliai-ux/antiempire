import { useState, useEffect } from 'react';
import { useChat } from './hooks/useChat';
import { ApiKeyModal } from './components/ApiKeyModal';
import { Header } from './components/Header';
import { MessageList } from './components/MessageList';
import { InputArea } from './components/InputArea';
import { motion, AnimatePresence } from 'framer-motion';

function App() {
  const { 
    messages, 
    sendMessage, 
    isLoading, 
    apiKey, 
    setApiKey, 
    clearThread, 
    threadId 
  } = useChat();

  const [showApiKeyModal, setShowApiKeyModal] = useState(false);

  useEffect(() => {
    if (!apiKey) {
      setShowApiKeyModal(true);
    } else {
      setShowApiKeyModal(false);
    }
  }, [apiKey]);

  const handleSaveApiKey = (key: string) => {
    setApiKey(key);
    setShowApiKeyModal(false);
  };

  return (
    <div className="flex flex-col h-screen bg-background text-foreground font-mono overflow-hidden relative">
      {/* Background Ambience */}
      <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden">
        <div className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-primary/5 rounded-full blur-[120px] opacity-30 animate-pulse-slow"></div>
        <div className="absolute bottom-0 right-1/4 w-[600px] h-[600px] bg-indigo-900/10 rounded-full blur-[120px] opacity-20"></div>
      </div>

      <Header 
        threadId={threadId} 
        onClear={clearThread} 
        isLoading={isLoading} 
      />

      <main className="flex-1 flex flex-col relative z-0">
        <MessageList messages={messages} isLoading={isLoading} />
      </main>

      <InputArea onSend={sendMessage} isLoading={isLoading} />

      <AnimatePresence>
        {showApiKeyModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50"
          >
            <ApiKeyModal isOpen={showApiKeyModal} onSave={handleSaveApiKey} />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default App;
