class WindowManager {
    constructor(containerId) {
        this.container = document.getElementById(containerId);
        this.panes = [];
        this.activePane = null;
        this.paneIdCounter = 0;
    }

    createPane(url = 'about:blank') {
        const id = `pane-${this.paneIdCounter++}`;
        const paneEl = document.createElement('div');
        paneEl.className = 'pane';
        paneEl.id = id;
        
        // Initial position and size (staggered)
        const offset = (this.panes.length * 30) % 200;
        paneEl.style.top = `${50 + offset}px`;
        paneEl.style.left = `${50 + offset}px`;
        paneEl.style.width = '800px';
        paneEl.style.height = '600px';

        // Header
        const header = document.createElement('div');
        header.className = 'pane-header';
        
        const title = document.createElement('div');
        title.className = 'pane-title';
        title.textContent = 'New Tab';
        
        const controls = document.createElement('div');
        controls.className = 'pane-controls';
        
        const closeBtn = document.createElement('button');
        closeBtn.className = 'pane-btn close';
        closeBtn.onclick = (e) => {
            e.stopPropagation();
            this.removePane(id);
        };
        
        controls.appendChild(closeBtn);
        header.appendChild(title);
        header.appendChild(controls);

        // Drag Logic
        header.addEventListener('mousedown', (e) => {
            if (e.target.closest('.pane-btn')) return;
            this.startDrag(e, paneEl);
        });
        
        // Content
        const content = document.createElement('div');
        content.className = 'pane-content';
        
        const webview = document.createElement('webview');
        webview.src = url;
        webview.allowpopups = true;
        
        // Webview events
        webview.addEventListener('dom-ready', () => {
             title.textContent = webview.getTitle();
             if (this.activePane && this.activePane.id === id) {
                 this.updateGlobalUI(webview.getURL());
             }
        });
        
        webview.addEventListener('page-title-updated', (e) => {
            title.textContent = e.title;
        });

        webview.addEventListener('did-navigate', (e) => {
            if (this.activePane && this.activePane.id === id) {
                this.updateGlobalUI(e.url);
            }
        });
        
        content.appendChild(webview);
        
        // Resize Handles
        const handles = ['n', 'e', 's', 'w', 'ne', 'nw', 'se', 'sw'];
        handles.forEach(dir => {
            const handle = document.createElement('div');
            handle.className = `resize-handle ${dir}`;
            handle.dataset.dir = dir;
            paneEl.appendChild(handle);

            // Resize Logic
            handle.addEventListener('mousedown', (e) => {
                this.startResize(e, paneEl, dir);
            });
        });

        paneEl.appendChild(header);
        paneEl.appendChild(content);
        
        this.container.appendChild(paneEl);
        
        const paneObj = {
            id,
            element: paneEl,
            webview,
            header
        };
        
        this.panes.push(paneObj);
        
        // Activate on click
        paneEl.addEventListener('mousedown', () => {
            this.setActivePane(paneObj);
        });
        
        this.setActivePane(paneObj);
        
        return paneObj;
    }

    removePane(id) {
        const index = this.panes.findIndex(p => p.id === id);
        if (index > -1) {
            const pane = this.panes[index];
            pane.element.remove();
            this.panes.splice(index, 1);
            
            if (this.activePane && this.activePane.id === id) {
                this.activePane = this.panes.length > 0 ? this.panes[this.panes.length - 1] : null;
                if (this.activePane) this.setActivePane(this.activePane);
            }
        }
    }

    setActivePane(pane) {
        this.activePane = pane;
        this.panes.forEach(p => {
            if (p.id === pane.id) {
                p.element.classList.add('active');
            } else {
                p.element.classList.remove('active');
            }
        });
        
        if (pane && pane.webview.getURL()) {
            this.updateGlobalUI(pane.webview.getURL());
        }
    }

    updateGlobalUI(url) {
        const addressBar = document.getElementById('address-bar');
        if (addressBar) {
            addressBar.value = url;
        }
        
        // Update nav buttons
        if (this.activePane) {
             document.getElementById('back-btn').disabled = !this.activePane.webview.canGoBack();
             document.getElementById('forward-btn').disabled = !this.activePane.webview.canGoForward();
        }
    }

    startDrag(e, paneEl) {
        e.preventDefault(); // Prevent text selection
        
        const startX = e.clientX;
        const startY = e.clientY;
        const startLeft = paneEl.offsetLeft;
        const startTop = paneEl.offsetTop;
        
        const moveHandler = (e) => {
            const dx = e.clientX - startX;
            const dy = e.clientY - startY;
            
            let newLeft = startLeft + dx;
            let newTop = startTop + dy;

            // Snap
            const points = this.getSnapPoints(paneEl);
            
            // Snap Left
            const snappedLeft = this.snap(newLeft, points.x);
            if (snappedLeft !== newLeft) {
                newLeft = snappedLeft;
            } else {
                 // Snap Right
                 const currentWidth = paneEl.offsetWidth;
                 const snappedRight = this.snap(newLeft + currentWidth, points.x);
                 if (snappedRight !== newLeft + currentWidth) {
                     newLeft = snappedRight - currentWidth;
                 }
            }
            
            // Snap Top
            const snappedTop = this.snap(newTop, points.y);
            if (snappedTop !== newTop) {
                newTop = snappedTop;
            } else {
                 // Snap Bottom
                 const currentHeight = paneEl.offsetHeight;
                 const snappedBottom = this.snap(newTop + currentHeight, points.y);
                 if (snappedBottom !== newTop + currentHeight) {
                     newTop = snappedBottom - currentHeight;
                 }
            }
            
            paneEl.style.left = `${newLeft}px`;
            paneEl.style.top = `${newTop}px`;
        };

        const upHandler = () => {
            document.removeEventListener('mousemove', moveHandler);
            document.removeEventListener('mouseup', upHandler);
        };

        document.addEventListener('mousemove', moveHandler);
        document.addEventListener('mouseup', upHandler);
    }

    startResize(e, paneEl, dir) {
        e.preventDefault();
        e.stopPropagation();
        
        const startX = e.clientX;
        const startY = e.clientY;
        const startWidth = paneEl.offsetWidth;
        const startHeight = paneEl.offsetHeight;
        const startLeft = paneEl.offsetLeft;
        const startTop = paneEl.offsetTop;
        
        const moveHandler = (e) => {
            const dx = e.clientX - startX;
            const dy = e.clientY - startY;
            
            let newWidth = startWidth;
            let newHeight = startHeight;
            let newLeft = startLeft;
            let newTop = startTop;
            
            if (dir.includes('e')) newWidth = startWidth + dx;
            if (dir.includes('w')) {
                newWidth = startWidth - dx;
                newLeft = startLeft + dx;
            }
            if (dir.includes('s')) newHeight = startHeight + dy;
            if (dir.includes('n')) {
                newHeight = startHeight - dy;
                newTop = startTop + dy;
            }
            
            // Min size
            if (newWidth < 200) {
                if (dir.includes('w')) newLeft = startLeft + (startWidth - 200);
                newWidth = 200;
            }
            if (newHeight < 150) {
                 if (dir.includes('n')) newTop = startTop + (startHeight - 150);
                newHeight = 150;
            }
            
            paneEl.style.width = `${newWidth}px`;
            paneEl.style.height = `${newHeight}px`;
            paneEl.style.left = `${newLeft}px`;
            paneEl.style.top = `${newTop}px`;
        };

        const upHandler = () => {
            document.removeEventListener('mousemove', moveHandler);
            document.removeEventListener('mouseup', upHandler);
        };

        document.addEventListener('mousemove', moveHandler);
        document.addEventListener('mouseup', upHandler);
    }

    snap(val, snapPoints, threshold = 20) {
        for (const point of snapPoints) {
            if (Math.abs(val - point) < threshold) {
                return point;
            }
        }
        return val;
    }

    getSnapPoints(currentPaneEl) {
        const points = {
            x: [0, this.container.clientWidth],
            y: [0, this.container.clientHeight]
        };
        
        this.panes.forEach(p => {
            if (p.element === currentPaneEl) return;
            
            points.x.push(p.element.offsetLeft);
            points.x.push(p.element.offsetLeft + p.element.offsetWidth);
            points.y.push(p.element.offsetTop);
            points.y.push(p.element.offsetTop + p.element.offsetHeight);
        });
        
        return points;
    }
}
