const { ipcRenderer } = require('electron');

// Since remote is deprecated in newer electron versions but the user code used it:
// require('electron').remote.getCurrentWindow()
// I will stick to what works or use ipcMain for window controls. 
// For now let's assume the user environment has remote or I'll use a workaround if it fails.
// Actually, it's safer to use ipcRenderer to ask main process to minimize/maximize/close if remote is an issue.
// But the user code used remote. I'll stick to it but wrap it in try-catch or use the user's method.

const addressBar = document.getElementById('address-bar');
const loadingScreen = document.getElementById('loading-screen');
const novaBtn = document.getElementById('nova-btn');
const voiceOverlay = document.getElementById('voice-overlay');

// Empire Navigator Core
class EmpireNavigatorRenderer {
    constructor() {
        this.isListening = false;
        this.recognition = null;
        this.windowManager = new WindowManager('browser-content');
        
        this.initializeVoiceRecognition();
        this.setupEventListeners();
        this.hideLoadingScreen();
        
        // Create initial pane
        this.windowManager.createPane('https://google.com');
    }

    initializeVoiceRecognition() {
        if ('webkitSpeechRecognition' in window) {
            this.recognition = new webkitSpeechRecognition();
            this.recognition.continuous = false;
            this.recognition.interimResults = false;
            this.recognition.lang = 'en-US';

            this.recognition.onstart = () => {
                console.log('🎤 Nova listening...');
                this.isListening = true;
                novaBtn.classList.add('listening');
                voiceOverlay.classList.add('active');
            };

            this.recognition.onresult = (event) => {
                const command = event.results[0][0].transcript;
                console.log('🗣️ Voice Command:', command);
                this.handleVoiceCommand(command);
            };

            this.recognition.onend = () => {
                this.isListening = false;
                novaBtn.classList.remove('listening');
                voiceOverlay.classList.remove('active');
            };

            this.recognition.onerror = (event) => {
                console.error('Voice recognition error:', event.error);
                this.isListening = false;
                novaBtn.classList.remove('listening');
                voiceOverlay.classList.remove('active');
            };
        }
    }

    setupEventListeners() {
        // Global Navigation Controls
        document.getElementById('back-btn').addEventListener('click', () => {
            if (this.windowManager.activePane) this.windowManager.activePane.webview.goBack();
        });

        document.getElementById('forward-btn').addEventListener('click', () => {
            if (this.windowManager.activePane) this.windowManager.activePane.webview.goForward();
        });

        document.getElementById('refresh-btn').addEventListener('click', () => {
            if (this.windowManager.activePane) this.windowManager.activePane.webview.reload();
        });
        
        document.getElementById('new-pane-btn').addEventListener('click', () => {
            this.windowManager.createPane('about:blank');
        });

        addressBar.addEventListener('keypress', (event) => {
            if (event.key === 'Enter') {
                const url = addressBar.value;
                this.navigateToSite(url);
            }
        });

        // Empire status updates
        setInterval(() => {
            this.updateEmpireStatus();
        }, 5000);
    }

    hideLoadingScreen() {
        setTimeout(() => {
            loadingScreen.style.opacity = '0';
            setTimeout(() => {
                loadingScreen.style.display = 'none';
            }, 500);
        }, 3000);
    }

    handleVoiceCommand(command) {
        const cmd = command.toLowerCase();
        
        // Update voice overlay
        document.getElementById('voice-command-text').textContent = `"${command}"`;
        
        // Send to main process
        ipcRenderer.invoke('empire-command', command);
        
        // Handle locally
        if (cmd.includes('navigate to') || cmd.includes('go to')) {
            const site = cmd.replace(/navigate to|go to/g, '').trim();
            this.navigateToSite(site);
        } else if (cmd.includes('new tab') || cmd.includes('new window')) {
            this.windowManager.createPane('about:blank');
        } else if (cmd.includes('refresh') || cmd.includes('reload')) {
            if (this.windowManager.activePane) this.windowManager.activePane.webview.reload();
        } else if (cmd.includes('back')) {
            if (this.windowManager.activePane) this.windowManager.activePane.webview.goBack();
        } else if (cmd.includes('forward')) {
            if (this.windowManager.activePane) this.windowManager.activePane.webview.goForward();
        }
    }

    navigateToSite(site) {
        let url = site;
        
        if (!url.includes('http')) {
            if (url.includes('.')) {
                url = `https://${url}`;
            } else {
                const shortcuts = {
                    'github': 'https://github.com',
                    'gmail': 'https://gmail.com',
                    'teams': 'https://teams.microsoft.com',
                    'discord': 'https://discord.com',
                    'youtube': 'https://youtube.com'
                };
                url = shortcuts[url] || `https://www.google.com/search?q=${encodeURIComponent(url)}`;
            }
        }
        
        if (this.windowManager.activePane) {
            this.windowManager.activePane.webview.src = url;
            // Address bar update is handled by the pane's event listener (to be implemented)
            addressBar.value = url; 
        } else {
            this.windowManager.createPane(url);
        }
    }

    async updateEmpireStatus() {
        try {
            const status = await ipcRenderer.invoke('get-empire-status');
            // Update agent count and status indicators
            document.getElementById('agent-count').textContent = '47 AGENTS';
        } catch (error) {
            console.error('Failed to update Empire status:', error);
        }
    }
}

// Global Functions
function activateNova() {
    if (empireNavigator.recognition && !empireNavigator.isListening) {
        empireNavigator.recognition.start();
    }
}

function toggleSocietas() {
    ipcRenderer.invoke('empire-command', 'show societas');
}

function minimizeWindow() {
    ipcRenderer.invoke('window-minimize');
}

function maximizeWindow() {
    ipcRenderer.invoke('window-maximize');
}

function closeWindow() {
    ipcRenderer.invoke('window-close');
}

// Initialize Empire Navigator
const empireNavigator = new EmpireNavigatorRenderer();

// Empire Easter Eggs
document.addEventListener('keydown', (event) => {
    // Ctrl+Shift+E = Empire Command Palette
    if (event.ctrlKey && event.shiftKey && event.key === 'E') {
        activateNova();
    }
    
    // Ctrl+Shift+S = Show Societas
    if (event.ctrlKey && event.shiftKey && event.key === 'S') {
        toggleSocietas();
    }
});

console.log('🏛️ Empire Navigator initialized');
