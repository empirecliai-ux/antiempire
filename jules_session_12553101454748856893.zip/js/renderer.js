const { ipcRenderer } = require('electron');
const WindowManager = require('./WindowManager.js'); // Assuming same directory

class EmpireNavigatorRenderer {
    constructor() {
        this.isListening = false;
        this.recognition = null;
        this.windowManager = null;

        // Wait for DOM to be ready
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.init());
        } else {
            this.init();
        }
    }

    init() {
        const container = document.getElementById('browser-content');
        this.windowManager = new WindowManager(container);

        this.addressBar = document.getElementById('address-bar');
        this.loadingScreen = document.getElementById('loading-screen');
        this.novaBtn = document.getElementById('nova-btn');
        this.voiceOverlay = document.getElementById('voice-overlay');
        this.voiceText = document.getElementById('voice-command-text');
        this.backBtn = document.getElementById('back-btn');
        this.forwardBtn = document.getElementById('forward-btn');
        this.agentCount = document.getElementById('agent-count');

        this.initializeVoiceRecognition();
        this.setupEventListeners();
        this.hideLoadingScreen();

        // Create initial window
        this.windowManager.createWindow('https://google.com');
    }

    initializeVoiceRecognition() {
        if ('webkitSpeechRecognition' in window) {
            // eslint-disable-next-line no-undef
            this.recognition = new webkitSpeechRecognition();
            this.recognition.continuous = false;
            this.recognition.interimResults = false;
            this.recognition.lang = 'en-US';

            this.recognition.onstart = () => {
                console.log('🎤 Nova listening...');
                this.isListening = true;
                this.novaBtn.classList.add('listening');
                this.voiceOverlay.classList.add('active');
            };

            this.recognition.onresult = (event) => {
                const command = event.results[0][0].transcript;
                console.log('🗣️ Voice Command:', command);
                this.handleVoiceCommand(command);
            };

            this.recognition.onend = () => {
                this.isListening = false;
                this.novaBtn.classList.remove('listening');
                this.voiceOverlay.classList.remove('active');
            };

            this.recognition.onerror = (event) => {
                console.error('Voice recognition error:', event.error);
                this.isListening = false;
                this.novaBtn.classList.remove('listening');
                this.voiceOverlay.classList.remove('active');
            };
        }
    }

    setupEventListeners() {
        // Global events for active window changes
        document.addEventListener('url-changed', (e) => {
            if (this.addressBar) this.addressBar.value = e.detail;
            this.updateNavigationButtons();
        });

        document.addEventListener('active-window-changed', (e) => {
             if (e.detail && e.detail.url && this.addressBar) {
                 this.addressBar.value = e.detail.url;
             }
             this.updateNavigationButtons();
        });

        // Empire status updates
        setInterval(() => {
            this.updateEmpireStatus();
        }, 5000);

        // Address bar
        if (this.addressBar) {
            this.addressBar.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    this.navigateToSite(this.addressBar.value);
                }
            });
        }

        // Nav buttons
        if (this.backBtn) {
            this.backBtn.addEventListener('click', () => {
                const win = this.windowManager.activeWindow;
                if (win && win.webview.canGoBack()) win.webview.goBack();
            });
        }

        if (this.forwardBtn) {
            this.forwardBtn.addEventListener('click', () => {
                const win = this.windowManager.activeWindow;
                if (win && win.webview.canGoForward()) win.webview.goForward();
            });
        }
    }

    hideLoadingScreen() {
        if (!this.loadingScreen) return;
        setTimeout(() => {
            this.loadingScreen.style.opacity = '0';
            setTimeout(() => {
                this.loadingScreen.style.display = 'none';
            }, 500);
        }, 3000);
    }

    handleVoiceCommand(command) {
        const cmd = command.toLowerCase();

        // Update voice overlay
        if (this.voiceText) this.voiceText.textContent = `"${command}"`;

        // Send to main process
        ipcRenderer.invoke('empire-command', command);

        // Handle locally
        if (cmd.includes('navigate to') || cmd.includes('go to')) {
            const site = cmd.replace(/navigate to|go to/g, '').trim();
            this.navigateToSite(site);
        } else if (cmd.includes('new tab') || cmd.includes('new window')) {
            this.windowManager.createWindow('about:blank');
        } else if (cmd.includes('refresh') || cmd.includes('reload')) {
            const win = this.windowManager.activeWindow;
            if (win) win.webview.reload();
        } else if (cmd.includes('back')) {
             const win = this.windowManager.activeWindow;
             if (win && win.webview.canGoBack()) win.webview.goBack();
        } else if (cmd.includes('forward')) {
             const win = this.windowManager.activeWindow;
             if (win && win.webview.canGoForward()) win.webview.goForward();
        } else if (cmd.includes('close window')) {
             const win = this.windowManager.activeWindow;
             if (win) this.windowManager.closeWindow(win);
        }
    }

    navigateToSite(site) {
        let url = site;

        if (!url.includes('http')) {
            if (url.includes('.') && !url.includes(' ')) {
                url = `https://${url}`;
            } else {
                const shortcuts = {
                    'github': 'https://github.com',
                    'gmail': 'https://gmail.com',
                    'teams': 'https://teams.microsoft.com',
                    'discord': 'https://discord.com',
                    'youtube': 'https://youtube.com'
                };
                url = shortcuts[url] || `https://www.google.com/search?q=${encodeURIComponent(url)}`;
            }
        }

        const win = this.windowManager.activeWindow;
        if (win) {
            // If current window is internal (about:blank or similar empty state), replace.
            // Otherwise, user might want a new tab?
            // For now, replace current window content as per browser standard behavior
            win.webview.src = url;
            if (this.addressBar) this.addressBar.value = url;
        } else {
            this.windowManager.createWindow(url);
        }
    }

    updateNavigationButtons() {
        const win = this.windowManager.activeWindow;
        if (win && win.webview) {
            // Webview methods like canGoBack are often not available immediately
            // But let's try safely
            try {
                if (this.backBtn) this.backBtn.disabled = !win.webview.canGoBack();
                if (this.forwardBtn) this.forwardBtn.disabled = !win.webview.canGoForward();
            } catch (e) {
                // Ignore
            }
        } else {
            if (this.backBtn) this.backBtn.disabled = true;
            if (this.forwardBtn) this.forwardBtn.disabled = true;
        }
    }

    async updateEmpireStatus() {
        try {
            const status = await ipcRenderer.invoke('get-empire-status');
            if (this.agentCount) this.agentCount.textContent = `${status.agents || 47} AGENTS`;
        } catch (error) {
            console.error('Failed to update Empire status:', error);
        }
    }
}

// Instantiate
const empireNavigator = new EmpireNavigatorRenderer();

// Global Window Controls (for main window)
window.minimizeWindow = () => ipcRenderer.invoke('window-minimize');
window.maximizeWindow = () => ipcRenderer.invoke('window-maximize');
window.closeWindow = () => ipcRenderer.invoke('window-close');

// Global Actions
window.activateNova = () => {
    if (empireNavigator.recognition && !empireNavigator.isListening) {
        empireNavigator.recognition.start();
    }
};

window.toggleSocietas = () => {
    ipcRenderer.invoke('empire-command', 'show societas');
};

window.refresh = () => {
    const win = empireNavigator.windowManager.activeWindow;
    if (win) win.webview.reload();
};

window.goBack = () => {
     const win = empireNavigator.windowManager.activeWindow;
     if (win && win.webview.canGoBack()) win.webview.goBack();
};

window.goForward = () => {
     const win = empireNavigator.windowManager.activeWindow;
     if (win && win.webview.canGoForward()) win.webview.goForward();
};

window.handleAddressBar = (event) => {
     if (event.key === 'Enter') {
         empireNavigator.navigateToSite(event.target.value);
     }
};

// Keybindings
document.addEventListener('keydown', (event) => {
    // Ctrl+Shift+E = Empire Command Palette
    if (event.ctrlKey && event.shiftKey && event.key === 'E') {
        window.activateNova();
    }

    // Ctrl+Shift+S = Show Societas
    if (event.ctrlKey && event.shiftKey && event.key === 'S') {
        window.toggleSocietas();
    }

    // Ctrl+N = New Window
    if (event.ctrlKey && event.key === 'n') {
        empireNavigator.windowManager.createWindow('about:blank');
    }
});

console.log('🏛️ Empire Navigator initialized');
