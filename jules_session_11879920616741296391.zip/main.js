const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');

let win;

function createWindow() {
    win = new BrowserWindow({
        width: 1200,
        height: 800,
        frame: false, // Frameless window as per user's design
        webPreferences: {
            nodeIntegration: true,
            contextIsolation: false,
            webviewTag: true
        }
    });

    win.loadFile('index.html');

    // IPC handlers for window controls
    ipcMain.handle('window-minimize', () => {
        win.minimize();
    });

    ipcMain.handle('window-maximize', () => {
        if (win.isMaximized()) {
            win.unmaximize();
        } else {
            win.maximize();
        }
    });

    ipcMain.handle('window-close', () => {
        win.close();
    });

    // Empire handlers
    ipcMain.handle('empire-command', (event, command) => {
        console.log('Received empire command:', command);
        return { status: 'executed', command };
    });

    ipcMain.handle('get-empire-status', () => {
        return { agents: 47, status: 'online' };
    });
}

app.whenReady().then(() => {
    createWindow();

    app.on('activate', () => {
        if (BrowserWindow.getAllWindows().length === 0) {
            createWindow();
        }
    });
});

app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
        app.quit();
    }
});
