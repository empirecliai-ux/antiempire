const { ipcRenderer } = require('electron');

// UI Elements
const addressBar = document.getElementById('address-bar');
const loadingScreen = document.getElementById('loading-screen');
const novaBtn = document.getElementById('nova-btn');
const voiceOverlay = document.getElementById('voice-overlay');
const agentCount = document.getElementById('agent-count');

// Window Manager
let windowManager;

class EmpireNavigatorRenderer {
    constructor() {
        this.isListening = false;
        this.recognition = null;
        
        // Initialize Window Manager
        windowManager = new window.WindowManager('window-container');
        
        // Create initial window
        windowManager.createWindow('https://www.google.com'); // Start with a real page

        this.initializeVoiceRecognition();
        this.setupEventListeners();
        this.hideLoadingScreen();
        
        // Expose callback for WindowManager
        window.onUrlChange = (url) => {
            addressBar.value = url;
            this.updateNavigationButtons();
        };
    }

    initializeVoiceRecognition() {
        if ('webkitSpeechRecognition' in window) {
            this.recognition = new webkitSpeechRecognition();
            this.recognition.continuous = false;
            this.recognition.interimResults = false;
            this.recognition.lang = 'en-US';

            this.recognition.onstart = () => {
                console.log('🎤 Nova listening...');
                this.isListening = true;
                novaBtn.classList.add('listening');
                voiceOverlay.classList.add('active');
            };

            this.recognition.onresult = (event) => {
                const command = event.results[0][0].transcript;
                console.log('🗣️ Voice Command:', command);
                this.handleVoiceCommand(command);
            };

            this.recognition.onend = () => {
                this.isListening = false;
                novaBtn.classList.remove('listening');
                voiceOverlay.classList.remove('active');
            };

            this.recognition.onerror = (event) => {
                console.error('Voice recognition error:', event.error);
                this.isListening = false;
                novaBtn.classList.remove('listening');
                voiceOverlay.classList.remove('active');
            };
        }
    }

    setupEventListeners() {
        // Navigation Controls
        document.getElementById('back-btn').addEventListener('click', () => {
            const win = windowManager.getActiveWindow();
            if (win && win.webview.canGoBack()) win.webview.goBack();
        });

        document.getElementById('forward-btn').addEventListener('click', () => {
            const win = windowManager.getActiveWindow();
            if (win && win.webview.canGoForward()) win.webview.goForward();
        });

        document.getElementById('refresh-btn').addEventListener('click', () => {
            const win = windowManager.getActiveWindow();
            if (win) win.webview.reload();
        });
        
        document.getElementById('new-window-btn').addEventListener('click', () => {
            windowManager.createWindow('about:blank');
        });

        // Address Bar
        addressBar.addEventListener('keydown', (event) => {
            if (event.key === 'Enter') {
                const url = this.formatUrl(addressBar.value);
                const win = windowManager.getActiveWindow();
                if (win) {
                    win.webview.src = url;
                } else {
                    windowManager.createWindow(url);
                }
            }
        });

        // Window Controls (Main Window)
        document.getElementById('win-minimize').addEventListener('click', () => {
            ipcRenderer.invoke('window-minimize');
        });

        document.getElementById('win-maximize').addEventListener('click', () => {
            ipcRenderer.invoke('window-maximize');
        });

        document.getElementById('win-close').addEventListener('click', () => {
            ipcRenderer.invoke('window-close');
        });
        
        // Societas Toggle
        document.getElementById('societas-toggle').addEventListener('click', () => {
            this.toggleSocietas();
        });
        
        // Nova Button
        novaBtn.addEventListener('click', () => {
            this.activateNova();
        });

        // Empire status updates
        setInterval(() => {
            this.updateEmpireStatus();
        }, 5000);
    }

    hideLoadingScreen() {
        setTimeout(() => {
            loadingScreen.style.opacity = '0';
            setTimeout(() => {
                loadingScreen.style.display = 'none';
            }, 500);
        }, 3000); // Keep user's 3s delay
    }

    handleVoiceCommand(command) {
        const cmd = command.toLowerCase();
        
        // Update voice overlay
        document.getElementById('voice-command-text').textContent = `"${command}"`;
        
        // Send to main process
        ipcRenderer.invoke('empire-command', command);
        
        // Handle locally
        if (cmd.includes('navigate to') || cmd.includes('go to')) {
            const site = cmd.replace(/navigate to|go to/g, '').trim();
            this.navigateToSite(site);
        } else if (cmd.includes('new tab') || cmd.includes('new window')) {
            windowManager.createWindow('about:blank');
        } else if (cmd.includes('refresh') || cmd.includes('reload')) {
            const win = windowManager.getActiveWindow();
            if (win) win.webview.reload();
        } else if (cmd.includes('back')) {
            const win = windowManager.getActiveWindow();
            if (win && win.webview.canGoBack()) win.webview.goBack();
        } else if (cmd.includes('close window')) {
            const win = windowManager.getActiveWindow();
            if (win) windowManager.closeWindow(win.id);
        }
    }

    navigateToSite(site) {
        const url = this.formatUrl(site);
        const win = windowManager.getActiveWindow();
        if (win) {
            win.webview.src = url;
        } else {
            windowManager.createWindow(url);
        }
    }

    formatUrl(input) {
        let url = input;
        if (!url.includes('http')) {
            if (url.includes('.') && !url.includes(' ')) {
                url = `https://${url}`;
            } else {
                const shortcuts = {
                    'github': 'https://github.com',
                    'gmail': 'https://gmail.com',
                    'teams': 'https://teams.microsoft.com',
                    'discord': 'https://discord.com',
                    'youtube': 'https://youtube.com'
                };
                url = shortcuts[url.toLowerCase()] || `https://www.google.com/search?q=${encodeURIComponent(url)}`;
            }
        }
        return url;
    }

    updateNavigationButtons() {
        // UI updates
    }

    async updateEmpireStatus() {
        try {
            const status = await ipcRenderer.invoke('get-empire-status');
            if (agentCount) agentCount.textContent = `${status.agents} AGENTS`;
        } catch (error) {
            console.error('Failed to update Empire status:', error);
        }
    }
    
    activateNova() {
        if (this.recognition && !this.isListening) {
            this.recognition.start();
        }
    }
    
    toggleSocietas() {
        ipcRenderer.invoke('empire-command', 'show societas');
    }
}

// Initialize
const empireNavigator = new EmpireNavigatorRenderer();

// Empire Easter Eggs
document.addEventListener('keydown', (event) => {
    // Ctrl+Shift+E = Empire Command Palette
    if (event.ctrlKey && event.shiftKey && event.key === 'E') {
        empireNavigator.activateNova();
    }
    
    // Ctrl+Shift+S = Show Societas
    if (event.ctrlKey && event.shiftKey && event.key === 'S') {
        empireNavigator.toggleSocietas();
    }
});

console.log('🏛️ Empire Navigator initialized');
