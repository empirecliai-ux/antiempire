class WindowManager {
    constructor(containerId) {
        this.container = document.getElementById(containerId);
        this.windows = [];
        this.activeWindow = null;
        this.zIndexCounter = 10;
        this.snapThreshold = 15; // Pixels to snap

        this.setupGlobalEvents();
    }

    setupGlobalEvents() {
        // Handle window resize if needed
    }

    createWindow(url = 'about:blank') {
        const id = 'win-' + Date.now() + Math.random().toString(36).substr(2, 9);
        
        // Create DOM elements
        const frame = document.createElement('div');
        frame.className = 'window-frame active';
        frame.id = id;
        
        // Initial Position & Size (Cascading)
        const offset = (this.windows.length % 8) * 30 + 20;
        frame.style.left = offset + 'px';
        frame.style.top = offset + 'px';
        frame.style.width = '800px';
        frame.style.height = '600px';
        frame.style.zIndex = ++this.zIndexCounter;

        // Header
        const header = document.createElement('div');
        header.className = 'window-header';
        
        const title = document.createElement('div');
        title.className = 'window-title';
        title.textContent = 'Loading...';
        
        const controls = document.createElement('div');
        controls.className = 'window-controls-pane';
        
        const maxBtn = document.createElement('button');
        maxBtn.className = 'pane-btn maximize';
        maxBtn.title = 'Maximize';
        maxBtn.onclick = (e) => {
            e.stopPropagation();
            this.toggleMaximize(frame);
        };
        
        const closeBtn = document.createElement('button');
        closeBtn.className = 'pane-btn close';
        closeBtn.title = 'Close';
        closeBtn.onclick = (e) => {
            e.stopPropagation();
            this.closeWindow(id);
        };
        
        controls.appendChild(maxBtn);
        controls.appendChild(closeBtn);
        
        header.appendChild(title);
        header.appendChild(controls);
        
        // Content
        const content = document.createElement('div');
        content.className = 'window-content';
        
        const webview = document.createElement('webview');
        webview.src = url;
        webview.setAttribute('allowpopups', '');
        
        // Webview Events
        webview.addEventListener('page-title-updated', (e) => {
            title.textContent = e.title;
        });
        
        webview.addEventListener('did-navigate', (e) => {
             if (this.activeWindow && this.activeWindow.id === id) {
                 if (window.onUrlChange) window.onUrlChange(e.url);
             }
        });

        webview.addEventListener('dom-ready', () => {
             if (this.activeWindow && this.activeWindow.id === id) {
                 if (window.onUrlChange) window.onUrlChange(webview.getURL());
             }
        });
        
        // Bring to front on click
        frame.addEventListener('mousedown', () => this.setActiveWindow(id));
        
        content.appendChild(webview);
        
        // Resize handles
        const resizeE = document.createElement('div'); resizeE.className = 'resize-handle e';
        const resizeS = document.createElement('div'); resizeS.className = 'resize-handle s';
        const resizeSE = document.createElement('div'); resizeSE.className = 'resize-handle se';
        
        frame.appendChild(header);
        frame.appendChild(content);
        frame.appendChild(resizeE);
        frame.appendChild(resizeS);
        frame.appendChild(resizeSE);
        
        this.container.appendChild(frame);
        
        const winObj = {
            id,
            frame,
            webview,
            header,
            isMaximized: false,
            originalRect: null
        };
        this.windows.push(winObj);
        
        this.setupDraggable(winObj);
        this.setupResizable(winObj, resizeE, 'e');
        this.setupResizable(winObj, resizeS, 's');
        this.setupResizable(winObj, resizeSE, 'se');
        
        this.setActiveWindow(id);
        return winObj;
    }

    closeWindow(id) {
        const index = this.windows.findIndex(w => w.id === id);
        if (index !== -1) {
            const win = this.windows[index];
            win.frame.remove();
            this.windows.splice(index, 1);
            
            // Set new active window
            if (this.activeWindow && this.activeWindow.id === id) {
                this.activeWindow = this.windows.length > 0 ? this.windows[this.windows.length - 1] : null;
                if (this.activeWindow) this.setActiveWindow(this.activeWindow.id);
            }
        }
    }

    setActiveWindow(id) {
        this.windows.forEach(w => w.frame.classList.remove('active'));
        const win = this.windows.find(w => w.id === id);
        if (win) {
            win.frame.classList.add('active');
            win.frame.style.zIndex = ++this.zIndexCounter;
            this.activeWindow = win;
            
            if (window.onUrlChange) window.onUrlChange(win.webview.getURL());
        }
    }
    
    getActiveWindow() {
        return this.activeWindow;
    }

    toggleMaximize(frame) {
        const win = this.windows.find(w => w.frame === frame);
        if (!win) return;
        
        if (win.isMaximized) {
            // Restore
            frame.style.left = win.originalRect.left;
            frame.style.top = win.originalRect.top;
            frame.style.width = win.originalRect.width;
            frame.style.height = win.originalRect.height;
            win.isMaximized = false;
        } else {
            // Maximize
            win.originalRect = {
                left: frame.style.left,
                top: frame.style.top,
                width: frame.style.width,
                height: frame.style.height
            };
            frame.style.left = '0';
            frame.style.top = '0';
            frame.style.width = '100%';
            frame.style.height = '100%';
            win.isMaximized = true;
        }
    }

    setupDraggable(win) {
        let isDragging = false;
        let startX, startY, startLeft, startTop;

        const onMouseMove = (e) => {
            if (!isDragging) return;
            
            let newLeft = startLeft + (e.clientX - startX);
            let newTop = startTop + (e.clientY - startY);
            
            // Boundary constraints
            const containerRect = this.container.getBoundingClientRect();
            const frameRect = win.frame.getBoundingClientRect();
            
            // Snap to container edges
            if (Math.abs(newLeft) < this.snapThreshold) newLeft = 0;
            if (Math.abs(newTop) < this.snapThreshold) newTop = 0;
            if (Math.abs(newLeft + frameRect.width - containerRect.width) < this.snapThreshold) 
                newLeft = containerRect.width - frameRect.width;
            if (Math.abs(newTop + frameRect.height - containerRect.height) < this.snapThreshold)
                newTop = containerRect.height - frameRect.height;
                
            // Snap to other windows (basic)
            this.windows.forEach(other => {
                if (other === win) return;
                const otherRect = other.frame.getBoundingClientRect();
                const containerLeft = containerRect.left;
                const containerTop = containerRect.top;

                // Helper to get relative rect
                const rRect = {
                    left: otherRect.left - containerLeft,
                    right: otherRect.right - containerLeft,
                    top: otherRect.top - containerTop,
                    bottom: otherRect.bottom - containerTop
                };
                
                // Snap Right side to Other Left
                if (Math.abs((newLeft + frameRect.width) - rRect.left) < this.snapThreshold) {
                    newLeft = rRect.left - frameRect.width;
                }
                
                // Snap Left side to Other Right
                if (Math.abs(newLeft - rRect.right) < this.snapThreshold) {
                    newLeft = rRect.right;
                }
                
                 // Snap Bottom to Other Top
                if (Math.abs((newTop + frameRect.height) - rRect.top) < this.snapThreshold) {
                    newTop = rRect.top - frameRect.height;
                }
                
                // Snap Top to Other Bottom
                if (Math.abs(newTop - rRect.bottom) < this.snapThreshold) {
                    newTop = rRect.bottom;
                }
            });

            win.frame.style.left = newLeft + 'px';
            win.frame.style.top = newTop + 'px';
        };

        const onMouseUp = () => {
            if (isDragging) {
                isDragging = false;
                const overlay = win.frame.querySelector('.drag-overlay');
                if (overlay) overlay.remove();
                
                window.removeEventListener('mousemove', onMouseMove);
                window.removeEventListener('mouseup', onMouseUp);
            }
        };

        const onMouseDown = (e) => {
            if (e.target.closest('.pane-btn')) return; // Don't drag if clicking buttons
            if (win.isMaximized) return;

            isDragging = true;
            startX = e.clientX;
            startY = e.clientY;
            startLeft = parseInt(win.frame.style.left || 0);
            startTop = parseInt(win.frame.style.top || 0);
            
            this.setActiveWindow(win.id);
            
            // Create a transparent overlay on webview to prevent event eating during drag
            const overlay = document.createElement('div');
            overlay.style.position = 'absolute';
            overlay.style.top = 0; overlay.style.left = 0; overlay.style.width = '100%'; overlay.style.height = '100%';
            overlay.style.zIndex = 999;
            overlay.className = 'drag-overlay';
            win.frame.appendChild(overlay);

            window.addEventListener('mousemove', onMouseMove);
            window.addEventListener('mouseup', onMouseUp);
        };

        win.header.addEventListener('mousedown', onMouseDown);
    }

    setupResizable(win, handle, type) {
        let isResizing = false;
        let startX, startY, startWidth, startHeight;

        const onMouseMove = (e) => {
            if (!isResizing) return;
            
            if (type.includes('e')) {
                const width = startWidth + (e.clientX - startX);
                if (width > 200) win.frame.style.width = width + 'px';
            }
            if (type.includes('s')) {
                const height = startHeight + (e.clientY - startY);
                if (height > 150) win.frame.style.height = height + 'px';
            }
        };

        const onMouseUp = () => {
            if (isResizing) {
                isResizing = false;
                const overlay = win.frame.querySelector('.resize-overlay');
                if (overlay) overlay.remove();

                window.removeEventListener('mousemove', onMouseMove);
                window.removeEventListener('mouseup', onMouseUp);
            }
        };

        const onMouseDown = (e) => {
            e.stopPropagation();
            isResizing = true;
            startX = e.clientX;
            startY = e.clientY;
            startWidth = win.frame.offsetWidth;
            startHeight = win.frame.offsetHeight;
            
            this.setActiveWindow(win.id);
            
             // Create overlay
            const overlay = document.createElement('div');
            overlay.style.position = 'absolute';
            overlay.style.top = 0; overlay.style.left = 0; overlay.style.width = '100%'; overlay.style.height = '100%';
            overlay.style.zIndex = 999;
            overlay.className = 'resize-overlay';
            win.frame.appendChild(overlay);

            window.addEventListener('mousemove', onMouseMove);
            window.addEventListener('mouseup', onMouseUp);
        };

        handle.addEventListener('mousedown', onMouseDown);
    }
}

// Export
window.WindowManager = WindowManager;
