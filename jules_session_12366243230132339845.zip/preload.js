const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('empireApi', {
  minimizeWindow: () => ipcRenderer.send('minimize-window'),
  maximizeWindow: () => ipcRenderer.send('maximize-window'),
  closeWindow: () => ipcRenderer.send('close-window'),
  sendEmpireCommand: (command) => ipcRenderer.invoke('empire-command', command),
  getEmpireStatus: () => ipcRenderer.invoke('get-empire-status')
});
