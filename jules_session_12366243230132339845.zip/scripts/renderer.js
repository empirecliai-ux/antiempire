// IPC removed

const addressBar = document.getElementById('address-bar');
const loadingScreen = document.getElementById('loading-screen');
const novaBtn = document.getElementById('nova-btn');
const voiceOverlay = document.getElementById('voice-overlay');
const browserContent = document.getElementById('browser-content');

// Empire Navigator Core
class EmpireNavigatorRenderer {
    constructor() {
        this.isListening = false;
        this.recognition = null;
        this.currentUrl = 'about:blank';
        this.windowManager = null;

        this.initializeVoiceRecognition();

        // Wait for DOM to be ready before initializing window manager
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.initWindowManager());
        } else {
            this.initWindowManager();
        }

        this.setupEventListeners();
        this.hideLoadingScreen();
    }

    initWindowManager() {
        if (!this.windowManager && window.WindowManager) {
            this.windowManager = new window.WindowManager(browserContent);
            // Create initial window
            this.windowManager.createPane('https://google.com');

            // Listen for pane activation to update UI
            document.addEventListener('pane-activated', (e) => {
                this.updateUIForPane(e.detail.pane);
            });
        }
    }

    updateUIForPane(pane) {
        if (!pane || !pane.webview) return;

        const update = () => {
            if (this.windowManager.activePane === pane) {
                try {
                    this.currentUrl = pane.webview.getURL();
                    addressBar.value = this.currentUrl;
                    this.updateNavigationButtons();
                } catch (e) {
                    // Webview might not be ready
                }
            }
        };

        update();

        // Attach listeners only once
        if (!pane._navListenersAttached) {
            pane.webview.addEventListener('did-navigate', update);
            pane.webview.addEventListener('did-navigate-in-page', update);
            pane.webview.addEventListener('did-start-loading', update);
            pane.webview.addEventListener('did-stop-loading', update);
            pane._navListenersAttached = true;
        }
    }

    initializeVoiceRecognition() {
        if ('webkitSpeechRecognition' in window) {
            this.recognition = new webkitSpeechRecognition();
            this.recognition.continuous = false;
            this.recognition.interimResults = false;
            this.recognition.lang = 'en-US';

            this.recognition.onstart = () => {
                console.log('🎤 Nova listening...');
                this.isListening = true;
                novaBtn.classList.add('listening');
                voiceOverlay.classList.add('active');
            };

            this.recognition.onresult = (event) => {
                const command = event.results[0][0].transcript;
                console.log('🗣️ Voice Command:', command);
                this.handleVoiceCommand(command);
            };

            this.recognition.onend = () => {
                this.isListening = false;
                novaBtn.classList.remove('listening');
                voiceOverlay.classList.remove('active');
            };

            this.recognition.onerror = (event) => {
                console.error('Voice recognition error:', event.error);
                this.isListening = false;
                novaBtn.classList.remove('listening');
                voiceOverlay.classList.remove('active');
            };
        }
    }

    setupEventListeners() {
        // Empire status updates
        setInterval(() => {
            this.updateEmpireStatus();
        }, 5000);
    }

    hideLoadingScreen() {
        if (!loadingScreen) return;
        setTimeout(() => {
            loadingScreen.style.opacity = '0';
            setTimeout(() => {
                loadingScreen.style.display = 'none';
            }, 500);
        }, 3000);
    }

    handleVoiceCommand(command) {
        const cmd = command.toLowerCase();

        // Update voice overlay
        document.getElementById('voice-command-text').textContent = `"${command}"`;

        // Send to main process
        window.empireApi.sendEmpireCommand(command);

        // Handle locally
        if (cmd.includes('navigate to') || cmd.includes('go to')) {
            const site = cmd.replace(/navigate to|go to/g, '').trim();
            this.navigateToSite(site);
        } else if (cmd.includes('new tab') || cmd.includes('new window')) {
            this.windowManager.createPane();
        } else if (cmd.includes('refresh') || cmd.includes('reload')) {
            this.reloadActive();
        } else if (cmd.includes('back')) {
            this.goBackActive();
        } else if (cmd.includes('forward')) {
            this.goForwardActive();
        }
    }

    navigateToSite(site) {
        let url = site;

        if (!url.includes('http')) {
            if (url.includes('.')) {
                url = `https://${url}`;
            } else {
                const shortcuts = {
                    'github': 'https://github.com',
                    'gmail': 'https://gmail.com',
                    'teams': 'https://teams.microsoft.com',
                    'discord': 'https://discord.com',
                    'youtube': 'https://youtube.com'
                };
                url = shortcuts[url] || `https://www.google.com/search?q=${encodeURIComponent(url)}`;
            }
        }

        if (this.windowManager && this.windowManager.activePane) {
            this.windowManager.activePane.webview.src = url;
            addressBar.value = url;
        }
    }

    updateNavigationButtons() {
        if (!this.windowManager || !this.windowManager.activePane) return;
        const webview = this.windowManager.activePane.webview;
        try {
            document.getElementById('back-btn').disabled = !webview.canGoBack();
            document.getElementById('forward-btn').disabled = !webview.canGoForward();
        } catch (e) {
            // Webview might not be ready
        }
    }

    reloadActive() {
        if (this.windowManager && this.windowManager.activePane) {
            this.windowManager.activePane.webview.reload();
        }
    }

    goBackActive() {
        if (this.windowManager && this.windowManager.activePane) {
            this.windowManager.activePane.webview.goBack();
        }
    }

    goForwardActive() {
        if (this.windowManager && this.windowManager.activePane) {
            this.windowManager.activePane.webview.goForward();
        }
    }

    async updateEmpireStatus() {
        try {
            const status = await window.empireApi.getEmpireStatus();
            // Update agent count and status indicators
            const agentCountEl = document.getElementById('agent-count');
            if (agentCountEl) agentCountEl.textContent = '47 AGENTS';
        } catch (error) {
            console.error('Failed to update Empire status:', error);
        }
    }
}

// Global Functions
window.activateNova = function() {
    if (empireNavigator.recognition && !empireNavigator.isListening) {
        empireNavigator.recognition.start();
    }
}

window.toggleSocietas = function() {
    window.empireApi.sendEmpireCommand('show societas');
}

window.handleAddressBar = function(event) {
    if (event.key === 'Enter') {
        const url = addressBar.value;
        empireNavigator.navigateToSite(url);
    }
}

window.goBack = function() {
    empireNavigator.goBackActive();
}

window.goForward = function() {
    empireNavigator.goForwardActive();
}

window.refresh = function() {
    empireNavigator.reloadActive();
}

window.newWindow = function() {
    if (empireNavigator.windowManager) {
        empireNavigator.windowManager.createPane();
    }
}

window.minimizeWindow = function() {
    window.empireApi.minimizeWindow();
}

window.maximizeWindow = function() {
    window.empireApi.maximizeWindow();
}

window.closeWindow = function() {
    window.empireApi.closeWindow();
}

// Initialize Empire Navigator
const empireNavigator = new EmpireNavigatorRenderer();

// Empire Easter Eggs
document.addEventListener('keydown', (event) => {
    // Ctrl+Shift+E = Empire Command Palette
    if (event.ctrlKey && event.shiftKey && event.key === 'E') {
        activateNova();
    }

    // Ctrl+Shift+S = Show Societas
    if (event.ctrlKey && event.shiftKey && event.key === 'S') {
        toggleSocietas();
    }
});

console.log('🏛️ Empire Navigator initialized');
console.log('🎤 Say "Hey Nova" or click the microphone');
console.log('💬 Press Ctrl+Shift+S for Societas');
