const WindowManager = require('./WindowManager');
const { ipcRenderer } = require('electron');

class EmpireNavigatorRenderer {
    constructor(windowManager) {
        this.wm = windowManager;
        this.isListening = false;
        this.recognition = null;

        this.initializeVoiceRecognition();
        this.setupStatusUpdates();
    }

    initializeVoiceRecognition() {
        if ('webkitSpeechRecognition' in window) {
            this.recognition = new webkitSpeechRecognition();
            this.recognition.continuous = false;
            this.recognition.interimResults = false;
            this.recognition.lang = 'en-US';

            const novaBtn = document.getElementById('nova-btn');
            const voiceOverlay = document.getElementById('voice-overlay');

            this.recognition.onstart = () => {
                console.log('🎤 Nova listening...');
                this.isListening = true;
                if(novaBtn) novaBtn.classList.add('listening');
                if(voiceOverlay) voiceOverlay.classList.add('active');
            };

            this.recognition.onresult = (event) => {
                const command = event.results[0][0].transcript;
                console.log('🗣️ Voice Command:', command);
                this.handleVoiceCommand(command);
            };

            this.recognition.onend = () => {
                this.isListening = false;
                if(novaBtn) novaBtn.classList.remove('listening');
                if(voiceOverlay) voiceOverlay.classList.remove('active');
            };

            this.recognition.onerror = (event) => {
                console.error('Voice recognition error:', event.error);
                this.isListening = false;
                if(novaBtn) novaBtn.classList.remove('listening');
                if(voiceOverlay) voiceOverlay.classList.remove('active');
            };
        }
    }

    setupStatusUpdates() {
        setInterval(() => {
            this.updateEmpireStatus();
        }, 5000);
    }

    async updateEmpireStatus() {
        try {
            const status = await ipcRenderer.invoke('get-empire-status');
            const agentCount = document.getElementById('agent-count');
            if (agentCount) agentCount.textContent = '47 AGENTS';
        } catch (error) {
            console.error('Failed to update Empire status:', error);
        }
    }

    handleVoiceCommand(command) {
        const cmd = command.toLowerCase();

        // Update voice overlay
        const voiceCmdText = document.getElementById('voice-command-text');
        if (voiceCmdText) voiceCmdText.textContent = `"${command}"`;

        // Send to main process
        ipcRenderer.invoke('empire-command', command);

        // Handle locally
        if (cmd.includes('navigate to') || cmd.includes('go to')) {
            const site = cmd.replace(/navigate to|go to/g, '').trim();
            this.navigateToSite(site);
        } else if (cmd.includes('new pane') || cmd.includes('open pane')) {
             this.wm.createPane('about:blank');
        } else if (cmd.includes('close pane')) {
             if (this.wm.activePane) this.wm.removePane(this.wm.activePane.id);
        } else if (cmd.includes('refresh') || cmd.includes('reload')) {
            if (this.wm.activePane && this.wm.activePane.webview) {
                this.wm.activePane.webview.reload();
            }
        } else if (cmd.includes('back')) {
            if (this.wm.activePane && this.wm.activePane.webview) {
                this.wm.activePane.webview.goBack();
            }
        } else if (cmd.includes('forward')) {
            if (this.wm.activePane && this.wm.activePane.webview) {
                this.wm.activePane.webview.goForward();
            }
        } else if (cmd.includes('societas')) {
            this.toggleSocietas();
        }
    }

    navigateToSite(site) {
        let url = site;

        if (!url.includes('http')) {
            if (url.includes('.')) {
                url = `https://${url}`;
            } else {
                const shortcuts = {
                    'github': 'https://github.com',
                    'gmail': 'https://gmail.com',
                    'teams': 'https://teams.microsoft.com',
                    'discord': 'https://discord.com',
                    'youtube': 'https://youtube.com'
                };
                url = shortcuts[url] || `https://www.google.com/search?q=${encodeURIComponent(url)}`;
            }
        }

        if (this.wm.activePane && this.wm.activePane.webview) {
             this.wm.activePane.webview.src = url;
             this.wm.updateAddressBar(url);
        } else {
            this.wm.createPane(url);
        }
    }

    activateNova() {
        if (this.recognition && !this.isListening) {
            this.recognition.start();
        }
    }

    toggleSocietas() {
        console.log('Toggling Societas panel...');
        // Implement societas panel toggle logic if UI exists
    }
}

document.addEventListener('DOMContentLoaded', () => {
    // Initialize the window manager
    const container = document.getElementById('pane-container');
    if (!container) {
        console.error('Pane container not found!');
        return;
    }

    const windowManager = new WindowManager('pane-container');

    // Create an initial pane
    windowManager.createPane('https://www.google.com');

    // Initialize Empire Navigator logic
    const empireNavigator = new EmpireNavigatorRenderer(windowManager);

    // Expose to window for debugging and interaction
    window.empireNavigator = empireNavigator;
    window.windowManager = windowManager;

    // Setup UI controls
    setupUIControls(windowManager);

    // Expose global functions expected by HTML onclick handlers
    window.activateNova = () => empireNavigator.activateNova();
    window.toggleSocietas = () => empireNavigator.toggleSocietas();
});

function setupUIControls(wm) {
    const addressBar = document.getElementById('address-bar');
    const backBtn = document.getElementById('back-btn');
    const forwardBtn = document.getElementById('forward-btn');
    const newPaneBtn = document.getElementById('new-pane-btn');

    if (newPaneBtn) {
        newPaneBtn.addEventListener('click', () => {
            wm.createPane('about:blank');
        });
    }

    if (addressBar) {
        addressBar.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                const url = addressBar.value;
                if (wm.activePane) {
                     if (wm.activePane.webview) {
                        let formattedUrl = url;
                        if (!formattedUrl.startsWith('http')) {
                            formattedUrl = 'https://' + formattedUrl;
                        }
                        wm.activePane.webview.src = formattedUrl;
                    }
                }
            }
        });
    }

    if (backBtn) {
        backBtn.addEventListener('click', () => {
            if (wm.activePane && wm.activePane.webview) wm.activePane.webview.goBack();
        });
    }

    if (forwardBtn) {
        forwardBtn.addEventListener('click', () => {
            if (wm.activePane && wm.activePane.webview) wm.activePane.webview.goForward();
        });
    }
}
