const jsdom = require("jsdom");
const { JSDOM } = jsdom;

const dom = new JSDOM(`<!DOCTYPE html><body><div id="pane-container"></div></body>`);
global.document = dom.window.document;
global.window = dom.window;
global.HTMLElement = dom.window.HTMLElement;
global.CustomEvent = dom.window.CustomEvent;
global.Event = dom.window.Event;

const WindowManager = require("../js/WindowManager");

// Mock webview element since JSDOM doesn't support it fully
// We just need it to not crash when properties are accessed
// JSDOM creates generic elements for unknown tags, so addEventListener works.

console.log("Running WindowManager Tests...");

try {
    const wm = new WindowManager("pane-container");
    console.log("WindowManager initialized.");

    // Test Create Pane
    console.log("Testing createPane...");
    const pane = wm.createPane("https://example.com");

    if (wm.panes.length !== 1) {
        throw new Error(`Expected 1 pane, got ${wm.panes.length}`);
    }

    const paneEl = document.getElementById(pane.id);
    if (!paneEl) {
        throw new Error("Pane element not found in DOM");
    }

    if (!paneEl.classList.contains("pane")) {
        throw new Error("Pane element missing 'pane' class");
    }

    console.log("createPane passed.");

    // Test Active Pane
    console.log("Testing active pane...");
    if (wm.activePane !== pane) {
        throw new Error("Active pane not set correctly");
    }
    console.log("Active pane passed.");

    // Test Remove Pane
    console.log("Testing removePane...");
    wm.removePane(pane.id);

    if (wm.panes.length !== 0) {
        throw new Error(`Expected 0 panes, got ${wm.panes.length}`);
    }

    if (document.getElementById(pane.id)) {
        throw new Error("Pane element still in DOM after removal");
    }
    console.log("removePane passed.");

    console.log("All WindowManager tests passed!");

} catch (error) {
    console.error("Test Failed:", error);
    process.exit(1);
}
