# Empire OS: LAN Boot & State Handoff Process

This document outlines the architecture for a "Fresh Every Time" operating system boot process that maintains state via seamless network handoff.

## Overview

The core concept is to replace traditional reboots with a network-booted fresh instance that inherits the state of critical services from the previous running instance. This minimizes downtime and ensures a clean environment for every session.

## Components

1.  **Boot Server (Node.js)**: Orchestrates the PXE boot process and coordinates state transfer.
2.  **Checkpoint Manager (Python)**: Uses CRIU to freeze running processes and transfer their memory/state.
3.  **Driver Updater (Python)**: Scans hardware on boot and installs the latest drivers dynamically.
4.  **Client Agent**: The interface on the "Old" OS that triggers the cycle.

## Detailed Workflow

### 1. Triggering the Cycle
*   User initiates a "Restart" via the Empire Navigator interface.
*   The Client Agent sends a request to the Boot Server: `POST /handoff/prepare`.
*   The Boot Server validates the request and prepares a target environment (or signals the local machine to reboot into network mode).

### 2. Pre-Shutdown Checkpoint
*   The Checkpoint Manager identifies critical PIDs (e.g., Guardian Sentinel, Neural Vault).
*   It executes CRIU dump commands:
    ```bash
    criu dump --tree <PID> --images-dir /tmp/checkpoint --shell-job --tcp-established
    ```
*   The memory pages and process state are compressed into an image archive.
*   The archive is streamed to the Boot Server via `POST /handoff/sync`.

### 3. Network Boot (iPXE)
*   The machine reboots.
*   BIOS/UEFI is configured to boot from LAN (PXE).
*   The Boot Server responds to the DHCP/PXE request with the iPXE script from `/pxe/boot.ipxe`.
*   The iPXE script loads the fresh kernel and minimal initrd (Alpine Linux base).

### 4. Fresh Environment Initialization
*   The new OS boots into RAM (diskless or overlayfs).
*   **Driver Updater** runs immediately:
    *   Scans PCI/USB devices.
    *   Fetches drivers from the Boot Server.
    *   Installs/Loads kernel modules.
*   Network networking is established.

### 5. State Restoration
*   The new OS requests the checkpoint image from the Boot Server.
*   The Checkpoint Manager executes CRIU restore:
    ```bash
    criu restore --images-dir /tmp/checkpoint --shell-job --tcp-established
    ```
*   Critical services resume exactly where they left off.

### 6. Cleanup
*   The old session is completely gone (RAM cleared on reboot).
*   Any temporary files not explicitly handed off are lost (ensuring no cruft buildup).

## Future Improvements
*   **Live Migration**: Migrate processes to a standby machine *before* rebooting the primary to achieve true zero downtime.
*   **P2P Handoff**: Direct transfer between instances without a central server bottleneck.
