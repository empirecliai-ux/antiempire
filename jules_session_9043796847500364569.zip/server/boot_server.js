const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = 8080;
const CHECKPOINT_DIR = path.join(__dirname, '../checkpoints');

// Ensure checkpoint directory exists
if (!fs.existsSync(CHECKPOINT_DIR)) {
    fs.mkdirSync(CHECKPOINT_DIR, { recursive: true });
}

// Helper to generate session ID
const generateSessionId = () => crypto.randomBytes(8).toString('hex');

const server = http.createServer((req, res) => {
    const { method, url } = req;
    console.log(`[${new Date().toISOString()}] ${method} ${url}`);

    // Route: PXE Boot Script
    if (url === '/pxe/boot.ipxe' && method === 'GET') {
        res.writeHead(200, { 'Content-Type': 'text/plain' });
        const ipxeScript = `#!ipxe
# Empire OS Boot Script
# This script boots the fresh OS instance into RAM

echo Booting Empire OS (Fresh Instance)...
set server_ip \${net0/next-server}

# Load Linux Kernel
kernel http://\${server_ip}:${PORT}/boot/vmlinuz initrd=initramfs.img console=tty0 console=ttyS0,115200n8

# Load Init Ramdisk
initrd http://\${server_ip}:${PORT}/boot/initramfs.img

# Boot
boot
`;
        res.end(ipxeScript);
        return;
    }

    // Route: Handoff Preparation
    if (url === '/handoff/prepare' && method === 'POST') {
        let body = '';
        req.on('data', chunk => {
            body += chunk.toString();
        });
        req.on('end', () => {
            const sessionId = generateSessionId();
            console.log(`Preparing handoff for session: ${sessionId}`);
            
            // In a real scenario, this would spin up a new VM or signal a physical node
            const response = {
                status: 'ready',
                sessionId: sessionId,
                targetIp: '192.168.1.50', // Mock target
                handoffUrl: `http://localhost:${PORT}/handoff/sync/${sessionId}`
            };
            
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify(response));
        });
        return;
    }

    // Route: Handoff Sync (Receive State)
    if (url.startsWith('/handoff/sync/') && method === 'POST') {
        const sessionId = url.split('/').pop();
        const filePath = path.join(CHECKPOINT_DIR, `${sessionId}.tar.gz`);
        const fileStream = fs.createWriteStream(filePath);

        req.pipe(fileStream);

        fileStream.on('finish', () => {
            console.log(`State received for session ${sessionId}. Saved to ${filePath}`);
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ status: 'received', size: fileStream.bytesWritten }));
        });

        fileStream.on('error', (err) => {
            console.error('Error saving checkpoint:', err);
            res.writeHead(500);
            res.end(JSON.stringify({ status: 'error', message: err.message }));
        });
        return;
    }

    // Default 404
    res.writeHead(404);
    res.end('Not Found');
});

server.listen(PORT, () => {
    console.log(`Boot Server running on port ${PORT}`);
    console.log(`Checkpoint storage: ${CHECKPOINT_DIR}`);
});
